app.run(['$templateCache', function($templateCache) {
    $templateCache.put('meeting',
        '<div id="confFullPannel">' +
        '    <HR id="line" style="FILTER: alpha(opacity=100,finishopacity=0,style=2); margin-left:2px" width="968px" color=#5CACEE SIZE=10>' +
        '    <div id="confList">' +
        '        <input type="button" id="searchConfList" value="my conf list" style="background:url(\'bin/img/confctrl/list.png\')" />' +
        '        <table class="confTreeList">' +
        '            <tr ng-repeat="confList in confLists" ng-click="showInfo($index)">' +
        '                <td style="width:75px;">{{confList.conf_subject}}</td>' +
        '                <td>{{confList.start_time}}</td>' +
        '            </tr>' +
        '        </table>' +
        '        <input type="button" id="turnListPage" title="turn page" ng-click="uiGetConfList()" />' +
        '    </div>' +
        '    <!--<div id="backPage"></div>-->' +
        '    <div id="upperPage" hidden="hidden">' +
        '        <p class="close"><img src="bin/img/login/btn_close_click.png" ng-click="closePage()" /></p>' +
        '        <div>' +
        '            <table>' +
        '                <tr>' +
        '                    <td>access number</td>' +
        '                    <td>{{accessNumber}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>chairman Pwd</td>' +
        '                    <td>{{chairmanPwd}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>conf Id</td>' +
        '                    <td>{{confId}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>conf state</td>' +
        '                    <td>{{confState}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>conf subject</td>' +
        '                    <td>{{confSubject}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>cycleConf Id</td>' +
        '                    <td>{{cycleConfId}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>start time</td>' +
        '                    <td>{{startTime}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>general pwd</td>' +
        '                    <td>{{generalPwd}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>media type</td>' +
        '                    <td>{{mediaType}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>scheduser name</td>' +
        '                    <td>{{scheduserName}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>scheduser number</td>' +
        '                    <td>{{scheduserNumber}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>conf size</td>' +
        '                    <td>{{size}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>end time</td>' +
        '                    <td>{{endTime}}</td>' +
        '                </tr>' +
        '                <tr>' +
        '                    <td>attendees</td>' +
        '                    <td title={{attendees}}>{{count}} ...</td>' +
        '                </tr>' +
        '            </table>' +
        '            <input type="button" value="enter conf" ng-click="uiEnterReservedConf()" />' +
        '        </div>' +
        '    </div>'

        +
        '    <div id="confPannel">' +
        '        <br/><br/>' +
        '        <img src="bin/img/confctrl/home.png" style="10%" />' +
        '        <span id="bookConf"><img class="bookConf" src="bin/img/confctrl/book.png"/><br />' +
        '        <span class="bookConf">Book Conf</span></span><br />'

        +
        '        <div id="confInfo">' +
        '            <div id="beforeBookConf">' +
        '                <img id="noConfAtNow" src="bin/img/confctrl/noConf.png" />' +
        '                <table id="confIncomingTable" hidden="hidden">' +
        '                    <tr>' +
        '                        <th>conference</th>' +
        '                        <th>incoming</th>' +
        '                    </tr>' +
        '                    <tr>' +
        '                        <td style="background:green" onclick="uiAcceptConf()">accept</td>' +
        '                        <td style="background:red" onclick="uiRejectConf()">reject</td>' +
        '                    </tr>' +
        '                </table>' +
        '                <div id="accessConfByCode">' +
        '                    <img src="bin/img/confctrl/cheek.png" />' +
        '                    <input type="text" id="confId" placeholder="Conf Id" />' +
        '                    <br/><img src="bin/img/confctrl/cheek.png" />' +
        '                    <input type="text" id="accessNumber" placeholder="Access Number" />' +
        '                    <br/><img src="bin/img/confctrl/cheek.png" />' +
        '                    <input type="text" id="confPasscode" placeholder="Passcode" />' +
        '                    <br/><input type="button" id="joinServConf" value="Join Conf" onclick="uiAccessReservedConf()" />' +
        '                </div>' +
        '                <div id="confDial">' +
        '                    <input type="text" id="confDialNumber" placeholder="conf access number" />' +
        '                    <div class="dial" onclick="inputNumThree(event)">' +
        '                        <input type="button" value="<-" />' +
        '                        <input type="button" value="1" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="2" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="3" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="4" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="5" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="6" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="7" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="8" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="9" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="*" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="0" onclick="DTMF(this.value)" />' +
        '                        <input type="button" value="#" onclick="DTMF(this.value)" />' +
        '                    </div>' +
        '                    <div>' +
        '                        <input type="button" id="callToJoinConf" title="startCall" onclick="uiCallAccessConf()" />' +
        '                    </div>' +
        '                </div>' +
        '            </div>' +
        '            <div id="bookConfInfo">' +
        '                <br/><span>Conf Start Time:</span>' +
        '                <input type="radio" name="startTime" id="startImmediate" />start now &nbsp &nbsp<input type="radio" name="startTime" id="startDelay" />start later' +
        '                <div id="bookTime">' +
        '                    <input type="text" class="bookTime" id="bookYear" placeholder="year" />-' +
        '                    <input type="text" class="bookTime" id="bookMonth" placeholder="month" />-' +
        '                    <input type="text" class="bookTime" id="bookDay" placeholder="day" /> &nbsp' +
        '                    <input type="text" class="bookTime" id="bookHour" placeholder="24h" />:' +
        '                    <input type="text" class="bookTime" id="bookMinute" /><br/>' +
        '                </div>' +
        '                <div>' +
        '                    <span>Conf Duration:</span>&nbsp' +
        '                    <input type="text" class="bookTime" id="bookDuraHour" value="2" />hour &nbsp' +
        '                    <input type="text" class="bookTime" id="bookDuraMinute" value="00" />minute' +
        '                    <br/><span>Media Type:</span>&nbsp' +
        '                    <select id="confMediaType">' +
        '                        <option value="1">audio conf</option>' +
        '                        <option value="3">video conf</option>' +
        '                        <option value="17">data conf</option>' +
        '                    </select>' +
        '                    <br/><span>Conf Size:</span>&nbsp' +
        '                    <input type="text" id="confSize" value="3" style="width:39px;" />' +
        '                    <span style="color:gray">3~200</span>' +
        '                    <br/><span>Conf Subject:</span>&nbsp' +
        '                    <input type="text" id="confSubject" placeholder="discussion AI" />' +
        '                    <br/><span>Attendee Info:</span>&nbsp' +
        '                    <input type="text" id="attendeeNumber" placeholder="123,123,123" /><br/><br/>' +
        '                    <input type="button" id="submitConfInfo" value="book conf" onclick="uiBookConf()" />' +
        '                </div>' +
        '            </div>' +
        '        </div>' +
        '    </div>' +
        '</div>'

        +
        '<div id="audioConfPannel" hidden="hidden">' +
        '    <div id="confFunction">' +
        '        <img src="bin/img/confctrl/avator.png" id="confAvator" />' +
        '        <input type="text" value="My Audio Conference" id="confGroupName" />' +
        '        <img src="bin/img/meeting/meeting_annotation.png" ng-click="ConfAsBeginAnnotation()" title="Start the desktop sharing annotation" />' +
        '        <img src="bin/img/meeting/meeting_annotation.png" ng-click="ConfAsEndAnnotation()" title="End the desktop sharing annotation" />' +
        '        <div id="confFunctionList">' +
        '            <!--The screen sharing starts-->' +
        '            <input type="button" title="screen share" id="screenShare" />' +
        '            <!--The screen sharing ends-->' +
        '            <input type="button" title="upgrade conf" hidden="hidden" id="switchMediaType" ng-click="uiUpgradeConf()" />' +
        '            <input type="button" id="confKeyboard" />' +
        '            <input type="button" id="muteConf" hidden="hidden" onclick="uiMuteConf(1)" />' +
        '            <input type="button" id="unmuteConf" hidden="hidden" onclick="uiMuteConf(0)" />' +
        '            <input type="button" title="switch number" id="switchTerminalNum" />' +
        '            <input type="button" id="moreChoose" /> &nbsp &nbsp &nbsp <span id="confTiming">00:00:00</span>' +
        '            <input type="button" id="confSignal" />&nbsp' +
        '            <input type="button" id="leaveAudioConf" title="leave conf" ng-click="uiLeaveConf()" />' +
        '        </div>' +
        '        <span id="addAttendeeNumber" hidden="hidden"><input type="text" id="newAttendeeNumber" value="123,123,123">' +
        '        <input type="button" title="add attendee" id="addConfAttendee" onclick="uiAddConfAttendee()"/></span>' +
        '    </div>' +
        '    <div id="confAttendeeList">' +
        '        <table id="confAttendeeTable">' +
        '            <tr ng-repeat="participant in participants">' +
        '                <td class="chairmanAttendee" hidden="hidden">&nbsp;<img src="bin/img/confctrl/leader.png" />&nbsp;</td>' +
        '                <td class="normalAttendee"></td>' +
        '                <td ng-click="ConfUserSetRole($index)">&nbsp; {{participant.number}} &nbsp;</td>' +
        '                <td class="dataConfUser" hidden="hidden" ng-click="">&nbsp <img width="16px" height="16px" src="bin/img/meeting/datascreen.png" />&nbsp</td>' +
        '                <td class="dataConfPresenter" hidden="hidden">&nbsp; <img src="bin/img/confctrl/speaker.png" /> &nbsp;</td>' +
        '                <td class="muteAttendee" hidden="hidden" ng-click="uiMuteAttendee($index)">&nbsp<img src="bin/img/confctrl/conf_connected.png" />&nbsp</td>' +
        '                <td class="unmuteAttendee" hidden="hidden" ng-click="uiMuteAttendee($index)">&nbsp<img src="bin/img/confctrl/conf_mute.png" />&nbsp</td>' +
        '                <td class="displayConfSpeaker" hidden="hidden">&nbsp<img src="bin/img/confctrl/speaker.png" />&nbsp</td>' +
        '                <td class="displayAttendeeState" hidden="hidden">&nbsp<img src="bin/img/confctrl/conf_hangup.png" />&nbsp</td>' +
        '                <td class="removeConfAttendee" hidden="hidden" ng-click="uiHangUpAttendee($index)">&nbsp<img src="bin/img/confctrl/remove.png" />&nbsp</td>'

        +
        '                <td class="confAsSetPrivilegeSet" hidden="hidden"><img src="bin/img/meeting/meeting_privilege.png" ng-click="ConfAsSetPrivilege(1,1,$index)" title="Grant remote control" /></td>' +
        '                <td class="confAsSetPrivilegeRevoke" hidden="hidden"><img src="bin/img/meeting/meeting_privilege.png" ng-click="ConfAsSetPrivilege(1,0,$index)" title="Retrieve remote control" /></td>' +
        '            </tr>' +
        '        </table>' +
        '    </div>' +
        '    <div id="confBlank">' +
        '        <!--The screen sharing table start-->' +
        '        <table id="screenShareType" border="1px" hidden="hidden">' +
        '            <tr>' +
        '                <td><span ng-click="ConfAsStart(0)">Start screen sharing</span></td>' +
        '            </tr>' +
        '            <tr>' +
        '                <td><span ng-click="ConfAsStart(1)">Start the program sharing</span></td>' +
        '            </tr>' +
        '            <tr>' +
        '                <td><span ng-click="ConfDsOpen()">Start document sharing</span></td>' +
        '            </tr>' +
        '            <tr>' +
        '                <td><span ng-click="ConfDsNewDoc()">Start whiteboard sharing</span></td>' +
        '            </tr>' +
        '        </table>' +
        '        <!--The screen sharing table end-->' +
        '        <table id="terminalNumOption" hidden="hidden">' +
        '            <tr>' +
        '                <td><img src="bin/img/confctrl/uaccNo.png" /><input type="text" id="otherTerminalNum" /></td>' +
        '            </tr>' +
        '            <tr>' +
        '                <td><img src="bin/img/confctrl/icon_Mobile.png" /><input type="button" value="switch terminal" onclick="switchTerminal()" /></td>' +
        '            </tr>' +
        '        </table>'

        +
        '        <table id="moreChooseOption" hidden="hidden">' +
        '            <tr id="chairmanEndConf" hidden="hidden">' +
        '                <td ng-click="uiEndConf()">chairman end conf</td>' +
        '            </tr>' +
        '            <tr id="chairmanLockConf" hidden="hidden">' +
        '                <td onclick="uiLockConf(1)">lock conf</td>' +
        '            </tr>' +
        '            <tr id="chairmanunLockConf" hidden="hidden">' +
        '                <td onclick="uiLockConf(0)">unlock conf</td>' +
        '            </tr>' +        
        '            <tr id="chairmanPostponeConf" hidden="hidden">' +
        '                <td><input type="text" id="postponeTime"><input type="button" value="postpone conf" onclick="uiPostponeConf()"/></td>' +
        '            </tr>' +   		
        '            <tr>' +
        '                <td><span ng-click="confVideo()">open video</span></td>' +
        '            </tr>' +
        '            <tr>' +
        '                <td><span ng-click="confVideoClose()">close video</span></td>' +
        '            </tr>' +
        '            <tr>' +
        '                <td><span ng-click="setConfMode()">conference mode</span></td>' +
        '            </tr>' +
        '        </table>' +

        '        <!--The video conference begin-->' +
        '        <div class="login-content" ng-show="videoConference" >' +
        '            <p>video conference</p>' +
        '            <canvas id="videoLocalCanvas" width="0px" height="0px" style="border:1px solid #d3d3d3;">' +
        '                  Your browser does not support the HTML5 canvas tag.' +
        '            </canvas>' +
        '            <canvas id="videoRemoteCanvas" width="0px" height="0px" style="border:1px solid #d3d3d3;">' +
        '                  Your browser does not support the HTML5 canvas tag.' +
        '            </canvas>' +
        '        </div>' +
        '        <!--The video conference end-->' +

        '        <!--The data conference begins-->' +
        '        <div class="login-content" ng-show=" MeetingPageShow" ng-init="meetingBasicEvent()">' +
        '            <!--<p>MEETING</p>-->' +
        '        </div>'
        +
        '        <div class="im-main-content" ng-show="!MeetingPageShow">' +
        '            <div class="meetingContent">' +
        '                <div class="meetingContentRight" ng-show="(screenShow == 0)">' +
        '                    <div class="meetingButtonRight">' +
        '                        <img src="bin/img/meeting/conf_leader.png" ng-click="ConfUserRequestRole(1)" title="Apply for host" />' +
        '                        <img src="bin/img/meeting/conf_connected.png" ng-click="ConfUserRequestRole(2)" title="Apply for presenter" />' +
        '                    </div>' +
        '                    <div id="meetingMessage">' +
        '                        Conference Theme：<span>{{meetingTitle}}</span> <br/> Conference Host：<span></span>' +
        '                    </div>' +
        '                    <div id="meetingWelcome">' +
        '                        Welcome to join the conference, you can share your information!' +
        '                    </div>' +
        '                     <canvas id="meetingLocalCanvas" width="0px" height="0px" style="border:1px solid #d3d3d3;">' +
        '                             Your browser does not support the HTML5 canvas tag.' +
        '                     </canvas>' +
        '                     <canvas id="meetingRemoteCanvas1" width="0px" height="0px" style="border:1px solid #d3d3d3;">' +
        '                             Your browser does not support the HTML5 canvas tag.' +
        '                     </canvas>' +
        '                     <canvas id="meetingRemoteCanvas2" width="0px" height="0px" style="border:1px solid #d3d3d3;">' +
        '                             Your browser does not support the HTML5 canvas tag.' +
        '                     </canvas>' +
        '                     <canvas id="meetingRemoteCanvas3" width="0px" height="0px" style="border:1px solid #d3d3d3;">' +
        '                             Your browser does not support the HTML5 canvas tag.' +
        '                     </canvas>' +
        '                </div>' +
        '                <!--Screen sharing host interface-->' +
        '                <div class="meetingContentRight" ng-show="(screenShow == 1)">' +
        '                    <div class="meetingButtonRight">' +
        '                        <img src="bin/img/meeting/conf_close.png" ng-click="ConfAsStop()" title="End desktop sharing" />' +
        '                    </div>' +
        '                    <span id="screenOwnerShow">{{meetingAttendeeList[0].user_name}}Shared in the desktop</span>' +
        '                </div>' +
        '                <!--Screen sharing participants interface-->' +
        '                <div class="meetingContentRight" ng-show="(screenShow == 2)">' +
        '                    <div class="meetingButtonRight">' +
        '                        <img id="annotationASCustomer" width="25px" height="25px" src="bin/img/meeting/conf_check.png" title="Graphic annotation" />' +
        '                        <table id="annotationASTypeCustomer" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/check.png" ng-click="annotationSwitch(72)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/xcheck.png" ng-click="annotationSwitch(73)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/lpointer.png" ng-click="annotationSwitch(74)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/rpointer.png" ng-click="annotationSwitch(75)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/upointer.png" ng-click="annotationSwitch(76)" /></td>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img id="annotationASFont" width="25px" height="25px" src="bin/img/meeting/conf_font.png" title="Text annotated" />' +
        '                        <table id="annotationASTypeFont" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(61)">Text annotated</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(64)">Modify text annotation</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(77)">Laser pen</span></td>' +
        '                            </tr>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img id="annotationASDrawing" width="25px" height="25px" src="bin/img/meeting/meetingDSAnnotation.png" title="Geometric annotation" />' +
        '                        <table id="annotationASTypeDrawing" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(65)">Pencil line</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(66)">Bright line</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(67)">Hollow rectangle</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(68)">Fill rectangle</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(69)">Single arrow</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(70)">Double arrows</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(71)">Whiteboard pen</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(63)">Modify the label</span></td>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/meetingDSAnnotationClear.png" ng-click="annotationSwitch(62)" title="Clear the label" />' +
        '                    </div>' +
        '                    <p>{{meetingAttendeeList[0].user_name}}Shared in the desktop</p>' +
        '                    <img id="screenShow" ng-src="{{imgScreenSrc}}" hidden="hidden" />' +
        '                    <canvas id="imgASCanvas" class="fl" width="750px" height="650px"></canvas>' +
        '                </div>' +
        '                <!--Document sharing host interface-->' +
        '                <div class="meetingContentRight" ng-show="(screenShow == 3)">' +
        '                    <div class="meetingButtonRight">' +
        '                        <img id="annotationCustomer" width="25px" height="25px" src="bin/img/meeting/conf_check.png" title="Graphic annotation" />' +
        '                        <table id="annotationTypeCustomer" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/check.png" ng-click="annotationSwitch(12)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/xcheck.png" ng-click="annotationSwitch(13)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/lpointer.png" ng-click="annotationSwitch(14)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/rpointer.png" ng-click="annotationSwitch(15)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/upointer.png" ng-click="annotationSwitch(16)" /></td>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img id="annotationFont" width="25px" height="25px" src="bin/img/meeting/conf_font.png" title="Text annotation" />' +
        '                        <table id="annotationTypeFont" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(1)">Text annotation</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(4)">Modify text annotation</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(17)">Laser pen</span></td>' +
        '                            </tr>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img id="annotationDrawing" width="25px" height="25px" src="bin/img/meeting/meetingDSAnnotation.png" title="Geometric annotation" />' +
        '                        <table id="annotationTypeDrawing" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(5)">Pencil line</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(6)">Bright line</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(7)">Hollow rectangle</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(8)">Fill rectangle</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(9)">Single arrow</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(10)">Double arrows</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(11)">Whiteboard pen</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(3)">Modify the label</span></td>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/meetingDSAnnotationClear.png" ng-click="annotationSwitch(2)" title="Clear the label" />' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/meetingPrevious.png" ng-click="preMeetingInfo()" title="Previous page" />' +
        '                        <lable id="meetingCurrentPage">{{meetingCurrentPage}}</lable>' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/meetingNext.png" ng-click="nextMeetingInfo()" title="Next page" />' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/meetingRefresh.png" ng-click="dsGetSyncinfo()" title="Get document sharing data" />' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/conf_sysc.png" ng-click="confPageSync(0)" title="Toggle local page" />' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/conf_close.png" ng-click="confDsClose()" title="End document sharing" />' +
        '                    </div>' +
        '                    <span id="screenOwnerShow">{{meetingAttendeeList[0].user_name}}Shared in the document</span>' +
        '                    <img id="DOCShow" ng-src="{{imgDSSrc}}" hidden="hidden" />' +
        '                    <canvas id="imgDSCanvas" class="fl" width="750px" height="650px"></canvas>' +
        '                </div>' +
        '                <!--Whiteboard sharing host interface-->' +
        '                <div class="meetingContentRight" ng-show="(screenShow == 5)">' +
        '                    <div class="meetingButtonRight">' +
        '                        <img id="annotationWBCustomer" width="25px" height="25px" src="bin/img/meeting/conf_check.png" title="Graphic annotation" />' +
        '                        <table id="annotationWBTypeCustomer" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/check.png" ng-click="annotationSwitch(42)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/xcheck.png" ng-click="annotationSwitch(43)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/lpointer.png" ng-click="annotationSwitch(44)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/rpointer.png" ng-click="annotationSwitch(45)" /></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td> <img width="25px" height="25px" src="bin/img/meeting/upointer.png" ng-click="annotationSwitch(46)" /></td>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img id="annotationWBFont" width="25px" height="25px" src="bin/img/meeting/conf_font.png" title="Text annotation" />' +
        '                        <table id="annotationWBTypeFont" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(31)">Text annotation</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(34)">Modify text annotation</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(47)">Laser pen</span></td>' +
        '                            </tr>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img id="annotationWBDrawing" width="25px" height="25px" src="bin/img/meeting/meetingDSAnnotation.png" title="Geometric annotation" />' +
        '                        <table id="annotationWBTypeDrawing" border="1px" hidden="hidden">' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(35)">Pencil line</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(36)">Bright line</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(37)">Hollow rectangle</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(38)">Fill rectangle</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(39)">Single arrow</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(40)">Double arrows</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(41)">Whiteboard pen</span></td>' +
        '                            </tr>' +
        '                            <tr>' +
        '                                <td><span ng-click="annotationSwitch(33)">Modify the label</span></td>' +
        '                            </tr>' +
        '                        </table>' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/meetingDSAnnotationClear.png" ng-click="annotationSwitch(32)" title="Clear the label" />' +
        '                        <img width="25px" height="25px" src="bin/img/meeting/conf_close.png" ng-click="confWBClose()" title="End whiteboard sharing" />' +
        '                    </div>' +
        '                    <span id="screenOwnerWBShow">{{meetingAttendeeList[0].user_name}}Shared in whiteboard</span>' +
        '                    <img id="DOCWBShow" ng-src="{{imgDSSrc}}" hidden="hidden" />' +
        '                    <canvas id="imgWBCanvas" class="fl" width="750px" height="650px"></canvas>' +
        '                </div>' +
        '            </div>' +
        '        </div>' +
        '        <!--The data meeting ends-->' +
        '    </div>' +
        '</div>'
    )
}]);
app.run(['$templateCache', function($templateCache){
    $templateCache.put('exception',
         '<div id="exception">'
        +'    <input type="text" id="connectState" value="Connect state:" readonly="readonly" />'
        +'    <input type="text" id="exceptionConnection" readonly="readonly" style="background-color:gray;border:none" /><br/><br/>'
        +'    <input type="text" id="offlineParse" value="Offline parse:" readonly/>'
        +'    <input type="test" id="fileFullPath" style="border:none;position:relative;bottom:10px;width:145px" readonly/><br /><br />'
        +'    <a href="javascript:;" class="file">input file'
        +'    <input type="file" name="fileTrans"/>'
        +'    </a>'
        +'    <input type="button" id="parseLog" value="parse log" class="file" style="position:relative;bottom:10px;margin-left:10%" />'

        +'    <ol id="exceptionList" class="rectangle-list">'
        +'    </ol>'
        +'</div>'
    )
}]);


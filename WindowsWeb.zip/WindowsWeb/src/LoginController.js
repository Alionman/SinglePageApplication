app.controller("loginController", function($rootScope, $scope) {
    /*load page,then give tab a value*/
    $rootScope.tab = 1;
    $scope.LoginPageShow = true;

    if (sessionStorage.authorize_result != null && sessionStorage.authorize_result != '' && sessionStorage.authorize_result != undefined) {
        $scope.LoginPageShow = false;
    }

    var loginAccountInfo = localStorage.loginAccountInfo;
    if (loginAccountInfo != null && loginAccountInfo != '' && loginAccountInfo != undefined) {

        loginAccountInfo = JSON.parse(loginAccountInfo);
        $scope.AccountVal = loginAccountInfo.AccountVal; //user name
        $scope.Password = loginAccountInfo.Password; //password
        $scope.server_addr = localStorage.server_addr; //server address
        $scope.server_port = localStorage.server_port; //server port
        $scope.local_ip = sessionStorage.local_ip;

    } else {
        $scope.AccountVal = "";
        $scope.Password = "";
        $scope.server_addr = "";
        $scope.server_port = 0;
        $scope.local_ip = "";

    }

    //This function is used to  login init.
    $scope.loginInit = function() {
        localStorage.server_addr = $scope.server_addr;
        localStorage.server_port = $scope.server_port;
        setGetBestLocalIp($scope.server_addr);
        var solutionType = $("#solution_type").find("option:selected").text();
        sessionStorage.setItem("solutionType", solutionType);
        alert("init success");
    }

    //This function is used to Uportal authenticate
    $scope.loginUPortalAuth = function() {
        loginUPortalAuth($scope.AccountVal, $scope.Password, $scope.server_addr, $scope.server_port, 
        { onUportalAuthResult: onLoginAuthResult, onRefreshTokenResult: onTokenRefresh });
    };

    //This function is used to  login uninit.
    $scope.loginUninit = function() {
        $scope.LoginPageShow = true;
        sessionStorage.clear();
        // SIP DeRegister
        uiDeRegister();
        //IM IM logout
        imLoginout();
    }

    //This callback of login authenticate result.
    function onLoginAuthResult(data) {

        if (data == 0) {
            var loginAccountInfo = {
                "AccountVal": $scope.AccountVal,
                "Password": $scope.Password
            }
            loginAccountInfo = JSON.stringify(loginAccountInfo);
            localStorage.loginAccountInfo = loginAccountInfo;

            $scope.LoginPageShow = false;
            $scope.$digest();
            //call sip login
            autoRegister();
            //ctd server cfg
            setCtdServerParam();
            //confctrl
            confCtrlCfg();
            //IM login 
            imLogin();
            //eaddr login
            eaddrInit();
            //detect firewall
            firewallDetect();
        } else {
            alert("Login failed, please login again");
        }
    }

    function onTokenRefresh(data) {
        if (data == 0) {
            eaddrInit();
        } else {
            alert("Account has expired, please login again");
        }
    }

    $scope.refreshToken = function() {
        refreshToken();
    }

    $scope.firewallDetect = function() {
        firewallDetect();
    }
});
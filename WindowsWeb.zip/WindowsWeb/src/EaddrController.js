app.controller("eaddrController", function($rootScope, $scope) {
    /*load page,then give tab a value*/
    $rootScope.tab = 5;
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /********************************EADDR*******************************************************/
    //This param is used to search enterprise address Info
    $scope.searchcondition = "1";
    $scope.searchPageIndex = 1;
    $scope.SearchType = 0;
    //This param is used to search avatar
    $scope.SeqNo = 1;
    loginAccountInfo = localStorage.loginAccountInfo;
    $scope.ucaccount = JSON.parse(loginAccountInfo).AccountVal;
    //This param is used to set avatar
    $scope.IconType = 1;
    $scope.SmallIconFilePath = "E:/json/1.jpg";
    $scope.MediumIconFilePath = "E:/json/2.jpg";
    $scope.LargeIconFilePath = "E:/json/3.jpg";
    $scope.IconID = 2;
    $scope.eaddrHeadSrc = "bin/img/headimg/0.png";
    $scope.eaddrMyHeadSrc = "bin/img/headimg/0.png";
    $scope.isOwner = 0;
    //This param is used to search department
    $scope.DepId = "-1";

    //This function is used to Page down
    $scope.nextEaddrInfo = function() {
        $scope.searchPageIndex = $scope.searchPageIndex + 1;
        $scope.startEaddrSearchInfo();
    }

    //This function is used to Page up
    $scope.preEaddrInfo = function() {

        $scope.searchPageIndex = ($scope.searchPageIndex - 1) <= 0 ? 1 : ($scope.searchPageIndex - 1);
        $scope.startEaddrSearchInfo();
    }

    //This function is used to search enterprise address Info
    $scope.startEaddrSearchInfo = function() {

        startEaddrSearchInfo(($scope.searchcondition), ($scope.searchPageIndex), ($scope.SearchType), { onSearchContactResult: onEaddrSearchInfo });
    }

    setTimeout(function() { $scope.startEaddrSearchInfo(); }, 1000);

    // This callback of enterprise address book information.
    function onEaddrSearchInfo(data) {
        $scope.eaddrDatas = data.param.entry || null;
        $scope.$digest();
    }

    //This function is used to search avatar
    $scope.startEaddrSearchAvatar = function(isOwner) {
        if (isOwner == 0) {
            $scope.isOwner = isOwner;
            startEaddrSearchAvatar($scope.SeqNo, $scope.ucaccount, { response: onEaddrSearchAvatarResult, onGetIAvatarResult: onGetIAvatarResult });
        } else {
            $scope.isOwner = isOwner;
            startEaddrSearchAvatar($scope.SeqNo, $scope.eaddrUcaccount, { response: onEaddrSearchAvatarResult, onGetIAvatarResult: onGetIAvatarResult });
        }

    }

    // This callback of search the avatar results
    function onEaddrSearchAvatarResult(data) {
        if (data == 0) {

        } else {
            alert("Avatar query failed");
        }
    }

    function onGetIAvatarResult(data) {
        if ($scope.isOwner == 0) {
            $scope.eaddrMyHeadSrc = "bin/img/headimg/" + (data.AvatarID == undefined ? data.AvatarFile : (data.AvatarID + ".png"));
        } else {
            $scope.eaddrHeadSrc =   "bin/img/headimg/" + (data.AvatarID == undefined ? data.AvatarFile : (data.AvatarID + ".png"));
        }
        $scope.$digest();
    }

    //This function is used to set avatar
    $scope.startEaddrSetIcon = function(IconType, IconID) {
        $scope.eaddrMyHeadSrc = "bin/img/headimg/" + IconID + ".png";
        if (IconType == 0) {
            startEaddrSetIcon(IconType, $scope.SmallIconFilePath, $scope.MediumIconFilePath, $scope.LargeIconFilePath, IconID, { onSetIconResult: onSetIconResult });
        } else {
            var sendFilePath = prompt("please input file path(include file name)");
            if (sendFilePath) {
                sendFilePath = sendFilePath.replace(/\\/g, "/");
                $scope.SmallIconFilePath = sendFilePath;
                $scope.MediumIconFilePath = sendFilePath;
                $scope.LargeIconFilePath = sendFilePath;
                startEaddrSetIcon(IconType, $scope.SmallIconFilePath, $scope.MediumIconFilePath, $scope.LargeIconFilePath, IconID, { onSetIconResult: onSetIconResult });
            }
        }
    }

    function onSetIconResult(data) {
        if (data == 0) {
            // alert("Avatar set up successfully");
        } else {
            alert("Avatar settings failed");
        }
    }

    //This function is used to search department   
    $scope.startEaddrSearchDept = function() {

        eaddrSearchDept($scope.SeqNo, $scope.DepId, { onSearchDeptResult: onEaddrSearchDept });
    }

    function onEaddrSearchDept(data) {
        alert("department ID" + data.SearchDepId + "\n" +
            "deptId:" + data.entry[0].deptId + "\n" +
            "deptName:" + data.entry[0].deptName + "\n" +
            "parentDeptId:" + data.entry[0].parentId);
    }

    //This function is used to search enterprise address details
    function contactInfo(i) {

        eaddrInfo = $scope.eaddrDatas;
        $scope.eaddrName = eaddrInfo[i].name;
        $scope.eaddrUcaccount = eaddrInfo[i].ucaccount;
        $scope.eaddrGender = eaddrInfo[i].gender;
        $scope.eaddrPosition = eaddrInfo[i].position;
        $scope.eaddrDeptname = eaddrInfo[i].deptname;
        $scope.eaddrOfficephone = eaddrInfo[i].officephone;
        $scope.eaddrMobile = eaddrInfo[i].mobile;
        $scope.eaddrOfficephone2 = eaddrInfo[i].officephone2;
        $scope.eaddrOtherphone = eaddrInfo[i].otherphone;
        $scope.eaddrOtherphone2 = eaddrInfo[i].otherphone2;
        $scope.eaddrHomephone = eaddrInfo[i].homephone;
        $scope.eaddrEmail = eaddrInfo[i].email;
        $scope.eaddrZipcode = eaddrInfo[i].zipcode;
        $scope.eaddrFax = eaddrInfo[i].fax;
        $scope.eaddrAddress = eaddrInfo[i].address;

    }

    //This function is used to show background color
    $scope.showBg = function(i) {
        var bh = $("body").height();
        var bw = $("#eaddrBody").width();
        $("#fullbg").css({
            height: bh * 0.845,
            width: bw,
            display: "block"
        });
        $("#dialog").show();
        contactInfo(i);
        $scope.startEaddrSearchAvatar(1);
        $scope.startEaddrSearchAvatar(0);
    }

    $scope.closeBg = function() {
        $("#fullbg,#dialog").hide();
    }

    /********************************EADDR*******************************************************/
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

});

function uiCtdStartCall(){

    $('#callPanel').hide();
    $('#callingPanel').show();
    $('#calling_num').val($('#callee_num').val());
    var ctdCallerNum = $('#ctdCallerNum').val();
    var calleeNum = $('#callee_num').val();
    ctdStartCall(ctdCallerNum.toString(), calleeNum.toString(), {onCallStateNotify : uiOnCallStateNotify});
}

function uiOnCallStateNotify(data){
    var state = ["idle","calling","talking","end","hold"];
    $('#callState').val(state[data.param.type]);
    if(state[data.param.type] == "end"){
        $('#callPanel').show();
        $('#callingPanel').hide();        
    }
}


function uiCtdEndCall(){
    ctdEndCall();
    $('#callingPanel').hide();
    $('#callPanel').show();
}


//Build an enterprise address book callback array
var eaddrNotifyFuncs = new Array();
var eaddrRspFuncs = new Array();
//This class is used to initialize the enterprise address book
var tupEaddr = new TUPEaddr({
    ready: onEaddrReady,
    close: onEaddrClose
});

function onEaddrReady() {

}

function onEaddrClose() {

}

//This function is used to init enterprise address book 
function eaddrInit() {
    authorize_result = sessionStorage.authorize_result;
    authorize_result = JSON.parse(authorize_result);
    var param2 = {
        "LogLevel": 0,
        "LogFileSize": 1024,
        "LogPath": "./"
    }
    tupEaddr.eaddrSetLogPara(param2);
    var param = {
        "ServerType": 3,
        "HttpServerAddr": 'https://' + authorize_result.auth_serinfo.server_uri + ':' + authorize_result.auth_serinfo.server_port + '/services',
        "AvatarServerAddr": 'https://' + authorize_result.auth_serinfo.server_uri + ':' + authorize_result.auth_serinfo.server_port + '/headportrait',
        "PageCount": 20,
        "UserName": authorize_result.sip_impi,
        "Token": authorize_result.auth_token,
        "AvatarFilePath": "../../../bin/img/headimg/",
        "HttpsVerifyMode": 0,
        "CertFilePath": "",
        "RCSType": 1,
        "IconType": 0
    }
    tupEaddr.eaddrConfig(param);
}

//This function is used to search enterprise address book info.
function startEaddrSearchInfo(searchcondition, searchPageIndex, SearchType, callbacks) {
    if (callbacks && typeof callbacks.onSearchContactResult == "function") {
        this.eaddrNotifyFuncs[1] = callbacks.onSearchContactResult;
    }

    var paramSearchInfo = {
        "SeqNo": 20,
        "ServerType": 3,
        "condition": searchcondition,
        "PageIndex": searchPageIndex,
        "SearchType": SearchType,
        "DeptId": "10000"
    }
    tupEaddr.eaddrSearchInfo(paramSearchInfo, { onSearchContactResult: onEaddrSearchInfo });
}

function onEaddrSearchInfo(data) {
    if (typeof eaddrNotifyFuncs[1] == "function") {
        eaddrNotifyFuncs[1](data);
    }
}

//This function is used to search enterprise address book department.
function eaddrSearchDept(SeqNo, DepId, callbacks) {
    if (callbacks && typeof callbacks.onSearchDeptResult == "function") {
        this.eaddrNotifyFuncs[2] = callbacks.onSearchDeptResult;
    }
    var paramDept = {
        "SeqNo": SeqNo,
        "DepId": DepId,
        "DepFilePath": "D:\\json\\-1.xml"
    }
    tupEaddr.eaddrSearchDept(paramDept, { onSearchDeptResult: onEaddrSearchDept });
}


function onEaddrSearchDept(data) {
    if (typeof eaddrNotifyFuncs[2] == "function") {
        eaddrNotifyFuncs[2](data.param);
    }
}

//This function is used to search enterprise address book avatar.
function startEaddrSearchAvatar(SeqNo, ucaccount, callbacks) {
    if (callbacks && typeof callbacks.onGetIAvatarResult == "function") {
        this.eaddrNotifyFuncs[3] = callbacks.onGetIAvatarResult;
    }
    if (callbacks && typeof callbacks.response == "function") {
        this.eaddrRspFuncs[3] = callbacks.response;
    }
    var paramSearchAvatar = {
        "SeqNo": SeqNo,
        "ServerType": 3,
        "ucaccount": ucaccount
    }
    tupEaddr.eaddrSearchAvatar(paramSearchAvatar, { response: onEaddrSearchAvatarResult, onGetIAvatarResult: onGetIAvatarResult });
}

function onEaddrSearchAvatarResult(data) {
    if (typeof eaddrRspFuncs[3] == "function") {
        eaddrRspFuncs[3](data.result);
    }
}

function onGetIAvatarResult(data) {
    if (typeof eaddrNotifyFuncs[3] == "function") {
        eaddrNotifyFuncs[3](data.param);
    }
}

//This function is used to set enterprise address book avatar.
function startEaddrSetIcon(IconType, SmallIconFilePath, MediumIconFilePath, LargeIconFilePath, IconID, callbacks) {
    if (callbacks && typeof callbacks.onSetIconResult == "function") {
        this.eaddrNotifyFuncs[4] = callbacks.onSetIconResult;
    }
    var paramSetIcon = {
        "ServerType": 3,
        "IconType": IconType,
        "SmallIconFilePath": SmallIconFilePath,
        "MediumIconFilePath": MediumIconFilePath,
        "LargeIconFilePath": LargeIconFilePath,
        "IconID": IconID
    }
    tupEaddr.eaddrSetIcon(paramSetIcon, { onSetIconResult: onSetIconResult });
}

function onSetIconResult(data) {
    if (typeof eaddrNotifyFuncs[4] == "function") {
        eaddrNotifyFuncs[4](data.param.result);
    }
}
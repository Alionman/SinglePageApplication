//This is used to create a object of tupCtd, and init the basic configure when wsocket is opened. and uninit ctd when wsocket is closed
if (!tupCtd){
   var tupCtd = new TUPCtd({ready : onCtdReady, close : onCtdClose}); 
}

//This Array is used to save callbacks of functions.
var ctdNotifyFuncs = new Array();

//This function is used to do init when Ctd component is ready
function onCtdReady(){
    var bool = sessionStorage.getItem("ctdKey");    
    if (!bool){
        ctdInit();
        sessionStorage.setItem("ctdKey", "true");
    }
}

//This function is used to do uninit when Ctd component is close
function onCtdClose(){
    ctdUninit();
    sessionStorage.removeItem("ctdKey");
} 

//This function is used to init ctd, including start log, set server param and init component
function ctdInit(){
    tupCtd.logStart(
        "./jsdemolog",
        5,
        2,
        10
    );
}

//This function is used to unit ctd, including stop log and uninit component
function ctdUninit(){
    tupCtd.logStop();
    tupCtd.uninit();
}


//This function is used to set ctd server param, this param come from onUportalAuthResult of login authorize
function setCtdServerParam(){
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = JSON.parse(authorize_result);
    tupCtd.setServerParam({
        server_addr: authorizeResult.auth_serinfo.server_uri,
        port: authorizeResult.auth_serinfo.server_port
    });
    tupCtd.init(1);
}

var ctdCallId = 0;

//This function is used to start call of ctd, if caller number is null, caller default to be user itself.
function ctdStartCall(callerNumber, calleeNum, callbacks){
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = JSON.parse(authorize_result);
    if (callbacks && typeof callbacks.onCallStateNotify == "function") {
        this.ctdNotifyFuncs[0] = callbacks.onCallStateNotify;
    }    
    if (callerNumber){
        tupCtd.startCall({
            caller_number : callerNumber,
            callee_number : calleeNum,
            token : authorizeResult.auth_token
        },{
            onStartCallResult:startCallResult,
            onCallStateNotify:callStateNotify
        });
    }
}

//This function is a callback of start call, it will carry information of this call including callid. 
function startCallResult(data){
    
}

//This function is used to end call by using callid
function ctdEndCall(){
    tupCtd.endCall(ctdCallId);
}

//This function is a callback of start call, it will carry information of call state
function callStateNotify(data){
    ctdCallId = data.param.callId;
    ctdNotifyFuncs[0](data);
}



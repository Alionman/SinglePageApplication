app.controller("exceptionController", function($rootScope, $scope) {
	/*加载当前页时标记tab状态*/
	$rootScope.tab = 7;
    ConnectExceptionChannal();
});

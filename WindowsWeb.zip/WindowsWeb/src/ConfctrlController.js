app.controller("confctrlController", function($rootScope, $scope) {
    $rootScope.tab = 6;
    //Automatically loads the callback of the confctrlMgr transfer
    uiSetBasicConfEvent();
    //Automatically loads the current date
    getNowFormatDate();
    //When the tab is switched, it remains on the original landing page
    if (sessionStorage.getItem("confTimer")) {
        $("#audioConfPannel").show();
        $("#confFullPannel").hide();
        uiMuteConf(0);
    }

    $("#bookConfInfo").hide();
    $(".bookConf").click(function() {
        $("#beforeBookConf").toggle();
        $("#bookConfInfo").toggle();
    });
    $("#submitConfInfo").click(function() {
        $("#beforeBookConf").show();
        $("#bookConfInfo").hide();
    });
    $("#startDelay").attr("checked", "checked");
    $("#startImmediate").click(function() {
        $("#bookTime").hide();
    });
    $("#startDelay").click(function() {
        $("#bookTime").show();
    });

    $("#testtt").click(function() {
        $("#testt").toggle();
    });
    $("#switchTerminalNum").click(function() {
        $("#terminalNumOption").toggle();
    });
    $("#moreChoose").click(function() {
        $("#moreChooseOption").toggle();
    });
    $("#setConfGroupName").click(function() {
        $("#confGroupName").val("Welcome to conference");
    });

    $("#uaccNumber").click(function() {
        var num = $("#uaccNumber").html();
        alert("calling " + num);
    });

    //This function is used to get the meeting list
    $scope.page = 1;
    $scope.uiGetConfList = function() {
        getConfList({
            account_id: (sessionStorage.getItem("solutionType") == "PBX") ? authNumber : "",
            conf_id: "",
            subject: "",
            conf_right: 2,
            include_end: 0,
            page_index: $scope.page,
            page_size: 13
        }, { onGetConfListResult: onGetConfList });
        $scope.page++;
    }

    //The meeting list will be presented on the page by passing the meeting list callback
    function onGetConfList(data) {
        $scope.confLists = data.param.conf_list_info || null;
        $scope.$digest();

        $scope.count = data.param.conf_count;
        if ($scope.count < 13) {
            $scope.page = 1;
        }
    }

    setTimeout(function() {
        $scope.uiGetConfList();
    }, 500);

    $scope.accessNumber = 0;
    $scope.chairmanPwd = 0;
    $scope.generalPwd = 0;

    function confListInfo(index) {
        confInfo = $scope.confLists;
        $scope.accessNumber = confInfo[index].access_number;
        $scope.chairmanPwd = confInfo[index].chairman_pwd;
        $scope.confId = confInfo[index].conf_id;
        $scope.confState = confInfo[index].conf_state;
        $scope.confSubject = confInfo[index].conf_subject;
        $scope.cycleConfId = confInfo[index].cycle_conf_id;
        $scope.startTime = confInfo[index].start_time; 
        $scope.generalPwd = confInfo[index].general_pwd;
        $scope.mediaType = confInfo[index].media_type;
        $scope.scheduserName = confInfo[index].scheduser_name;
        $scope.scheduserNumber = confInfo[index].scheduser_number;
        $scope.size = confInfo[index].size;
        $scope.endTime = confInfo[index].end_time;
        $scope.$digest();
    }

    function onGetConfInfo(data) {
        $scope.confInfoRes = data.param.get_conf_info_result || null;
        $scope.chairmanPwd = $scope.confInfoRes.conf_list_info.chairman_pwd;
        $scope.generalPwd = $scope.confInfoRes.conf_list_info.general_pwd;
        $scope.mediaType = $scope.confInfoRes.conf_list_info.media_type;
        var attArray = $scope.confInfoRes.attendee;
        $scope.count = $scope.confInfoRes.num_of_addendee;
        var array = new Array();
        for (var i = 0; i < $scope.count; i++) {
            array[i] = attArray[i].number;
        }
        $scope.attendees = array.join(",");
        $scope.$digest();
    }

    $scope.uiRequestChairman = function(){
        requestChairman($scope.chairmanPwd, authNumber, {
            onReqChairmanResult:onReqChairmanResultInd,
            onEnterPasswordToBeChairman:onEnterPasswordToBeChairmanInd
        })
    }

    function onReqChairmanResultInd(data){

    }

    function onEnterPasswordToBeChairmanInd(data){

    }

    $scope.uiReleaseChairman = function(){
        releaseChairman(authNumber, {
            onReleaseChairmanResult:onReleaseChairmanResultInd
        })
    }

    function onReleaseChairmanResultInd(data){
        
    }

    //This function is used for a typing entry
    $scope.uiEnterReservedConf = function() {
        var accessCode = "";
        if ($scope.chairmanPwd) {
            accessCode = $scope.accessNumber + "*" + $scope.chairmanPwd + "#";
        } else {
            accessCode = $scope.accessNumber + "*" + $scope.generalPwd + "#";
        }
        if (sessionStorage.getItem("solutionType") == "PBX") {
            startConfCall(accessCode.toString());
        } else if (sessionStorage.getItem("solutionType") == "EC") {
            var call_id = 0;
            var call_type = 0;
            var pstconfparam = {
                "confid": $scope.confId,
                "access_code": $scope.accessNumber,
                "conf_paswd": $scope.chairmanPwd != "******" ? $scope.chairmanPwd : $scope.generalPwd
            };
            accessReservedConfEx(call_id, call_type, pstconfparam);
        } else {

        }
        $scope.closePage();
    }

    //This function is used to display and close the meeting information
    $scope.showInfo = function(index) {
        getConfInfo({ conf_id: $scope.confLists[index].conf_id, page_index: 1, page_size: 20 }, { onGetConfInfoResult: onGetConfInfo })
        var bh = $("body").height();
        var bw = $("body").width();
        $("#backPage").css({
            height: bh * 0.845,
            width: bw * 0.925,
            display: "block"
        });
        $("#upperPage").show();
        setTimeout(function() {
            confListInfo(index);
        }, 500);
    }

    $scope.closePage = function() {
        $("#backPage,#upperPage").hide();
    }

    //This function is used to set the method to load the confctrlMgr callback
    function uiSetBasicConfEvent() {
        setBasicConfEvent({
            onConfConnectedInd: confConnectedInd,
            onBeTransToConfInd: beTransToConfInd,
            onConfIncomingInd: confIncomingInd,
            onAttendeeListUpdate: attendeeListUpdate,
            onConfInfoInd: confInfoInd,
            onFloorAttendeeInd: floorAttendeeInd,
            onEndConfInd: endConfInd,
            onAddDataConfInd: addDataConfInd,
            onConfRhghtResult: confRhghtResult
        });
    }
    function confConnectedInd(data) {

    }
    function beTransToConfInd(data) {
        $("#confFullPannel").hide();
        $("#audioConfPannel").show();

    }

    var dataConfUrl = "";
    var dataConfId = "";
    var dataRandom = "";
    var dataPassword = "";
    function confInfoInd(data) {
        // $scope.participants = showAttendeeDB();
        // setTimeout(function(){
        //    for(var i = 0;i<$scope.participants.length;i++){
        //        deleteAttendeeDB($scope.participants[i].participant_id);
        //    }
        // },500);
        $("#confFullPannel").hide();
        $("#audioConfPannel").show();
        confTiming();
        if (sessionStorage.getItem("solutionType") == "PBX") {
            dataConfUrl = data.param.conf_info.dateconf_uri;
        }
        dataConfId = data.param.conf_info.conf_id;
        dataRandom = data.param.conf_info.data_random;
        dataPassword = data.param.conf_info.password;
        var mediaType = data.param.conf_info.media_type;
        var dataHandle = data.param.handle;
        if (mediaType == 21) {
            uiGetDataconfParams();
        }else if(mediaType ==3){            
            $scope.videoConference = true;
            var localVideoView = $('#videoLocalCanvas')[0];
            var remoteVideoView = $('#videoRemoteCanvas')[0];
            setAllVideoView(localVideoView,remoteVideoView);
        }
    }

    function floorAttendeeInd(data) {
        var speakerCount = data.param.floor_attendee_info.num_of_speaker;
        if (speakerCount) {
            var speakers = data.param.floor_attendee_info.speaker;
            var speakerId = speakers[0].number;
            for (var i = 0; i < $scope.participants.length; i++) {
                if ($scope.participants[i].number == speakerId) {
                    $("#confAttendeeTable tr td[class='displayConfSpeaker']").eq(i).show();
                }
            }
        } else {
            for (var j = 0; j < $scope.participants.length; j++) {
                $("#confAttendeeTable tr td[class='displayConfSpeaker']").eq(j).hide();
            }
        }
        $scope.$digest();
    }

    function endConfInd(data) {
        endtimer();
        $("#confFullPannel").show();
        $("#audioConfPannel").hide();
        $("#confIncomingTable").hide();
        $("#noConfAtNow").show();
        $scope.participants = showAttendeeDB();
        setTimeout(function(){
           for(var i = 0;i<$scope.participants.length;i++){
               deleteAttendeeDB($scope.participants[i].participant_id);
           }
        },500);
        $scope.uiGetConfList();
    }

    function confIncomingInd(data) {
        $("#confIncomingTable").show();
        $("#noConfAtNow").hide();
    }

    //Push the participant list information, the page renders the member list and the member's ability and attributes
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = null;
    var authNumber = null;
    if (authorize_result != undefined && authorize_result != null) {
        authorizeResult = JSON.parse(authorize_result);
        authNumber = parseInt(authorizeResult.sip_impi) + "";
        sessionStorage.setItem("authNumber", authNumber);
    }
    var confIndex = -1;
    $scope.participants = new Array();
    function attendeeListUpdate(data) {
        var participantsDB = data.param.conf_status.participants;
        if(participantsDB != null){
            for (var k = 0; k < participantsDB.length; k++) {
                var attendeeDB = null;
                attendeeDB = {
                    "is_deaf": participantsDB[k].is_deaf,
                    "is_mute": participantsDB[k].is_mute,
                    "is_self": participantsDB[k].is_self,
                    "media_type": participantsDB[k].media_type,
                    "name": participantsDB[k].name,
                    "number": participantsDB[k].number,
                    "participant_id": participantsDB[k].participant_id,
                    "role": participantsDB[k].role,
                    "state": participantsDB[k].state,
                }
                if(0 == participantsDB[k].state){
                    addAttendeeDB(attendeeDB);
                }
                
            }
            $scope.$digest();
            if (startAttendeeList != null) {
                endUpdateAttendeeList();
            }
            startUpdateAttendeeList();
            for (var i = 0; i < participantsDB.length; i++) {

                if (participantsDB[i].is_self == 1) {
                    confIndex = i;
                    if (data.param.conf_status.is_all_mute) {
                        $("#unmuteConf").show();
                        $("#muteConf").hide();
                    } else {
                        $("#muteConf").show();
                        $("#unmuteConf").hide();
                    }
                    //Identifies whether the conference is locked
                    if (data.param.conf_status.lock_state) {
                        $("#chairmanunLockConf").show();
                        $("#chairmanLockConf").hide();
                    } else {
                        $("#chairmanLockConf").show();
                        $("#chairmanunLockConf").hide();
                    }
                }

            }
        
            if (confIndex != -1 && participantsDB[confIndex].is_mute) { 
                $("#confAttendeeTable tr td[class='muteAttendee']").eq(confIndex).hide();
                $("#confAttendeeTable tr td[class='unmuteAttendee']").eq(confIndex).show();
            } else {
                $("#confAttendeeTable tr td[class='muteAttendee']").eq(confIndex).show();
                $("#confAttendeeTable tr td[class='unmuteAttendee']").eq(confIndex).hide();
            }
            $scope.$digest();
        }else{

        }

    }
    //This function is used to automatically update the meeting list
    var startAttendeeList;
    function startUpdateAttendeeList() {
        $scope.participants = showAttendeeDB();
        startAttendeeList = setInterval(function() {
            for (var i = 0; i < $scope.participants.length; i++) {
                if ($scope.participants[i].role) {
                    $("#confAttendeeTable tr td[class='chairmanAttendee']").eq(i).show();
                    $("#confAttendeeTable tr td[class='normalAttendee']").eq(i).hide();
                    $("#confAttendeeTable tr td[class='removeConfAttendee']").eq(i).hide();
                }
                //Shows whether it is a data meeting member
                if ($scope.participants[i].dataconf_userid != null) {
                    $("#confAttendeeTable tr td[class='dataConfUser']").eq(i).show();
                }
                //Speaker logo
                if ($scope.participants[i].participant_type != null && 2 == $scope.participants[i].participant_type) {
                    $("#confAttendeeTable tr td[class='dataConfPresenter']").eq(i).show();
                    $("#screenShare").show();
                }
                if ($scope.participants[i].state == 3) { 
                    $("#confAttendeeTable tr td[class='displayAttendeeState']").eq(i).show();
                }
                if ($scope.participants[i].is_self == 1) { 
                    confIndex = i;
                    if ($scope.participants[i].role) {
                        $("#addAttendeeNumber").show();
                        $("#confAttendeeTable .removeConfAttendee").show();
                        $("#confAttendeeTable .removeConfAttendee").eq(i).hide();
                        $("#chairmanEndConf").show();
                        $("#chairmanPostponeConf").show();
                        $("#switchMediaType").show();
                        for (var j = 0; j < $scope.participants.length; j++) {
                            if ($scope.participants[j].is_mute) { 
                                $("#confAttendeeTable tr td[class='muteAttendee']").eq(j).hide();
                                $("#confAttendeeTable tr td[class='unmuteAttendee']").eq(j).show();
                            } else {
                                $("#confAttendeeTable tr td[class='muteAttendee']").eq(j).show();
                                $("#confAttendeeTable tr td[class='unmuteAttendee']").eq(j).hide();
                            }
                        }
                    }
                }
                if ($scope.participants[i].media_type > 16) {
                    $("#confAttendeeTable tr td[class='dataConfUser']").eq(i).show();
                }
            }
            $scope.$digest();
        }, 1000);
    }

    function endUpdateAttendeeList() {
        clearInterval(startAttendeeList);
    }

    //This function is used to mute attendees
    var isAttendeeMuted = 1;
    $scope.uiMuteAttendee = function(index) {
        confIndex = index;
        var attNum = $scope.participants[index].number;
        if (isAttendeeMuted) {
            muteAttendee(isAttendeeMuted, attNum);
            isAttendeeMuted = 0;
        } else {
            muteAttendee(isAttendeeMuted, attNum);
            isAttendeeMuted = 1;
        }
    }
    //This function is used to hang up attendees
    $scope.uiHangUpAttendee = function(index) {
        var attendeeNum = $scope.participants[index].number;
        hangUpAttendee(attendeeNum, {
            onHangupAttendeeResult:onHangupAttendee
        });
        removeAttendee(attendeeNum,{onDelAttendeeResult:onDelAttendeeResult});
        if ($scope.participants[index].dataConfUserID) {
            var userid = $scope.participants[index].dataConfUserID;
            console.log("The data meeting has left" + userid);
            ConfUserKickout(userid);
        }

        function onHangupAttendee(data){}
    
        function onDelAttendeeResult(data){
        if(0 == data){           
            for(var i = 0;i<$scope.participants.length;i++){
                if(attendeeNum == $scope.participants[i].number){
                    deleteAttendeeDB($scope.participants[i].participant_id);
                }
            }
        } 
        $scope.participants = showAttendeeDB();
        $scope.$digest();
        }
    }

    //This function is used to upgrade to a data conference
    $scope.uiUpgradeConf = function() {
        upgradeConf();
    }
    var dataHandle = 0;
    function addDataConfInd(data) {
        uiGetDataconfParams();
        dataHandle = data.param.handle;
    }
    //EC upgrade data conference
    function confRhghtResult(data) {
        dataConfUrl = data.param.request_confctrl_right_result.dataconf_uri;
    }
    //Get the data conference parameter interface
    function uiGetDataconfParams() {
        var confParams = {
            conf_url: dataConfUrl,
            mcu_addr: { server_addr: "", server_port: 0 },
            random: dataRandom,
            passcode: dataPassword,
            sip_mun: authNumber,
            conf_id: dataConfId,
            password: dataPassword,
            type: (sessionStorage.getItem("solutionType") == "PBX") ? 1 : 3
        }; 
        getDataconfParams(confParams, {
            onConfParamsResult: confParamsResult
        });
    }

    var dataConfUserid = 0;
    function confParamsResult(data) {
        if (data.param.result == 0) {
            var hostKey = data.param.conf_params.host_key;
            var title = "subject";
            var userId = data.param.conf_params.user_id;
            dataConfUserid = parseInt(userId);
            var option = 4096;
            var siteId = data.param.conf_params.site_id;
            var userType = data.param.conf_params.user_role;
            var siteUrl = data.param.conf_params.cm_address;
            var serverIp = data.param.conf_params.server_ip;
            var serverInterip = "";
            //sbc Gateway
            // var serverIp = data.param.conf_params.sbc_server_address;
            // var serverInterip = data.param.conf_params.server_ip;           
            var encryptionKey = data.param.conf_params.crypt_key;
            var confId = data.param.conf_params.conf_id;
            var userCapability = 2046;
            var handle = dataHandle;
            var userName = "mao";
            var logUrl = authNumber;
            var userM = data.param.conf_params.M;
            var userT = data.param.conf_params.T;

            CreateConference(title, option, Number(userType), Number(userId), userName, hostKey, Number(confId), encryptionKey, siteId,
                siteUrl, serverIp, serverInterip,userCapability, Number(handle), logUrl, userM, userT, { response: onConferenceNewResult });
        } else {
            alert("Upgrade failed");
        }
    }

    // This function is used to replay attendees and attendees raise their hands after canceling their hands
    $scope.uiCallAttendee = function(index){
    	var attendeeNum = $scope.participants[index].participant_id;
    	callAttendee(attendeeNum);
    }

    $scope.uiHandup = function(){
    	handup("", 1, {
            onHandUpResult:onHandUpResultInd
        });
    }

    function onHandUpResultInd(data){

    }

    $scope.uiHanddown = function(index){
    	var attNum = $scope.participants[index].participant_id;
    	handup(attNum, 0, {
            onHandUpResult:onHandUpResultInd
        });
    }

    $scope.setConfMode = function() {

        setConfMode(2);
    }

    $scope.broadcastAttendee = function() {

        param = 
        {
            "conf_handle": 123,
            "to_broadcast": 1,
            "attendee_vc":
            {
                "mcu_num":12,
                "terminal_num":10
            }
        }
        broadcastAttendee(param);
    }

    $scope.watchAttendee = function() {

        param = 
        {
            "conf_handle": 123,
            "conf_id": "3215"
        }
        watchAttendee(param);
    }

    //This function is used to leave the meeting
    $scope.uiLeaveConf =function() {
        leaveConf();
        endtimer();
        $scope.participants = showAttendeeDB();
        setTimeout(function(){
            for(var i = 0;i<$scope.participants.length;i++){
                deleteAttendeeDB($scope.participants[i].participant_id);
            }
        },500);   
        //Leave the data meeting
        LeaveConference({ response: onuserLeaveResult });
        $("#confFullPannel").show();
        $("#audioConfPannel").hide();
        sessionStorage.removeItem("lock");
        sessionStorage.removeItem("callerNum");
        sessionStorage.removeItem("meetingAttendeeList");
    }

    function onuserLeaveResult(data) {
        setTimeout(function() {
            window.location.reload();
        }, 1500);
    }

     //This function is used to end the conference  
    $scope.uiEndConf = function() {
        $scope.participants = showAttendeeDB();
        setTimeout(function(){
        for(var i = 0;i<$scope.participants.length;i++){
            deleteAttendeeDB($scope.participants[i].participant_id);
        }
        },500);   
        endConf({
            onEndConfResult: endConfResult
        });
        TerminateConference({ response: onconfTerminateResult });
    }

    function onconfTerminateResult(data) {
        setTimeout(function() {
            window.location.reload();
        }, 1500);
    
    }
    $scope.MeetingPageShow = true;
    $scope.confSeachShow = true;
    $scope.screenShow = 0;
    $scope.videoConference = false;

    if (sessionStorage.meetingConfHandle != null && sessionStorage.meetingConfHandle != '' && sessionStorage.meetingConfHandle != undefined) {
        $scope.MeetingPageShow = false;
    }

    $scope.SVNVersion = "20170508-0858_svn17658_json";
    $scope.meetingTitle = "DataConf"; 
    $scope.meetingOption = 4096; 
    $scope.meetingUserType = 3; 
    $scope.meetingUserID = 155; 
    $scope.meetingUserName = "ding"; 
    $scope.meetingHostKey = 456; 
    $scope.meetingConfID = 8; 
    $scope.meetingEncryptionKey = "123"; 
    //Screen sharing
    $scope.imgScreenSrc = "bin/img/headimg/0.png"; 
    $scope.imgDSSrc = "bin/img/confctrl/loading.gif"; 
    //Document sharing
    $scope.meetingCurrentPage = parseInt(sessionStorage.meetingPageId) || 0; 
    $scope.meetingDSannotation = 0;
    $scope.localIndex = 0;
    $scope.meetingtype = 0;
    $scope.subtype = 0;
    $scope.pString = ""; 
    $scope.canvasX = 0;
    $scope.canvasY = 0;
    $scope.confSync = 1;
    $scope.annoid = 0; 
    $scope.annoidType = 0; 

    $scope.meetingBasicEvent = function() {
        setBasicMeetingEvent({
            onUserEnterInd: onUserEnterInd,
            onuserLeaveKickout: onuserLeaveKickout,
            onConfLeave: onConfLeave,
            onConfTerminate: onConfTerminate,
            onAsOnSharingSession: onAsOnSharingSession,
            onAsOnScreenData: onAsOnScreenData,
            onAsOnSharingState: onAsOnSharingState,
            onDocNew: onDocNew,
            onPageNew: onPageNew,
            onCurrentPageInd: onCurrentPageInd,
            onDocDel: onDocDel,
            onPageDel: onPageDel,
            onWbDocDel: onWbDocDel,
            onWbPageDel: onWbPageDel,
            onDrawDataNotify: onDrawDataNotify,
            onWbdrawDataNotify: onWbdrawDataNotify,
            hostChangeInd: hostChangeInd,
            onPresenterChangeInd: onPresenterChangeInd,
            onAsSaveResult: onAsSaveResult,
            onWbCurrentPageInd: onWbCurrentPageInd,
            onAsOnJsonGetParam: onAsOnJsonGetParam

        });
    }

    function onUserEnterInd(data) {
        updateAttendDB(data.user_alt_uri, data.user_alt_id, data.user_name);
        startUpdateAttendeeList();
        $scope.$digest();
    }

    function onuserLeaveKickout(data) {
        alert("You have left the meeting");
        sessionStorage.removeItem("meetingAttendeeList");
        $scope.MeetingPageShow = true;
        $scope.$digest();
    }

    function onConfTerminate(data) {
        sessionStorage.removeItem("meetingAttendeeList");
        $scope.MeetingPageShow = true;
    }

    function onConfLeave(data) {
        console.log("Data meeting members leave");
        $scope.$digest();
    }

    function onAsOnSharingSession(data) {
        alert("The desktop shared channel is open");
    }

    var i = 0;
    function onAsOnScreenData(data) {
        $scope.screenShow = 2;
        $scope.imgScreenSrc = "file:/" + data.filepath;
        console.log("Screen sharing in transmission");
        $scope.$digest();
    }

    function onAsOnSharingState(data) {
        if (data.value2 == 2) {
            alert("The shared side starts sharing");
            console.log("Screen sharing in crawl.");

            for (i = 0; i < $scope.participants.length; i++) {
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeSet']").eq(i).show();
            }
            $scope.screenShow = 1;
            $scope.$digest();
        } else if (data.value2 == 0) {
            alert("Shared end end sharing");
            console.log("The screen sharing has ended.");
            for (i = 0; i < $scope.participants.length; i++) {
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeSet']").eq(i).hide();
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeRevoke']").eq(i).hide();
            }
            $scope.screenShow = 0;
            $scope.$digest();
        } else if (data.value2 == 1) {
            alert("Watch the viewing side");
            console.log("Watching");
            $scope.screenShow = 2;
            $scope.$digest();
        }
    }

    function onDocNew(data) {

    }

    function onPageNew(data) {
        $scope.screenShow = 3;
        $scope.$digest();
    }

    function onCurrentPageInd(data) {
        $scope.meetingCurrentPage = data.value2;
        $scope.$digest();
    }

    function onDocDel(data) {
        $scope.screenShow = 0;
        $scope.$digest();
        alert("Document sharing stopped");
    }

    function onPageDel(data) {

    }

    function onWbDocDel(data) {
        $scope.screenShow = 0;
        $scope.$digest();
        alert("Whiteboard sharing has stopped");
    }

    function onWbPageDel(data) {

    }

    function onDrawDataNotify(data) {
        if (data.value2 != 0) {
            $scope.imgDSSrc = "file:/" + data.filepath;
            $scope.$digest();
        }
    }

    function onWbdrawDataNotify(data) {

    }

    function hostChangeInd(data) {
        //Moderator changes
        console.log("host has changed" + data.value2);
        $scope.$digest();
    }

    function onPresenterChangeInd(data) {
        //The speaker changes
        console.log("presenter has changed" + data.value2);
        for (i = 0; i < $scope.participants.length; i++) {
            if ($scope.participants[i].dataconf_userid == data.value2) {
                //Add a data conference moderator logo
                updateAttendPresenterDB($scope.participants[i].participant_id, 2);
                startUpdateAttendeeList();
            }
        }
        $scope.$digest();
    }

    var i = 1;
    function onAsSaveResult(data) {
        if (data.result == 0) {
            $scope.screenShow = 2;
            $scope.$digest();
        }
    }

    function onWbCurrentPageInd(data) {
        $scope.meetingCurrentPage = data.value2;
        $scope.$digest();
    }

    $scope.meetingNew = function() {
        CreateConference($scope.meetingTitle, parseInt($scope.meetingOption), parseInt($scope.meetingUserType), parseInt($scope.meetingUserID), $scope.meetingUserName, $scope.meetingHostKey, parseInt($scope.meetingConfID), $scope.meetingEncryptionKey, "CN30", "huawei", "10.173.19.53", 0, 0, 0, { response: onConferenceNewResult });
    }

    function onConferenceNewResult(data) {
        if (data == 0) {
            $scope.MeetingPageShow = false;
            $scope.$digest();
        } else {
            alert("Failed to create a meeting");
        }
    }

    function onjoinConferenceResult(data) {
        if (data == 0) {
            // $scope.MeetingPageShow = false;
            // $scope.$digest();
        } else {
            alert("Failed to join meeting");
        }
    }

    //This function is used to terminate the meeting
    $scope.TerminateConference = function() {
        TerminateConference({ response: onconfTerminate });
    }

    function onconfTerminate(data) {
        console.log("The data meeting has ended");
    }

    //This function is used to leave the meeting
    $scope.LeaveConference = function() {
        LeaveConference({ response: onuserLeave });
    }

    function onuserLeave(data) {
        console.log("Leave the data conference");
    }

    function onAsOnJsonGetParam(data) {
        var pappwnd = diagSelectAPP(data);
        if (pappwnd) {
            $scope.ConfSetsharingapp(parseInt(pappwnd));
        } else {
            alert("Please open the program first");
        }
        console.log("Program parameters:" + data);
    }

    //This function is used to kick the attendees
    $scope.ConfUserKickout = function(userid) {
        ConfUserKickout(userid);
    }

    //This function is used to set the user role
    $scope.ConfUserSetRole = function(index) {
        var userid = $scope.participants[index].dataConfUserID;
        ConfUserSetRole(2, userid);
    }

    //This function is used to request a user role
    $scope.ConfUserRequestRole = function(roleType) {
        var rolePassword = "";
        if (roleType == 1) {
            ConfUserGetHost();
            rolePassword = diagRequestHost();
        } else {

        }
        ConfUserRequestRole(roleType, rolePassword);
    }

    //This function is used to set the cancel conference lock
    $scope.ConfLock = function() {
        ConfLock();
    }

    //This function is used to set the cancellation of the conference
    $scope.ConfMute = function() {
        ConfMute();
    }

    //This function is used to start screen sharing
    $scope.ConfAsStart = function(sharingtype) {
        sessionStorage.sharingtype = sharingtype;
        ConfAsStart(dataConfUserid);
    }

    //This function is used to select the shared program and start the program share
    $scope.ConfSetsharingapp = function(pappwnd) {
        ConfSetsharingapp(pappwnd);
    }

    //This function is used to end the screen sharing
    $scope.ConfAsStop = function() {
        ConfAsStop(dataConfUserid);
    }

    //This function is used to grant remote control
    $scope.ASprivilege = 0;
    $scope.ConfAsSetPrivilege = function(privilege, action, index) {
        if (privilege == 1 && action == 1) {
            $scope.ASprivilege = 1;
            for (i = 0; i < $scope.participants.length; i++) {
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeSet']").eq(i).hide();
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeRevoke']").eq(i).show();
            }
        } else if (privilege == 1 && action == 0) {
            $scope.ASprivilege = 0;
            for (i = 0; i < $scope.participants.length; i++) {
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeSet']").eq(i).show();
                $("#confAttendeeTable tr td[class='confAsSetPrivilegeRevoke']").eq(i).hide();
            }
        }
        userid = $scope.participants[index].dataConfUserID;
        ConfAsSetPrivilege(privilege, action, userid);
    }

    //This function is used to start screen annotation
    $scope.ConfAsBeginAnnotation = function() {
        ConfAsBeginAnnotation();
    }

    //This function is used to end the screen annotation
    $scope.ConfAsEndAnnotation = function() {
        ConfAsEndAnnotation();
    }

    //This function is used to start whiteboard sharing
    $scope.ConfDsNewDoc = function() {
        ConfDsNewDoc({ onWbDocNew: onWbDocNew });
    }

    function onWbDocNew(data) {
        $scope.screenShow = 5;
        $scope.$digest();
    }

    //This function is used to end whiteboard sharing
    // $scope.ConfDsNewDoc = function() {
    //     ConfDsNewDoc();
    // }

    //This function is used to start document sharing
    $scope.ConfDsOpen = function() {
        var DSSrc = diagInputSrc();
        ConfDsOpen(DSSrc, { response: dsOpenResult });
    }

    function dsOpenResult(data) {
        $scope.screenShow = 3;
        $scope.$digest();
    }

    $scope.nextMeetingInfo = function() {
        $scope.meetingCurrentPage = $scope.meetingCurrentPage + 1;
        dsSetCurrentPage($scope.meetingCurrentPage, parseInt(sessionStorage.meetingDOCId), 1, $scope.confSync, { response: onSetCurrentPageResult, onCurrentPage: onCurrentPage });
    }

    $scope.preMeetingInfo = function() {
        $scope.meetingCurrentPage = ($scope.meetingCurrentPage - 1) <= 0 ? 1 : ($scope.meetingCurrentPage - 1);
        dsSetCurrentPage($scope.meetingCurrentPage, parseInt(sessionStorage.meetingDOCId), 1, $scope.confSync, { response: onSetCurrentPageResult, onCurrentPage: onCurrentPage });
    }

    function onSetCurrentPageResult(data) {
        $scope.meetingCurrentPage = parseInt(sessionStorage.meetingPageId);
        $scope.$digest();
        alert("Has been in the end!");
    }

    function onCurrentPage(data) {
        $scope.imgDSSrc = "bin/img/confctrl/loading.gif";
        $scope.$digest();
    }

    function onWBCurrentPage(data) {
        $scope.imgDSSrc = "bin/img/confctrl/loading.gif";
        $scope.$digest();
    }

    //This function is used for participants to synchronize document sharing data
    $scope.dsGetSyncinfo = function() {
        $scope.confSync = 1;
        dsGetSyncinfo({ onDsSyncInfo: onDsSyncInfo });
    }

    function onDsSyncInfo(data) {
        console.log("Synchronization is successful");
    }

    //This function is used to end document sharing
    $scope.confDsClose = function() {
        ConfDsClose();
    }

    $scope.confWBClose = function() {
        ConfDsDeleteDoc();
    }

    //Annotated
    $scope.annotationCreateStart = function(point, subtype, ciid, type) {
        annotationCreateStart(point, subtype, ciid, type);
    }

    $scope.annotationCreateUpdate = function(ciid, pdata) {
        annotationCreateUpdate(ciid, pdata);
    }

    $scope.annotationCreateDone = function(ret_annoid, ciid, bCancel) {
        annotationCreateDone(ret_annoid, ciid, bCancel);
    }

    //Local page
    $scope.confPageSync = function(isSync) {
        $scope.confSync = isSync;
    }

    //annotation switch
    $scope.annotationSwitch = function(annotation) {
        switch (annotation) {
            case 0:
                $scope.meetingDSannotation = 0;
                $scope.annoidType = 1;
                break;
            case 1:
                $scope.meetingDSannotation = 1;
                $scope.annoidType = 1;
                break;
            case 2:
                $scope.meetingDSannotation = 2;
                $scope.annoidType = 1;
                break;
            case 3:
                if ($scope.meetingDSannotation == 20) {
                    annotationSetselect(0, $scope.annoidType, $scope.annoid);
                    $scope.meetingDSannotation = 3;
                } else {
                    $scope.meetingDSannotation = 3;
                }
                $scope.annoidType = 1;
                break;
            case 4:
                $scope.meetingDSannotation = 4;
                $scope.annoidType = 1;
                break;
            case 5:
                $scope.meetingDSannotation = 5;
                $scope.subtype = 1;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 6:
                $scope.meetingDSannotation = 6;
                $scope.subtype = 2;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 7:
                $scope.meetingDSannotation = 7;
                $scope.subtype = 3;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 8:
                $scope.meetingDSannotation = 8;
                $scope.subtype = 4;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 9:
                $scope.meetingDSannotation = 9;
                $scope.subtype = 10;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 10:
                $scope.meetingDSannotation = 10;
                $scope.subtype = 11;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 11:
                $scope.meetingDSannotation = 11;
                $scope.subtype = 12;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 12:
                $scope.meetingDSannotation = 12;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 0;
                $scope.annoidType = 1;
                break;
            case 13:
                $scope.meetingDSannotation = 13;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 1;
                $scope.annoidType = 1;
                break;
            case 14:
                $scope.meetingDSannotation = 14;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 2;
                $scope.annoidType = 1;
                break;
            case 15:
                $scope.meetingDSannotation = 15;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 3;
                $scope.annoidType = 1;
                break;
            case 16:
                $scope.meetingDSannotation = 16;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 4;
                $scope.annoidType = 1;
                break;
            case 17:
                if ($scope.meetingDSannotation == 17) {
                    annotationLaserpointerStop(1);
                } else {
                    $scope.meetingDSannotation = 17;
                }
                $scope.annoidType = 1;
                break;
            case 18:
                $scope.meetingDSannotation = 18;
                $scope.annoidType = 1;
                break;

            case 30:
                $scope.meetingDSannotation = 30;
                $scope.annoidType = 512;
                break;
            case 31:
                $scope.meetingDSannotation = 31;
                $scope.annoidType = 512;
                break;
            case 32:
                $scope.meetingDSannotation = 32;
                $scope.annoidType = 512;
                break;
            case 33:
                if ($scope.meetingDSannotation == 50) {
                    annotationSetselect(0, 512, $scope.annoid);
                    $scope.meetingDSannotation = 33;
                } else {
                    $scope.meetingDSannotation = 33;
                }
                $scope.annoidType = 512;
                break;
            case 34:
                $scope.meetingDSannotation = 34;
                $scope.annoidType = 512;
                break;
            case 35:
                $scope.meetingDSannotation = 35;
                $scope.subtype = 1;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 36:
                $scope.meetingDSannotation = 36;
                $scope.subtype = 2;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 37:
                $scope.meetingDSannotation = 37;
                $scope.subtype = 3;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 38:
                $scope.meetingDSannotation = 38;
                $scope.subtype = 4;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 39:
                $scope.meetingDSannotation = 39;
                $scope.subtype = 10;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 40:
                $scope.meetingDSannotation = 40;
                $scope.subtype = 11;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 41:
                $scope.meetingDSannotation = 41;
                $scope.subtype = 12;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 42:
                $scope.meetingDSannotation = 42;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 0;
                $scope.annoidType = 512;
                break;
            case 43:
                $scope.meetingDSannotation = 43;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 1;
                $scope.annoidType = 512;
                break;
            case 44:
                $scope.meetingDSannotation = 44;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 2;
                $scope.annoidType = 512;
                break;
            case 45:
                $scope.meetingDSannotation = 45;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 3;
                $scope.annoidType = 512;
                break;
            case 46:
                $scope.meetingDSannotation = 46;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 4;
                $scope.annoidType = 512;
                break;
            case 47:
                if ($scope.meetingDSannotation == 47) {
                    annotationLaserpointerStop(512);
                } else {
                    $scope.meetingDSannotation = 47;
                }
                $scope.annoidType = 512;
                break;
            case 48:
                $scope.meetingDSannotation = 48;
                $scope.annoidType = 512;
                break;

            case 60:
                $scope.meetingDSannotation = 60;
                $scope.annoidType = 2;
                break;
            case 61:
                $scope.meetingDSannotation = 61;
                $scope.annoidType = 2;
                break;
            case 62:
                $scope.meetingDSannotation = 62;
                $scope.annoidType = 2;
                break;
            case 63:
                if ($scope.meetingDSannotation == 80) {
                    annotationSetselect(0, 2, $scope.annoid);
                    $scope.meetingDSannotation = 63;
                } else {
                    $scope.meetingDSannotation = 63;
                }
                $scope.annoidType = 2;
                break;
            case 64:
                $scope.meetingDSannotation = 64;
                $scope.annoidType = 2;
                break;
            case 65:
                $scope.meetingDSannotation = 65;
                $scope.subtype = 1;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 66:
                $scope.meetingDSannotation = 66;
                $scope.subtype = 2;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 67:
                $scope.meetingDSannotation = 67;
                $scope.subtype = 3;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 68:
                $scope.meetingDSannotation = 68;
                $scope.subtype = 4;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 69:
                $scope.meetingDSannotation = 69;
                $scope.subtype = 10;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 70:
                $scope.meetingDSannotation = 70;
                $scope.subtype = 11;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 71:
                $scope.meetingDSannotation = 71;
                $scope.subtype = 12;
                $scope.meetingtype = 12;
                $scope.annoidType = 2;
                break;
            case 72:
                $scope.meetingDSannotation = 72;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 0;
                $scope.annoidType = 2;
                break;
            case 73:
                $scope.meetingDSannotation = 73;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 1;
                $scope.annoidType = 2;
                break;
            case 74:
                $scope.meetingDSannotation = 74;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 2;
                $scope.annoidType = 2;
                break;
            case 75:
                $scope.meetingDSannotation = 75;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 3;
                $scope.annoidType = 2;
                break;
            case 76:
                $scope.meetingDSannotation = 76;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 4;
                $scope.annoidType = 2;
                break;
            case 77:
                if ($scope.meetingDSannotation == 77) {
                    annotationLaserpointerStop(2);
                } else {
                    $scope.meetingDSannotation = 47;
                }
                $scope.annoidType = 2;
                break;
            case 78:
                $scope.meetingDSannotation = 78;
                $scope.annoidType = 2;
                break;
            default:

        }
    }

    //This function is used to create text annotations (documents)
    $scope.annotationTextCreate = function(x, y, pString, ciid) {
        var pInfo = {
            "bounds": {
                "left": x,
                "top": y,
                "right": x + 1500,
                "bottom": y + 300
            },
            "pString": pString,
            "pFont": "宋体",
            "color": 255,
            "size": 240,
            "reserve": 0
        }
        annotationTextCreate(pInfo, 0, ciid);
    }

    $scope.annotationHittest = function(point) {
        annotationHittest(point, 0, $scope.annoidType, { onAnnoHittest: onAnnoHittest });
    }

    $scope.annotationTextGetinfo = function(ciid, annoid) {
        annotationTextGetinfo(ciid, annoid, { onAnnoTextGetInfo: onAnnoTextGetInfo });
    }

    function onAnnoTextGetInfo(data) {
        if (data.annoid) {
            var x = $scope.canvasX;
            var y = $scope.canvasY;
            var pInfo = {
                "bounds": {
                    "left": x,
                    "top": y,
                    "right": x + 1500,
                    "bottom": y + 300
                },
                "pString": diag($scope.pString),
                "pFont": "宋体",
                "color": 255,
                "size": 240,
                "reserve": 0
            }
            $scope.annotationTextUpdate($scope.annoidType, pInfo, parseInt(data.annoid));
        }
    }

    //Edit the label
    $scope.annotationTextUpdate = function(ciid, pInfo, annoid) {
        annotationTextUpdate(true, pInfo, ciid, annoid);
    }

    //Delete the text label
    $scope.annotationDelete = function(point, ciid) {
        annotationHittest(point, 0, ciid, { onAnnoHittest: onAnnoHittest });
    }

    function onAnnoHittest(data) {
        if (data.annoid != 0) {
            $scope.annoid = data.annoid;
            if ($scope.meetingDSannotation == 2 || $scope.meetingDSannotation == 32 || $scope.meetingDSannotation == 62) {
                annotationDelete($scope.annoidType, data.annoid);
            } else if ($scope.meetingDSannotation == 4 || $scope.meetingDSannotation == 34 || $scope.meetingDSannotation == 64) {
                $scope.annotationTextGetinfo($scope.annoidType, data.annoid);
            } else if ($scope.meetingDSannotation == 3) {
                //Confirmation here
                annotationSetselect(1, $scope.annoidType, data.annoid);
                $scope.meetingDSannotation = 20;
            } else if ($scope.meetingDSannotation == 33) {
                annotationSetselect(1, $scope.annoidType, data.annoid);
                $scope.meetingDSannotation = 50;
            } else if ($scope.meetingDSannotation == 63) {
                annotationSetselect(1, $scope.annoidType, data.annoid);
                $scope.meetingDSannotation = 80;
            }

        }
    }

    //This function is used to start the laser pen
    $scope.annotationLaserpointerStart = function() {
        AnnotationInit();
        annotationLaserpointerStart();
    }

    //This function is used to move the laser pointer
    $scope.annotationLaserpointerMoveto = function() {
        annotationLaserpointerMoveto();
    }

    //This function is used to end the laser pen
    $scope.annotationLaserpointerStop = function() {
        annotationLaserpointerStop();
    }

    $scope.ConfSeach = function() {
        if ($scope.confSeachShow) {
            $scope.confSeachShow = false;
        } else {
            $scope.confSeachShow = true;
        }
    }

    setTimeout(function() { meetingASBoard(); }, 2000);

    function meetingASBoard() {
        var c = document.getElementById("imgASCanvas");
        var ctx = c.getContext("2d");
        var imgDS = document.getElementById("screenShow");
        imgDS.onload = function() {
            ctx.drawImage(imgDS, 0, 0, 750, 650);
        }
        //Gets the coordinates of the current mouse
        c.onmousedown = function(e) {
            var x = e.clientX,
                y = e.clientY,
                left = this.parentNode.offsetLeft + 264,
                top = this.parentNode.offsetTop + 285,
                //There is a problem with the positioning of the coordinates, 
                //developers need to adjust according to their own resolution
                canvasX = (x - left) * 15,
                canvasY = (y - top) * 15; 
            $scope.canvasX = canvasX;
            $scope.canvasY = canvasY;
            // alert(left + "****" + x + "*****" + top + "****" + y + "***" + canvasX + "***" + canvasY);
            console.log(x + "===========" + y);
            // ConfAsInputWndMsg(513, 0, 0, { "x": canvasX, "y": canvasY });
            //To determine whether the remote control
            if ($scope.ASprivilege == 1) {
                ConfAsInputWndMsg(513, 0, 0, { "x": canvasX, "y": canvasY });
            }
            //To determine whether to operate the whiteboard
            if ($scope.meetingDSannotation == 61) {
                var pString = diag("");
                $scope.pString = pString;
                $scope.annotationTextCreate(canvasX, canvasY, pString, 2);
            } else if ($scope.meetingDSannotation == 62) {
                $scope.annotationDelete({ "x": canvasX, "y": canvasY }, 2);
            } else if ($scope.meetingDSannotation == 63) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation == 64) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation >= 65 && $scope.meetingDSannotation <= 71) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 2, $scope.meetingtype);
            } else if ($scope.meetingDSannotation >= 72 && $scope.meetingDSannotation <= 76) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 2, $scope.meetingtype);
            } else if ($scope.meetingDSannotation == 77) {
                annotationLaserpointerStart(512, { "x": canvasX, "y": canvasY }, { "cx": 28 * 15, "cy": 28 * 15 });
            } else if ($scope.meetingDSannotation == 80) {
                annotationEditStart($scope.annoid, 6, 2, { "x": $scope.canvasX, "y": $scope.canvasY }, $scope.annoid);
            }

            document.onmousemove = function(e) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left),
                        canvasY = (y - top); 
                    if ($scope.ASprivilege == 1) {
                        ConfAsInputWndMsg(512, 0, 0, { "x": canvasX, "y": canvasY });
                    }
                    if ($scope.meetingDSannotation == 63) {

                    } else if ($scope.meetingDSannotation >= 72 && $scope.meetingDSannotation <= 76) {
                        //Customize graphics
                        var pdata = {
                            "bLocal": 1,
                            "localIndex": $scope.localIndex,
                            "dispRect": {
                                "left": canvasX * 15 - 14 * 15,
                                "top": canvasY * 15 - 14 * 15,
                                "right": (canvasX + 28) * 15,
                                "bottom": (canvasY + 28) * 15
                            }
                        }
                        annotationCreateCustomerUpdate(2, pdata);
                    } else if ($scope.meetingDSannotation >= 65 && $scope.meetingDSannotation <= 71) {
                        // Geometric annotation
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationCreateDrawingUpdate(2, pdata);
                    } else if ($scope.meetingDSannotation == 77) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationLaserpointerMoveto(2, pdata);
                    } else if ($scope.meetingDSannotation == 80) {
                        annotationEditUpdate(2, { "x": canvasX * 15, "y": canvasY * 15 });
                    }
                }

            document.onmouseup = function(e) {
                var t = e.target;
                if (t == c) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left) * 15,
                        canvasY = (y - top) * 15; 
                    if ($scope.ASprivilege == 1) {
                        ConfAsInputWndMsg(514, 0, 0, { "x": canvasX, "y": canvasY });
                    }
                    if ($scope.meetingDSannotation >= 65 && $scope.meetingDSannotation <= 76) {
                        annotationCreateDone(0, 2, false);
                    } else if ($scope.meetingDSannotation == 77) {

                    } else if ($scope.meetingDSannotation == 63) {

                    } else if ($scope.meetingDSannotation == 80) {
                        annotationEditDone(false, 2);
                    }
                }
                this.onmousemove = null;
            }
        }
    }

    setTimeout(function() { meetingWhiteboard(); }, 2000);

    // This function is used for whiteboard sharing of document interface canvas operations
    function meetingWhiteboard() {
        var c = document.getElementById("imgWBCanvas");
        var ctx = c.getContext("2d");
        var imgDS = document.getElementById("DOCWBShow");
        imgDS.onload = function() {
            ctx.drawImage(imgDS, 0, 0);
        }

        c.onmousedown = function(e) {
            var x = e.clientX,
                y = e.clientY,
                left = this.parentNode.offsetLeft + 264,
                top = this.parentNode.offsetTop + 305,
                canvasX = (x - left) * 15,
                canvasY = (y - top) * 15; 
            $scope.canvasX = canvasX;
            $scope.canvasY = canvasY;
            if ($scope.meetingDSannotation == 31) {
                var pString = diag("");
                $scope.pString = pString;
                $scope.annotationTextCreate(canvasX, canvasY, pString, 512);
            } else if ($scope.meetingDSannotation == 32) {
                $scope.annotationDelete({ "x": canvasX, "y": canvasY }, 512);
            } else if ($scope.meetingDSannotation == 33) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation == 34) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation >= 35 && $scope.meetingDSannotation <= 41) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 512, $scope.meetingtype);
            } else if ($scope.meetingDSannotation >= 42 && $scope.meetingDSannotation <= 46) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 512, $scope.meetingtype);
            } else if ($scope.meetingDSannotation == 47) {
                annotationLaserpointerStart(512, { "x": canvasX, "y": canvasY }, { "cx": 28 * 15, "cy": 28 * 15 });
            } else if ($scope.meetingDSannotation == 50) {
                annotationEditStart($scope.annoid, 6, 512, { "x": $scope.canvasX, "y": $scope.canvasY }, $scope.annoid);
            }

            document.onmousemove = function(e) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left),
                        canvasY = (y - top); 
                    if ($scope.meetingDSannotation == 33) {

                    } else if ($scope.meetingDSannotation >= 42 && $scope.meetingDSannotation <= 46) {
                        var pdata = {
                            "bLocal": 1,
                            "localIndex": $scope.localIndex,
                            "dispRect": {
                                "left": canvasX * 15 - 14 * 15,
                                "top": canvasY * 15 - 14 * 15,
                                "right": (canvasX + 28) * 15,
                                "bottom": (canvasY + 28) * 15
                            }
                        }
                        annotationCreateCustomerUpdate(512, pdata);
                    } else if ($scope.meetingDSannotation >= 35 && $scope.meetingDSannotation <= 41) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationCreateDrawingUpdate(512, pdata);
                    } else if ($scope.meetingDSannotation == 47) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationLaserpointerMoveto(512, pdata);
                    } else if ($scope.meetingDSannotation == 50) {
                        annotationEditUpdate(512, { "x": canvasX * 15, "y": canvasY * 15 });
                    }
                }
            document.onmouseup = function(e) {
                var t = e.target;
                if (t == c) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left) * 15,
                        canvasY = (y - top) * 15; 
                    if ($scope.meetingDSannotation >= 35 && $scope.meetingDSannotation <= 46) {
                        annotationCreateDone(0, 512, false);
                    } else if ($scope.meetingDSannotation == 47) {

                    } else if ($scope.meetingDSannotation == 33) {

                    } else if ($scope.meetingDSannotation == 50) {
                        annotationEditDone(false, 512);
                    }
                }
                this.onmousemove = null;
            }
        }
    }

    setTimeout(function() { meetingDSBoard(); }, 500);
    function meetingDSBoard() {
        var c = document.getElementById("imgDSCanvas");
        var ctx = c.getContext("2d");
        var imgDS = document.getElementById("DOCShow");
        imgDS.onload = function() {
            ctx.drawImage(imgDS, 0, 0);
        }
        c.onmousedown = function(e) {
            var x = e.clientX,
                y = e.clientY,
                left = this.parentNode.offsetLeft + 264,
                top = this.parentNode.offsetTop + 285,
                canvasX = (x - left) * 15,
                canvasY = (y - top) * 15; 
            $scope.canvasX = canvasX;
            $scope.canvasY = canvasY;
            //To determine whether to operate the document
            if ($scope.meetingDSannotation == 1) {
                var pString = diag("");
                $scope.pString = pString;
                $scope.annotationTextCreate(canvasX, canvasY, pString, 1);

            } else if ($scope.meetingDSannotation == 2) {
                $scope.annotationDelete({ "x": canvasX, "y": canvasY }, 1);
            } else if ($scope.meetingDSannotation == 3) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation == 4) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation >= 5 && $scope.meetingDSannotation <= 11) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 1, $scope.meetingtype);
            } else if ($scope.meetingDSannotation >= 12 && $scope.meetingDSannotation <= 16) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 1, $scope.meetingtype);
            } else if ($scope.meetingDSannotation == 17) {
                annotationLaserpointerStart(1, { "x": canvasX, "y": canvasY }, { "cx": 28 * 15, "cy": 28 * 15 });
            } else if ($scope.meetingDSannotation == 20) {
                annotationEditStart($scope.annoid, 6, $scope.annoidType, { "x": $scope.canvasX, "y": $scope.canvasY }, $scope.annoid);
            }

            document.onmousemove = function(e) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left),
                        canvasY = (y - top); 
                    if ($scope.meetingDSannotation == 3) {

                    } else if ($scope.meetingDSannotation >= 12 && $scope.meetingDSannotation <= 16) {
                        var pdata = {
                            "bLocal": 1,
                            "localIndex": $scope.localIndex,
                            "dispRect": {
                                "left": canvasX * 15 - 14 * 15,
                                "top": canvasY * 15 - 14 * 15,
                                "right": (canvasX + 28) * 15,
                                "bottom": (canvasY + 28) * 15
                            }
                        }
                        annotationCreateCustomerUpdate(1, pdata);
                    } else if ($scope.meetingDSannotation >= 5 && $scope.meetingDSannotation <= 11) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationCreateDrawingUpdate(1, pdata);
                    } else if ($scope.meetingDSannotation == 17) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationLaserpointerMoveto(1, pdata);
                    } else if ($scope.meetingDSannotation == 20) {
                        annotationEditUpdate($scope.annoidType, { "x": canvasX * 15, "y": canvasY * 15 });
                    }
                }
            document.onmouseup = function(e) {
                var t = e.target;
                if (t == c) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left) * 15,
                        canvasY = (y - top) * 15; 
                    if ($scope.meetingDSannotation >= 5 && $scope.meetingDSannotation <= 16) {
                        annotationCreateDone(0, 1, false);
                    } else if ($scope.meetingDSannotation == 17) {

                    } else if ($scope.meetingDSannotation == 3) {

                    } else if ($scope.meetingDSannotation == 20) {
                        annotationEditDone(false, $scope.annoidType);
                    }
                }
                this.onmousemove = null;
            }
        }

    }

    function diag(pString) {
        var str = prompt("enter the contents", pString);
        if (str) {
            return str;
        }
    }

    //This function is used to enter the file path
    function diagInputSrc() {
        var str = prompt("Please enter the file path：", "D:/1.docx");
        if (str) {
            return str;
        }
    }

    function diagRequestHost() {
        var str = prompt("enter the host password", "");
        if (str) {
            return str;
        }

    }

    //This function is used to select shared programs
    function diagSelectAPP(data) {
        var APPList = "";
        var hwnd = 0;
        var wndTitle = 0;
        for (var i = 0; i < 20; i++) {
            hwnd = "hwnd" + i;
            wndTitle = "wndTitle" + i;
            if (data[hwnd] != 0) {
                APPList = APPList + data[hwnd] + ":" + data[wndTitle] + "\n\n";
            } else {
                break;
            }
        }
        var str = prompt(APPList);
        if (str) {
            return str;
        }
    }

    //This function is used for text annotation
    $(function() {
        $("#annotationFont").click(function() {
            $("#annotationTypeFont").show();
            //The key is here, stop bubbling
            return false; 
        });
        $("#annotationTypeFont").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationTypeFont").hide();
        });
    })

    $(function() {
        $("#annotationWBFont").click(function() {
            $("#annotationWBTypeFont").show();
            return false;
        });
        $("#annotationWBTypeFont").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationWBTypeFont").hide();
        });
    })

    $(function() {
        $("#annotationASFont").click(function() {
            $("#annotationASTypeFont").show();
            return false; 
        });
        $("#annotationASTypeFont").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationASTypeFont").hide();
        });
    })

    $(function() {
        $("#annotationCustomer").click(function() {
            $("#annotationTypeCustomer").show();
            return false; 
        });
        $("#annotationTypeCustomer").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationTypeCustomer").hide();
        });
    })

    $(function() {
        $("#annotationWBCustomer").click(function() {
            $("#annotationWBTypeCustomer").show();
            return false; 
        });
        $("#annotationWBTypeCustomer").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationWBTypeCustomer").hide();
        });
    })

    $(function() {
        $("#annotationASCustomer").click(function() {
            $("#annotationASTypeCustomer").show();
            return false; 
        });
        $("#annotationASTypeCustomer").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationASTypeCustomer").hide();
        });
    })

    $(function() {
        $("#annotationDrawing").click(function() {
            $("#annotationTypeDrawing").show();
            return false; 
        });
        $("#annotationTypeDrawing").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationTypeDrawing").hide();
        });
    })

    $(function() {
        $("#annotationWBDrawing").click(function() {
            $("#annotationWBTypeDrawing").show();
            return false; 
        });
        $("#annotationWBTypeDrawing").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationWBTypeDrawing").hide();
        });
    })

    $(function() {
        $("#annotationASDrawing").click(function() {
            $("#annotationASTypeDrawing").show();
            return false; 
        });
        $("#annotationASTypeDrawing").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationASTypeDrawing").hide();
        });
    })

    $(function() {
        $("#screenShare").click(function() {
            $("#screenShareType").show();
            return false; 
        });
        $("#screenShareType").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#screenShareType").hide();
        });
    })

    var localView = $('#meetingLocalCanvas')[0];
    var remoteView1 = $('#meetingRemoteCanvas1')[0];
    var remoteView2 = $('#meetingRemoteCanvas2')[0];
    var remoteView3 = $('#meetingRemoteCanvas3')[0];

    $scope.confVideo = function() {
        $('#meetingWelcome').hide();
        for (var i = 0; i < $scope.participants.length; i++) {
            if ($scope.participants[i].is_self == 1) { 
                ConfVideoOpen({ lcCanvas: localView, rtCanvas: [remoteView1, remoteView2, remoteView3], width: 352, height: 288, userid: ($scope.participants[i].dataconf_userid) });
            }
        }
    }

    $scope.confVideoClose = function() {
            ConfVideoClose();
        }
});

//This function is used for conference access code entry
function uiAccessReservedConf() {
    var accessNumber = $("#accessNumber").val();
    var confPasscode = $("#confPasscode").val();
    var confId = $("#confId").val();
    if (sessionStorage.getItem("solutionType") == "PBX") {
        startConfCall(accessNumber + "*" + confPasscode + "#");
    } else if (sessionStorage.getItem("solutionType") == "EC") {
        var call_id = 0;
        var call_type = 0;
        var pstconfparam = {
            "confid": confId,
            "access_code": accessNumber,
            "conf_paswd": confPasscode
        };
        accessReservedConfEx(call_id, call_type, pstconfparam);
    } else {

    }
}

//This function is used to unify access numbers
function uiCallAccessConf() {
    startConfCall($('#confDialNumber').val());
}

//This function is used to create a meeting
function uiBookConf() {
    var bookType = $("input[name='startTime']:checked").attr('id');
    var confSize = Number($("#confSize").val());
    var mediaType = Number($("#confMediaType").val());
    var year = Number($("#bookYear").val());
    var month = Number($("#bookMonth").val());
    var date = Number($("#bookDay").val());
    var hour = Number($("#bookHour").val());
    var minute = $("#bookMinute").val();
    if (hour < 8) { 
        hour = hour + 24 - 8
        if (date > 1) {
            date = date - 1;
        } else {
            if (month > 1) {
                month = month - 1;
            } else {
                month = 12
                year = year - 1;
            }
            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) { date = 31 };
            if (month == 4 || month == 6 || month == 9 || month == 11) { date = 30 };
            if (month == 2) {
                if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
                    date = 29;
                } else {
                    date = 28;
                }
            }
        }
    } else {
        hour = hour - 8;
    };
    month += "";
    date += "";
    hour += "";
    if (month >= 1 && month <= 9 && (month.substring(0, 1) != 0)) {
        month = "0" + month;
    }
    if (date >= 0 && date <= 9 && (date.substring(0, 1) != 0)) {
        date = "0" + date;
    }
    if (hour >= 0 && hour <= 9 && (hour.substring(0, 1) != 0)) {
        hour = "0" + hour;
    }
    if (minute >= 0 && minute <= 9 && (minute.substring(0, 1) != 0)) {
        minute = "0" + minute;
    }
    var startTime = year + "-" + month + "-" + date + " " + hour + ":" + minute;
    var confLen = Number($("#bookDuraHour").val() * 60 + Number($("#bookDuraMinute").val()));
    var subject = $("#confSubject").val();

    var numbers = $("#attendeeNumber").val() + "";
    var array = numbers.split(",");
    var attendeeNumber = Number(array.length);
    var attendee = new Array();
    for (var i = 0; i < array.length; i++) {
        if (array[i] != "") {
            attendee[i] = { number: array[i] + "", name: "", email: "", sms: "", is_mute: 0, role: 0, type: 0, is_auto_invite: 0 };
        } else {
            attendeeNumber--;
        }
    }
    var chairmanNum = sessionStorage.getItem("authNumber");
    attendee[array.length] = { number: chairmanNum, name: "", email: "", sms: "", is_mute: 0, role: 1, type: 0, is_auto_invite: 0 };
    var cycle = { start_data: 0, end_data: 0, frequency: 0, appointed_type: 0, interval: 0, point_num: 0, point_list: 0, cycle_count: 0 };
    var assMedia = { mpi: 1, type: 1, code: 1, bandwidth: 1, size: 1 };
    if (bookType == "startDelay") { 
        var bookConfInfoUportal = {
            size: confSize,
            conf_type: 0,
            media_type: mediaType,
            start_time: startTime,
            conf_len: confLen,
            subject: subject,
            welcome_voice_enable: 0,
            enter_prompt: 0,
            leave_prompt: 0,
            conf_filter: 0,
            record_flag: 0,
            auto_prolong: 0,
            multi_stream_flag: 0,
            reminder: 0,
            language: 0,
            conf_encrypt_mode: 0,
            user_type: 0,
            num_of_attendee: attendeeNumber + 1,
            attendee: attendee,
            cycle_params: cycle,
            assistant_media_params: assMedia
        };
        bookConf({ book_conf_info_uportal: bookConfInfoUportal }, { onUportalBookConfResult: onUportalBookConf });
    } else { 
        if (sessionStorage.getItem("terminalType") == "android") {
            var bookConfInfoUportal = {
                size: confSize,
                conf_type: 0,
                media_type: mediaType,
                start_time: "",
                conf_len: confLen,
                subject: subject,
                welcome_voice_enable: 0,
                enter_prompt: 0,
                leave_prompt: 0,
                conf_filter: 0,
                record_flag: 0,
                auto_prolong: 0,
                multi_stream_flag: 0,
                reminder: 0,
                language: 0,
                conf_encrypt_mode: 0,
                user_type: 0,
                num_of_attendee: attendeeNumber + 1,
                attendee: attendee,
                cycle_params: cycle,
                assistant_media_params: assMedia
            };
            bookConf({ book_conf_info_uportal: bookConfInfoUportal }, { onUportalBookConfResult: onBookReservedConfResult });
        } else {
            createConf({ 
                subject: subject,
                group_uri: "",
                welcome_voice_enable: 0,
                enter_prompt: 0,
                leave_prompt: 0,
                conf_filter: 0,
                record_flag: 0,
                multi_stream_flag: 0,
                media_type: mediaType,
                language: 0,
                conf_encrypt_mode: 0,
                user_type: 0,
                num_of_attendee: attendeeNumber + 1,
                attendee: attendee,
                assistant_media_params: assMedia
            }, { onCreateConfResult: onCreateConf });
        }

    }
}

function onUportalBookConf(data) {
    if(0 == data.ret){
        alert("Meeting book is successful");
    }else if(11040 == data.ret){
       alert("The meeting start time can not be less than the current time");
    }else{
       alert("Meeting booking failed");
    }
}

function onBookReservedConfResult(data) {
    var confId = data.param.conf_list_info.conf_id;
    if (data.param.ret == 0) {
        createConfHandle(confId, {
            onMobileConfConnected: onMobileConfConnectedInd
        });
    }
}

function onCreateConf(data) {

}

function onMobileConfConnectedInd(msg) {
    var confHandle = msg.param.conf_handle;
    subscribeConf(confHandle, {
        onSubscribeConfResult: onSubscribeConfResultInd
    });
}

function onSubscribeConfResultInd(data) {

}

//This function is used to leave the meeting
function uiLeaveConf() {
    leaveConf();
    endtimer();
    closeDB();
    $scope.participants = showAttendeeDB();
    //Leave the data meeting
    LeaveConference({ response: onuserLeaveResult });
    $("#confFullPannel").show();
    $("#audioConfPannel").hide();
    sessionStorage.removeItem("lock");
    sessionStorage.removeItem("callerNum");
    sessionStorage.removeItem("meetingAttendeeList");
}

function onuserLeaveResult(data) {
    setTimeout(function() {
        window.location.reload();
    }, 1500);
}

//This function is used for mute meetings
function uiMuteConf(value) {
    muteConf(value, {
        onMuteConfResult: muteConfResult
    });
}

//This function is used to mute the meeting results
function muteConfResult(data) {
    var is_mute = data.param.to_mute;
    if (is_mute) {
        $("#muteConf").hide();
        $("#unmuteConf").show();
    } else {
        $("#muteConf").show();
        $("#unmuteConf").hide();
    }
}

//This function is used to add attendees
function uiAddConfAttendee() {
    var numbers = $("#newAttendeeNumber").val() + "";
    var array = numbers.split(",");
    var attendeeNumber = Number(array.length);
    var attendee = new Array();
    for (var i = 0; i < array.length; i++) { 
        attendee[i] = { number: array[i] + "", name: "", email: "", sms: "", is_mute: 0, role: 0, type: 0, is_auto_invite: 0 };
    }
    var attendeeInfo = { num_of_attendee: attendeeNumber, attendee_info: attendee };
    addAttendee(attendeeInfo);
}

function switchTerminal() {
    var num = $("#otherTerminalNum").val();
    var attendee = [{ number: num + "", name: "", email: "", sms: "", is_mute: 0, role: 0, type: 0, is_auto_invite: 0 }];
    var attendeeInfo = { num_of_attendee: 1, attendee_info: attendee };
    addAttendee(attendeeInfo);
}

function uiAcceptConf() {
    acceptConf();
}

function uiRejectConf() {
    rejectConf();
    $("#confIncomingTable").hide();
    $("#noConfAtNow").show();
}

function uiEndConf() {
    endConf({
        onEndConfResult: endConfResult
    });
    TerminateConference({ response: onconfTerminateResult });
    closeDB();
}

function uiLockConf(toLock) {
    lockConf(toLock, {
        onLockConfResult:onLockConfResultInd
    })
}

function onLockConfResultInd(data){

}

function uiPostponeConf(){
    var time = $("#postponeTime").val();
    postponeConf(time, {
        onConfTimeRemnant:onConfTimeRemnantInd,
        onConfPostphoneResult:onConfPostphoneResultInd
    })
}

function onConfTimeRemnantInd(data){

}

function onConfPostphoneResultInd(data){

}
function onconfTerminateResult(data) {
    setTimeout(function() {
        window.location.reload();
    }, 1500);
}

function endConfResult(data) {
    var res = data.param.ret;
    if (res == 0) {
        endtimer();
        $("#confFullPannel").show();
        $("#audioConfPannel").hide();
        sessionStorage.removeItem("lock");
        sessionStorage.removeItem("callerNum");
    }
}

function getNowFormatDate() {
    var date = new Date();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();

    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    $("#bookYear").val(date.getFullYear());
    $("#bookMonth").val(month);
    $("#bookDay").val(strDate);
    $("#bookHour").val(date.getHours());
    $("#bookMinute").val(date.getMinutes());
}

function inputNumThree(e) {
    var obj = e.target || e.srcElement;
    if (obj.nodeName != "INPUT") {
        return;
    }
    var value = obj.value;
    var calleeNum = $("#confDialNumber").val();
    var sub = calleeNum.substr(0, calleeNum.length - 1);
    if (value == "<-") {
        $("#confDialNumber").val(sub);
    } else {
        $("#confDialNumber").val(calleeNum + value);
    }
}

var conftimer = 0;
var timeStr = '';

function confTiming() {

    var HH = 0;
    var mm = 0;
    var ss = 0;
    conftimer = setInterval(function() {
        timeStr = "";
        if (++ss == 60) {
            if (++mm == 60) {
                HH++;
                mm = 0;
            }
            ss = 0;
        }
        timeStr += HH < 10 ? "0" + HH : HH;
        timeStr += ":";
        timeStr += mm < 10 ? "0" + mm : mm;
        timeStr += ":";
        timeStr += ss < 10 ? "0" + ss : ss;
        if ($("#confTiming").html() != null) {
            $("#confTiming").html(timeStr);
        }
    }, 1000);
    sessionStorage.setItem("confTimer", "inconf");
};

function endtimer() {
    timeStr = "";
    clearInterval(conftimer);
    sessionStorage.removeItem("confTimer");
}
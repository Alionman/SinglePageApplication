//Build a callback array
var loginNotifyFuncs = new Array();

var tupLogin = new TUPLogin({
    ready: onLoginReady,
    close: onLoginClose
});

function onLoginReady() {
    var loginKey = sessionStorage.getItem("loginKey");
    if (!loginKey) {
        LoginInit();
        sessionStorage.setItem("loginKey", "true");
    }

}

function onLoginClose() {
    alert("Your local library has been closed, please reopen!");
    sessionStorage.removeItem("loginKey");
    sessionStorage.clear();
    window.location.reload();
}

function LoginInit() {

    tupLogin.logStart("./jsdemolog", 3, 3, 10240);
    tupLogin.init("", 0);
};

//This function is used to Uportal authenticate
function loginUPortalAuth(accountVal, password, server_addr, server_port, callbacks) {

    if (callbacks && typeof callbacks.onUportalAuthResult == "function") {
        this.loginNotifyFuncs[10] = callbacks.onUportalAuthResult;
    }
    if (callbacks && typeof callbacks.onRefreshTokenResult == "function") {
        this.loginNotifyFuncs[11] = callbacks.onRefreshTokenResult;
    }
    if (callbacks && typeof callbacks.IMSTokenRefresh == "function") {
        this.loginNotifyFuncs[18] = callbacks.IMSTokenRefresh;
    }
    if (callbacks && typeof callbacks.onMediaxAuthResult == "function") {
        this.loginNotifyFuncs[9] = callbacks.onMediaxAuthResult;
    }
    if (callbacks && typeof callbacks.onSMCAuthResult == "function") {
        this.loginNotifyFuncs[14] = callbacks.onSMCAuthResult;
    }
    var auth_data = {
        "auth_type": 0,
        "user_agent": "espace-desktop",
        "user_tiket": "1",
        "auth_info": {
            "user_name": accountVal,
            "password": password
        },
        "auth_server": {
            "server_type": 0,
            "server_url": server_addr,
            "server_port": Number(server_port),
            "server_version": "V6R6C00",
            "proxy_url": ""
        }
    };
    tupLogin.authorize(auth_data, {
        onUportalAuthResult: onLoginAuthResult,
        onRefreshTokenResult: onRefreshTokenResult
    });
};

//This function is used to Uportal authenticate of UC3.2
function loginUPortalUC32Auth() {
    var auth_data = {
        "auth_type": 0,
        "user_agent": "espace-desktop",
        "user_tiket": "1",
        "auth_info": {
            "user_name": "+8675582471503@domain84.huawei.com",
            "user_number": "+8675582471503",
            "password": "12345678"
        },
        "auth_server": {
            "server_type": 0,
            "server_url": "162.3.10.210",
            "server_port": 443,
            "server_version": "V6R6C00",
            "proxy_url": ""
        }
    };
    tupLogin.authorize(auth_data, {
        IMSTokenRefresh: IMSTokenRefresh
    });
};

//This callback of refresh token result.
function onRefreshTokenResult(data) {
    if (typeof loginNotifyFuncs[11] == "function") {
        if (data.param.result == 0) {
            var authorize_result = JSON.parse(sessionStorage.authorize_result);
            authorize_result.auth_token = data.param.refresh_token_result.auth_token;
            authorize_result = JSON.stringify(authorize_result);
            sessionStorage.authorize_result = authorize_result;
        } else {
            //Automatically call the login method
        }
        loginNotifyFuncs[11](data.param.result);
    }
}

//This callback of login authenticate result.
function onLoginAuthResult(data) {

    if (typeof loginNotifyFuncs[10] == "function") {
        if (data.param.result == 0) {
            var authorize_result = JSON.stringify(data.param.uportal_authorize_result);
            sessionStorage.authorize_result = authorize_result;
        } else {

        }
        loginNotifyFuncs[10](data.param.result);
    }
}

//This function is used to refresh token.
function refreshToken() {
    tupLogin.refreshToken({ onRefreshTokenResult: onRefreshTokenResult });
}

//This function is used to detect firewall.
function firewallDetect() {
    var authorize_result = JSON.parse(sessionStorage.authorize_result);
    if (authorize_result.site_info != undefined || authorize_result.site_info != null) {
        var svn_uri = authorize_result.site_info[0].access_server[0].svn_uri;
        var arraySVN = svn_uri.split(":");
        var detect_server = {
            "server_num": 1,
            "servers": [{
                "server_port": parseInt(arraySVN[1]),
                "server_uri": arraySVN[0]
            }]
        }
        tupLogin.firewallDetect(detect_server, { onFirewallDetectResult: onFirewallDetectResult });
    } else {
        console.log("Site information is empty!");
    }

}

function onFirewallDetectResult(data) {
    if (data.param.result == 0 && data.param.fire_wall_mode == 2) {
        console.log("No firewall");
    }
}


//This function is used to get local IP.
function setGetBestLocalIp(server_addr){
    param = {
        "server" : server_addr
    }
    tupLogin.setGetBestLocalIp(param,{response:onLocalIpResult});

    function onLocalIpResult(data){
        if(0 == data.result){
            sessionStorage.local_ip = data.local_ip;
        }else{
           console.log("Get local IP failed"); 
        }
        
    }
}

function loginUninit() {
    tupLogin.uninit();
    tupLogin.logStop();
}
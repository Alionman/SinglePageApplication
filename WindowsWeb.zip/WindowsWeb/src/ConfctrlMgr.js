//This is used to create a object of tupConfctrl, and init the basic configure when wsocket is opened
if(!tupConfctrl){
    var tupConfctrl = new TUPConfctrl({ready : onCallReady, close : onCallClose});
}

//This function is used to deel with event which need to be invoked when webSocket is opened
function onCallReady(){
    var bool = sessionStorage.getItem("confctrlKey");
    if(!bool){
        initConfctrl();
        setConfEnvType();
        sessionStorage.setItem("confctrlKey", "true");
        sessionStorage.setItem("terminalType", "PC"); 
    }
}
//This function is used to deel with event which need to be invoked when webSocket is closed
function onCallClose(){
    sessionStorage.removeItem("confctrlKey");
    sessionStorage.removeItem("terminalType");
}

//This function is used to set server indicate event
tupConfctrl.setServerIndEvent({
    onAttendeeUpdate:onAttendeeUpdateMgr,
    onChairmanInd:onChairmanIndMgr,
    onBroadcastAttendeeInd:onBroadcastAttendeeMgr,
    onCancelBroadcastAttendeeInd:onCancelBroadcastAttendeeMgr,
    onAttendeeBroadcastedInd:onAttendeeBroadcastedMgr,
    onLocalBroadcastStatusInd:onLocalBroadcastStatusMgr,
    onFloorAttendeeInd:onFloorAttendeeMgr,
    onAttendeeListUpdate:onAttendeeListUpdateMgr
});

//This method is used to set basic conf call event
tupConfctrl.setBasicConfCallEvent({
    onConfIncomingInd:onConfIncoming,
    onConfConnectedInd:onConfConnected,
    onConfInfoInd:onConfInfo,
    onEndConfInd:onEndConf,
    onBeTransToConfInd:onBeTransToConf,
    onAddDataConfInd:onAddDataConf,
    onConfRightResult:onConfRight
});

//This array is used to saved callbacks which need to be transfered to confctrlController
var confNotifyFuncs = new Array();
//This function is used to put callbacks in array
function setBasicConfEvent(callbacks){
    if (callbacks && typeof callbacks.onConfConnectedInd == "function") {
        this.confNotifyFuncs[5] = callbacks.onConfConnectedInd;
    }    
    if (callbacks && typeof callbacks.onBeTransToConfInd == "function") {
        this.confNotifyFuncs[3] = callbacks.onBeTransToConfInd;
    }
    if (callbacks && typeof callbacks.onConfIncomingInd == "function") {
        this.confNotifyFuncs[4] = callbacks.onConfIncomingInd;
    }
    if (callbacks && typeof callbacks.onAttendeeListUpdate == "function") {
        this.confNotifyFuncs[8] = callbacks.onAttendeeListUpdate;
    }
    if (callbacks && typeof callbacks.onConfInfoInd == "function") {
        this.confNotifyFuncs[9] = callbacks.onConfInfoInd;
    }
    if (callbacks && typeof callbacks.onFloorAttendeeInd == "function") {
        this.confNotifyFuncs[10] = callbacks.onFloorAttendeeInd;
    }
    if (callbacks && typeof callbacks.onEndConfInd == "function") {
        this.confNotifyFuncs[11] = callbacks.onEndConfInd;
    } 
    if (callbacks && typeof callbacks.onAddDataConfInd == "function") {
        this.confNotifyFuncs[13] = callbacks.onAddDataConfInd;
    }    
    if (callbacks && typeof callbacks.onConfRhghtResult == "function") {
        this.confNotifyFuncs[57] = callbacks.onConfRhghtResult;
    }
}

//This function is used to init log and basic param before the service start.
function initConfctrl(){
    tupConfctrl.init(
        {
            log_level: 3,
            maxsize_kb: 100,
            file_count: 5,
            log_path: "./jsdemolog"           
        },{    
            wait_msgp_thread : 1,
            batch_update : 0,
            connect_call : 1,
            save_participant_list : 1            
        }
    )
}

//This function is used to set conference environment type.
function setConfEnvType(){
    tupConfctrl.setConfEnvType(3);
}

//This function is used to set server params, server address and port get from authorize result
function setServerParams(){
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = JSON.parse(authorize_result);
    tupConfctrl.setServerParams({
        server_addr: authorizeResult.auth_serinfo.server_uri,
        port: authorizeResult.auth_serinfo.server_port
    });
}

//This function is used to set token of conference control. At the end of expire time, invoking this function in the callback 'onTokenRefresh'.
function setToken(){
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = JSON.parse(authorize_result);
    tupConfctrl.setToken(authorizeResult.auth_token);
}

//This function is invoked after authorize login
function confCtrlCfg(){
    setServerParams();
    setToken();
}

//This function is used to book conf
function bookConf(params, callbacks){
    if (callbacks && typeof callbacks.onUportalBookConfResult == "function") {
        this.confNotifyFuncs[0] = callbacks.onUportalBookConfResult;
    }
    tupConfctrl.bookConf(params, 
    {onUportalBookConfResult:uportalBookConfResult,
     onBookConfResult:bookConfResult});
}

//This function is used to receive data from callback, and do some relatived operate
function uportalBookConfResult(data){
    confNotifyFuncs[0](data.param);
}
//This is used in VC mode
function bookConfResult(data){

}
//This function is used to create conf
function createConf(params, callbacks){
    if (callbacks && typeof callbacks.onCreateConfResult == "function") {
        this.confNotifyFuncs[1] = callbacks.onCreateConfResult;
    }    
    tupConfctrl.createConf(params,{onCreateConfResult:createConfResult});
}
//This function is used to receive data from callback, and do some relatived operate
function createConfResult(data){
    confNotifyFuncs[1](data);
}
//This function is used to get conf list 
function getConfList(params, callbacks){
    if (callbacks && typeof callbacks.onGetConfListResult == "function") {
        this.confNotifyFuncs[2] = callbacks.onGetConfListResult;
    }
    tupConfctrl.getConfList(params, {onGetConfListResult:getConfListResult});
}
//This function is used to receive data from callback, and do some relatived operate
function getConfListResult(data){
    confNotifyFuncs[2](data);
}

function getConfInfo(confInfo, callbacks){
    if (callbacks && typeof callbacks.onGetConfInfoResult == "function") {
        this.confNotifyFuncs[15] = callbacks.onGetConfInfoResult;
    }    
    tupConfctrl.getConfInfo(confInfo, {onGetConfInfoResult:getConfInfoResult});
}

function getConfInfoResult(data){
    confNotifyFuncs[15](data);
}

//This function is used to access conf
function startConfCall(accessCode){
    startCall(accessCode,0);
}

//This function is used to access EC conf
function accessReservedConfEx(call_id, call_type, pstconfparam,callbacks){
    tupCall.accessReservedConfEx(call_id, call_type, pstconfparam, callbacks);
}

//This function is used to receive data from callback, and do some relatived operate
var confHandle = 1;
function onConfIncoming(data){
    confHandle = data.param.handle;
    confNotifyFuncs[4](data);
}
//This function is used to receive data from callback, and do some relatived operate
function onConfConnected(data){
    confNotifyFuncs[5](data);
    confHandle = data.param.handle;
}
//This function is used to receive data from callback, and do some relatived operate
function onConfInfo(data){
    confNotifyFuncs[9](data);
    confHandle = data.param.handle;
}
//This function is used to receive data from callback, and do some relatived operate
function onEndConf(data){
    confNotifyFuncs[11](data);
}
//This function is used to receive data from callback, and do some relatived operate
function onBeTransToConf(data){
    confNotifyFuncs[3](data);
}
//This function is used to receive data from callback, and do some relatived operate
function onAddDataConf(data){
    confNotifyFuncs[13](data);
}

function onConfRight(data){
    confNotifyFuncs[57](data);
}


function onAttendeeUpdateMgr(data){

}

function onChairmanIndMgr(data){

}

function onBroadcastAttendeeMgr(data){
    
}

function onCancelBroadcastAttendeeMgr(data){
    
}

function onAttendeeBroadcastedMgr(data){
    
}

function onLocalBroadcastStatusMgr(data){
    
}
//This function is used to receive data from callback, and do some relatived operate
function onFloorAttendeeMgr(data){
    confNotifyFuncs[10](data);
}
//This function is used to receive data from callback, and do some relatived operate
var conf_id = "";
function onAttendeeListUpdateMgr(data){
    conf_id = data.param.conf_status.conf_id;
    confNotifyFuncs[8](data);
}

//This function is used to leave conf
function leaveConf(){
    tupConfctrl.leaveConf(confHandle);
}

//This function is used to mute conf
function muteConf(isMute,callbacks){
    if (callbacks && typeof callbacks.onMuteConfResult == "function") {
        this.confNotifyFuncs[6] = callbacks.onMuteConfResult;
    }    
    tupConfctrl.muteConf(confHandle, isMute, {
        onMuteConfResult:onMuteConfResultMgr
    })
}
//This function is used to receive data from callback, and do some relatived operate
function onMuteConfResultMgr(data){
    confNotifyFuncs[6](data);
}
//This function is used to end conf
function endConf(callbacks){
    if (callbacks && typeof callbacks.onEndConfResult == "function") {
        this.confNotifyFuncs[7] = callbacks.onEndConfResult;
    }
    tupConfctrl.endConf(confHandle, {
        onEndConfResult:onEndConfResultMgr
    });
}
//This function is used to receive data from callback, and do some relatived operate
function onEndConfResultMgr(data){
    confNotifyFuncs[7](data);
}
//This function is used to mute attendee
function muteAttendee(ismute, attNum){ 
    tupConfctrl.muteAttendee({conf_handle:confHandle, to_mute:ismute, attendee:attNum},{
        onMuteAttendeeResult:onMuteAttendeeMgr
    });
}
//This function is used to receive data from callback, and do some relatived operate
function onMuteAttendeeMgr(data){

}

function handup(attNum, ishandup, callbacks){
    if (callbacks && typeof callbacks.onHandUpResult == "function") {
        this.confNotifyFuncs[21] = callbacks.onHandUpResult;
    }     
    tupConfctrl.handup(attNum, confHandle, ishandup, {
        onHandUpResult:onHandUpResultMgr
    });
}

function onHandUpResultMgr(data){
    confNotifyFuncs[21](data);
}

//This function is used to add attendee
function addAttendee(attendeeInfo){
    tupConfctrl.addAttendee(attendeeInfo, confHandle, "", {
        onAddAttendeeResult:onAddAttendeeMgr
    })
}
//This function is used to receive data from callback, and do some relatived operate
function onAddAttendeeMgr(data){
    
}
//This method is used to remove attendee
function removeAttendee(attendeeNum,callbacks){
    if (callbacks && typeof callbacks.onDelAttendeeResult == "function") {
        this.confNotifyFuncs[29] = callbacks.onDelAttendeeResult;
    }     
    var params = {conf_handle:confHandle, number:attendeeNum}
    tupConfctrl.removeAttendee(params, {
        onDelAttendeeResult:onDelAttendeeMgr
    })
}
//This function is used to receive data from callback, and do some relatived operate
function onDelAttendeeMgr(data){
    confNotifyFuncs[29](data.param.ret);
}
//This function is used to hang up attendee
function hangUpAttendee(attendeeNum, callbacks){
    if (callbacks && typeof callbacks.onHangupAttendeeResult == "function") {
        this.confNotifyFuncs[22] = callbacks.onHangupAttendeeResult;
    }       
    var params = {conf_handle:confHandle, attendee:attendeeNum}
    tupConfctrl.hangUpAttendee(params, {
        onHangupAttendeeResult:onHangupAttendeeResultMgr
    })    
}
//This function is used to receive data from callback, and do some relatived operate
function onHangupAttendeeResultMgr(data){
    confNotifyFuncs[22](data);
}
//This function is used to accept conf
function acceptConf(){
    tupConfctrl.acceptConf(confHandle);
}
//This function is used to reject conf
function rejectConf(){
    tupConfctrl.rejectConf(confHandle);
}

//This function is used to recall attendee
function callAttendee(attendeeNum){
    if (callbacks && typeof callbacks.onCallAttendeeResult == "function") {
        this.confNotifyFuncs[23] = callbacks.onCallAttendeeResult;
    }      
    var params = {conf_handle:confHandle, attendee:attendeeNum}
    tupConfctrl.callAttendee(params, {
        onCallAttendeeResult:onCallAttendeeMgr
    });
}

function onCallAttendeeMgr(data){
    confNotifyFuncs[23](data);
}

//This function is used to p2p transfer to conf
function p2pTransferToConf(confInfo, callId){
    tupConfctrl.p2pTransferToConf(confInfo, callId, {
        onTransToConfResult:onTransToConfResultMgr
    })
}
//This function is used to receive data from callback, and do some relatived operate
function onTransToConfResultMgr(data){

}
//This function is used to upgrade conf
function upgradeConf(){
    tupConfctrl.upgradeConf(
        {media_type:17, group_uri:""},
        confHandle,
        {onUpgradeConfResult:onUpgradeConfResultMgr}
    );
}
//This function is used to receive data from callback, and do some relatived operate
function onUpgradeConfResultMgr(data){
    
}
//This function is used to get data conf param， it's supposed to invoked after upgradeConf
function getDataconfParams(confParams, callbacks){
    if (callbacks && typeof callbacks.onConfParamsResult == "function") {
        this.confNotifyFuncs[12] = callbacks.onConfParamsResult;
    }     
    tupConfctrl.getDataconfParams(confParams, {
        onConfParamsResult:onConfParamsResultMgr
    });
}
//This function is used to receive data from callback, and do some relatived operate
function onConfParamsResultMgr(data){
    confNotifyFuncs[12](data);
}

//This function is used to create a conf handle for android joining conference
function createConfHandle(confId, callbacks){
    if (callbacks && typeof callbacks.onMobileConfConnected == "function") {
        this.confNotifyFuncs[16] = callbacks.onMobileConfConnected;
    }   
    tupConfctrl.createConfHandle("", confId, {response : function(msg){
        confNotifyFuncs[16](msg);
    }, onConnected: onConnectedMgr});
}

function onConnectedMgr(data){
    
}

//This function is used to subscribe to a meeting
function subscribeConf(confHandle, callbacks){
    if (callbacks && typeof callbacks.onSubscribeConfResult == "function") {
        this.confNotifyFuncs[17] = callbacks.onSubscribeConfResult;
    }     
    tupConfctrl.subscribeConf(confHandle, {
        onSubscribeConfResult:subscribeConfResult
    });
}

function subscribeConfResult(data){
    confNotifyFuncs[17](data);
}

//This function is used to lock a meeting
function lockConf(toLock, callbacks){
    if (callbacks && typeof callbacks.onLockConfResult == "function") {
        this.confNotifyFuncs[18] = callbacks.onLockConfResult;
    }      
    tupConfctrl.lockconf(parseInt(toLock), confHandle, {
        onLockConfResult:lockConfResult
    });
}

function lockConfResult(data){
    confNotifyFuncs[18](data);
}

//This function is used to extend the meeting
function postponeConf(time, callbacks){
    if (callbacks && typeof callbacks.onConfTimeRemnant == "function") {
        this.confNotifyFuncs[19] = callbacks.onConfTimeRemnant;
    }     
    if (callbacks && typeof callbacks.onConfPostphoneResult == "function") {
        this.confNotifyFuncs[20] = callbacks.onConfPostphoneResult;
    }         
    tupConfctrl.postponeConf(confHandle, parseInt(time), {
        onConfTimeRemnant:confTimeRemnant,
        onConfPostphoneResult:confPostphoneResult
    })
}

function confTimeRemnant(data){
    confNotifyFuncs[19](data);
}

function confPostphoneResult(data){
    confNotifyFuncs[20](data);
}

//This function is used to apply for a chairperson
function requestChairman(password, numb, callbacks){
    if (callbacks && typeof callbacks.onReqChairmanResult == "function") {
        this.confNotifyFuncs[24] = callbacks.onReqChairmanResult;
    }     
    if (callbacks && typeof callbacks.onEnterPasswordToBeChairman == "function") {
        this.confNotifyFuncs[25] = callbacks.onEnterPasswordToBeChairman;
    } 
    tupConfctrl.requestChairman(password, confHandle, numb, {
        onReqChairmanResult:reqChairmanResult,
        onEnterPasswordToBeChairman:enterPasswordToBeChairman
    })
}

function reqChairmanResult(data){
    confNotifyFuncs[24](data);
}

function enterPasswordToBeChairman(data){
    confNotifyFuncs[25](data);
}

//This function is used to release the chairman
function releaseChairman(numb, callbacks){
    if (callbacks && typeof callbacks.onReleaseChairmanResult == "function") {
        this.confNotifyFuncs[26] = callbacks.onReleaseChairmanResult;
    }     
    tupConfctrl.releaseChairman(confHandle, numb, {
        onReleaseChairmanResult:releaseChairmanResult
    })
}

function releaseChairmanResult(data){
    confNotifyFuncs[26](data);
}

//This function is used to set the conference mode
function setConfMode( mode, callbacks){
    if(callbacks && typeof callbacks.onSetConfModeResult == "function")
    {
        this.confNotifyFuncs[40] = callbacks.onSetConfModeResult;
    }
    tupConfctrl.setConfMode(confHandle, mode,{onSetConfModeResult:onSetConfModeResult});
}

function onSetConfModeResult(data){
    confNotifyFuncs[26](data);
}

//This function is used to broadcast attendees
function broadcastAttendee(params, callbacks){
        if(callbacks && typeof callbacks.onBroadcastAttendeeResult == "function"){
            this.confNotifyFuncs[11] = callbacks.onBroadcastAttendeeResult;
        }
        if(callbacks && typeof callbacks.onCancelBroadcastAttendeeResult == "function"){
            this.confNotifyFuncs[12] = callbacks.onCancelBroadcastAttendeeResult;
        }
        tupConfctrl.broadcastAttendee(params,{onBroadcastAttendeeResult:onBroadcastAttendeeResult});
}

function onBroadcastAttendeeResult(data){
     confNotifyFuncs[11](data);
}

//This function is used to select attendees
function watchAttendee(params, callbacks){
        if(callbacks && typeof callbacks.onWatchAttendeeResult == "function"){
            this.confNotifyFuncs[15] = callbacks.onWatchAttendeeResult;
        }
        tupConfctrl.watchAttendee(params,{onWatchAttendeeResult:onWatchAttendeeResult});
}

function onWatchAttendeeResult(data){
     confNotifyFuncs[15](data);
}
var meetingNotifyFuncs = new Array();
var meetingRspFuncs = new Array();
var tupMeeting = new TUPMeeting({
    ready: onMeetingReady,
    close: onMeetingClose
});

function onMeetingReady() {
    openDB();
}

function onMeetingClose() {
    closeDB();

}

//This module is used to build indexDB when the page refresh is loaded
var database;
function openDB() {
    var request = window.indexedDB.open("test", 3);
    request.onsuccess = function(event) {
        database = request.result;
        console.log("Create the database successfully");
    };

    request.onerror = function(event) {
        console.log("An error occurred" + request.error);

    };

    request.onupgradeneeded = function(event) {
        console.log("The first time to create a database or update the database");
        var db = request.result;
        var objectStore = db.createObjectStore("AttendeeList", {
            keyPath: "participant_id"
        });

    }
};

//This function is used to add data
function addAttendeeDB(attendee) {
    var transaction = database.transaction(["AttendeeList"], "readwrite");
    var objectStore = transaction.objectStore("AttendeeList");
    var request = objectStore.get(attendee.participant_id);
    request.onsuccess = function(event) {
        var linkRecord = event.target.result;
        if (linkRecord != null) {
            linkRecord.is_deaf = attendee.is_deaf;
            linkRecord.is_mute = attendee.is_mute;
            linkRecord.is_self = attendee.is_self;
            linkRecord.media_type = attendee.media_type;
            linkRecord.name = attendee.name;
            linkRecord.number = attendee.number;
            linkRecord.participant_id = attendee.participant_id;
            linkRecord.role = attendee.role;
            linkRecord.state = attendee.state;
            objectStore.put(linkRecord);
            console.log("update completed");
        } else {
            objectStore.put(attendee);
            console.log("Insert successfully");
        }
    };
    
    request.onerror = function(event) {
        console.log("An error occurred" + request.error);
    };
}

//This function is used to update data
function updateAttendDB(participant_id, dataconf_userid, username) {
    var transaction = database.transaction(["AttendeeList"], 'readwrite');
    var objectStore = transaction.objectStore("AttendeeList");
    var request = objectStore.get(participant_id);
    request.onsuccess = function(event) {
        var linkRecord = event.target.result;
        if (linkRecord != null) {
            linkRecord.dataconf_userid = dataconf_userid;
            linkRecord.username = username;
            linkRecord.media_type = linkRecord.media_type + 16;
            objectStore.put(linkRecord);
            console.log("update completed");
        } else {
            console.log("This data was not found");
        }
    };

    request.onerror = function(event) {
        console.log("An error occurred" + request.error);
    };
}

//This function is used to update the speaker data
function updateAttendPresenterDB(participant_id, participant_type) {
    var transaction = database.transaction(["AttendeeList"], 'readwrite');
    var objectStore = transaction.objectStore("AttendeeList");
    var request = objectStore.get(participant_id);
    request.onsuccess = function(event) {
        var linkRecord = event.target.result;
        console.log("====" + linkRecord);
        if (linkRecord != null) {
            linkRecord.participant_type = participant_type;
            objectStore.put(linkRecord);
            console.log("Participant role was updated successfully");
        } else {
            console.log("This data was not found");
        }
    };

    request.onerror = function(event) {
        console.log("An error occurred" + request.error);
    };
}

//This function is used to display data
function showAttendeeDB() {
    var transaction = database.transaction(["AttendeeList"], "readonly");
    var objectStore = transaction.objectStore("AttendeeList");
    var attendeeList = new Array();
    var i = 0;
    var request = objectStore.openCursor();
    request.onerror = function(event) {
        console.log("发生错误" + request.error);
    };
    request.onsuccess = function(event) {
        //Create a cursor
        var cursor = event.target.result;
        if (cursor) {
            var attendee = cursor.value;
            attendeeList[i] = attendee;
            i = ++i;
            //Call the cursor.continue () method to access the next data, 
            //when the cursor reaches the next one is the onsuccess event again trigger
            cursor.continue();

        } else {
            // No results show the last one
        }
    };
    return attendeeList;

}

//This function is used to delete data
function deleteAttendeeDB(participant_id){
    var transaction = database.transaction(["AttendeeList"], 'readwrite');
    var objectStore = transaction.objectStore("AttendeeList");
    var request = objectStore.delete(participant_id);
    request.onerror = function(event) {
        console.log("An error occurred" + request.error);
    };
    request.onsuccess = function(event) {
        console.log("Participants deleted successfully");
    }
}

//This function is used to empty the database
function clearDB() {
    var transaction = database.transaction(["AttendeeList"], "readwrite");
    var objectStore = transaction.objectStore("AttendeeList");
    objectStore.clear(
        request.onsuccess = function(){  
           console.log("Clear success");
        } 
    );
}

//This function is used to close the database
function closeDB() {
    setTimeout(function() {
        database.close();
        indexedDB.deleteDatabase("test");
    }, 500);
}

//Initialize the notification function
function setBasicMeetingEvent(callbacks) {
    if (callbacks && typeof callbacks.onUserEnterInd == "function") {
        meetingNotifyFuncs[1109] = callbacks.onUserEnterInd;
    }
    if (callbacks && typeof callbacks.hostChangeInd == "function") {
        meetingNotifyFuncs[1101] = callbacks.hostChangeInd;
    }
    if (callbacks && typeof callbacks.presenterChangeInd == "function") {
        meetingNotifyFuncs[1105] = callbacks.presenterChangeInd;
    }
    if (callbacks && typeof callbacks.onAsOnScreenData == "function") {
        meetingNotifyFuncs[2111] = callbacks.onAsOnScreenData;
    }
    if (callbacks && typeof callbacks.hostChangeCfm == "function") {
        meetingNotifyFuncs[1102] = callbacks.hostChangeCfm;
    }
    if (callbacks && typeof callbacks.presenterChangeCfm == "function") {
        meetingNotifyFuncs[1106] = callbacks.presenterChangeCfm;
    }
    if (callbacks && typeof callbacks.onUserModifyInd == "function") {
        meetingNotifyFuncs[1111] = callbacks.onUserModifyInd;
    }
    if (callbacks && typeof callbacks.onConfModelUpdate == "function") {
        meetingNotifyFuncs[1006] = callbacks.onConfModelUpdate;
    }
    if (callbacks && typeof callbacks.onLayoutUpdata == "function") {
        meetingNotifyFuncs[1007] = callbacks.onLayoutUpdata;
    }
    if (callbacks && typeof callbacks.onNetStatusReport == "function") {
        meetingNotifyFuncs[1051] = callbacks.onNetStatusReport;
    }
    if (callbacks && typeof callbacks.onFlowControl == "function") {
        meetingNotifyFuncs[1010] = callbacks.onFlowControl;
    }
    if (callbacks && typeof callbacks.onuserLeaveKickout == "function") {
        meetingNotifyFuncs[1003] = callbacks.onuserLeaveKickout;
    }
    if (callbacks && typeof callbacks.onConfLeave == "function") {
        meetingNotifyFuncs[1110] = callbacks.onConfLeave;
    }
    if (callbacks && typeof callbacks.onConfTerminate == "function") {
        meetingNotifyFuncs[1002] = callbacks.onConfTerminate;
    }
    if (callbacks && typeof callbacks.onAsOnSharingSession == "function") {
        meetingNotifyFuncs[2122] = callbacks.onAsOnSharingSession;
    }
    if (callbacks && typeof callbacks.onAsOnSharingState == "function") {
        meetingNotifyFuncs[2121] = callbacks.onAsOnSharingState;
    }
    if (callbacks && typeof callbacks.onDocNew == "function") {
        meetingNotifyFuncs[2201] = callbacks.onDocNew;
    }
    if (callbacks && typeof callbacks.onPageNew == "function") {
        meetingNotifyFuncs[2203] = callbacks.onPageNew;
    }
    if (callbacks && typeof callbacks.onCurrentPageInd == "function") {
        meetingNotifyFuncs[2205] = callbacks.onCurrentPageInd;
    }
    if (callbacks && typeof callbacks.onDocDel == "function") {
        meetingNotifyFuncs[2202] = callbacks.onDocDel;
    }
    if (callbacks && typeof callbacks.onPageDel == "function") {
        meetingNotifyFuncs[2204] = callbacks.onPageDel;
    }
    if (callbacks && typeof callbacks.onWbDocDel == "function") {
        meetingNotifyFuncs[2802] = callbacks.onWbDocDel;
    }
    if (callbacks && typeof callbacks.onWbPageDel == "function") {
        meetingNotifyFuncs[2804] = callbacks.onWbPageDel;
    }
    if (callbacks && typeof callbacks.onDrawDataNotify == "function") {
        meetingNotifyFuncs[2210] = callbacks.onDrawDataNotify;
    }
    if (callbacks && typeof callbacks.onWbdrawDataNotify == "function") {
        meetingNotifyFuncs[2808] = callbacks.onWbdrawDataNotify;
    }
    if (callbacks && typeof callbacks.onAsSaveResult) {
        meetingRspFuncs[693] = callbacks.onAsSaveResult;
    }
    if (callbacks && typeof callbacks.onWbCurrentPageInd == "function") {
        meetingNotifyFuncs[2805] = callbacks.onWbCurrentPageInd;
    }
    if (callbacks && typeof callbacks.onPresenterChangeInd == "function") {
        meetingNotifyFuncs[1105] = callbacks.onPresenterChangeInd;
    }
    if (callbacks && typeof callbacks.onHostChangeInd == "function") {
        meetingNotifyFuncs[1101] = callbacks.onHostChangeInd;
    }
    if (callbacks && typeof callbacks.onAsOnJsonGetParam == "function") {
        meetingNotifyFuncs[2161] = callbacks.onAsOnJsonGetParam;
    }

    tupMeeting.setBasicMeetingEvent({
        onUserEnterInd: onUserEnterInd,
        onPresenterChangeInd: onPresenterChangeInd,
        onHostChangeInd: onHostChangeInd,
        onAsOnScreenData: onAsOnScreenData,
        hostChangeCfm: hostChangeCfm,
        presenterChangeCfm: presenterChangeCfm,
        onUserModifyInd: onUserModifyInd,
        onConfModelUpdate: onConfModelUpdate,
        onLayoutUpdata: onLayoutUpdata,
        onNetStatusReport: onNetStatusReport,
        onFlowControl: onFlowControl,
        onuserLeaveKickout: onuserLeaveKickout,
        onConfLeave: onConfLeave,
        onConfTerminate: onConfTerminate,
        onAsOnSharingSession: onAsOnSharingSession,
        onAsOnSharingState: onAsOnSharingState,
        onDocNew: onDocNew,
        onPageNew: onPageNew,
        onCurrentPageInd: onCurrentPageInd,
        onDocDel: onDocDel,
        onPageDel: onPageDel,
        onWbDocDel: onWbDocDel,
        onWbPageDel: onWbPageDel,
        onDrawDataNotify: onDrawDataNotify,
        onWbCurrentPageInd: onWbCurrentPageInd,
        onVideoDecoderYUV: onVideoDecoderYUV,
        onVideoPreprocessYUV: onVideoPreprocessYUV,
        onVideoOnSwitch: onVideoOnSwitch
    });
}

function onUserEnterInd(data) {
    if (typeof meetingNotifyFuncs[1109] == "function") {
        meetingNotifyFuncs[1109](data.param);
    } else {
        //Failed to join meeting
    }

}

function onPresenterChangeInd(data) {
    meetingNotifyFuncs[1105](data.param);
}

function onHostChangeInd(data) {
    meetingNotifyFuncs[1101](data.param);
}

var i = 1;

function onAsOnScreenData(data) {
    meetingNotifyFuncs[2111](data.param);
}

function onAsSaveResult(data) {
    meetingRspFuncs[693](data.param);
}

function hostChangeCfm(data) {
    console.log(data);

}

function presenterChangeCfm(data) {
    console.log(data);

}

function onUserModifyInd(data) {
    console.log(data);

}

function onConfModelUpdate(data) {
    console.log(data);

}

function onLayoutUpdata(data) {
    console.log(data);

}

function onNetStatusReport(data) {
    console.log(data);

}

function onFlowControl(data) {
    console.log(data);

}

function onDocNew(data) {
    if (data.param.value1 != 0) {
        sessionStorage.meetingDOCId = data.param.value1;
        meetingNotifyFuncs[2201](data.param);
    }
}

function onPageNew(data) {
    if (data.param.value1 != 0) {
        sessionStorage.meetingDOCId = data.param.value1;
        sessionStorage.meetingPageId = data.param.value2;
        meetingNotifyFuncs[2203](data);
    }

}

function onuserLeaveKickout(data) {
    meetingNotifyFuncs[1003](data);
    tupMeeting.release(parseInt(sessionStorage.meetingConfHandle)); 
    sessionStorage.removeItem("meetingConfHandle");
}

function onConfLeave(data) {
    meetingNotifyFuncs[1110](data.param);

}

function onConfTerminate(data) {
    meetingNotifyFuncs[1002](data.param);
}

function onAsOnSharingSession(data) {
    if (data.param.value1 == 1 && data.param.value2 == 1) {
        var sharingtype = sessionStorage.sharingtype;
        if (sharingtype == 0) {
            tupMeeting.asSetSharetype(parseInt(sessionStorage.meetingConfHandle), 0);
            tupMeeting.asStart(parseInt(sessionStorage.meetingConfHandle)); //Turn on screen sharing
        } else if (sharingtype == 1) {
            tupMeeting.asSetSharetype(parseInt(sessionStorage.meetingConfHandle), 1);
            tupMeeting.asGetapplist(parseInt(sessionStorage.meetingConfHandle), { onAsOnJsonGetParam: onAsOnJsonGetParam }); //Gets the list of open programs
        }
        meetingNotifyFuncs[2122](data.param);
    } else if (data.param.value1 == 0 && data.param.value2 == 1) {

    } else if (data.param.value1 == 1 && data.param.value2 == 0) {
        //Share release notification
    }
}

// Get the list of programs
function onAsOnJsonGetParam(data) {
    meetingNotifyFuncs[2161](data.param);
}

function onAsOnSharingState(data) {
    if (data.param.value2 == 0) {

    }
    meetingNotifyFuncs[2121](data.param);
}

function onDocDel(data) {
    if (data.param.value2 == 0) {

    }
    meetingNotifyFuncs[2202](data.param);
}

function onPageDel(data) {
    if (data.param.value2 == 0) {

    }
    meetingNotifyFuncs[2204](data.param);
}

function onWbDocDel(data) {
    if (data.param.value2 == 0) {

    }
    meetingNotifyFuncs[2802](data.param);
}

function onWbPageDel(data) {
    if (data.param.value2 == 0) {

    }
    meetingNotifyFuncs[2804](data.param);
}

function onCurrentPageInd(data) {
    if (data.param.value2 != 0) {
        sessionStorage.meetingDOCId = data.param.value1;
        sessionStorage.meetingPageId = data.param.value2;
        meetingNotifyFuncs[2205](data.param);
        dsSetCurrentPage(parseInt(sessionStorage.meetingPageId), parseInt(sessionStorage.meetingDOCId), 1, 0);
    }
}

function onDrawDataNotify(data) {
    meetingNotifyFuncs[2210](data.param);
}

function onWbdrawDataNotify(data) {
    if (data.param.value2 != 0) {
        tupMeeting.dsGetSurfacebmp(1425, parseInt(sessionStorage.meetingConfHandle), 975);
    }
    meetingNotifyFuncs[2808](data.param);
}

this.canvas = null;
this.viewW = null;
this.viewH = null;

function onVideoDecoderYUV(data) {

}

function onVideoPreprocessYUV(data) {

}

function CreateConference(meetingTitle, meetingOption, meetingUserType, meetingUserID, meetingUserName, meetingHostKey, meetingConfID, meetingEncryptionKey, meetingSiteId, meetingSiteUrl, meetingServerIp,meetingServerInterip, meetingUserCapability, meetingHandle, meetingLogUrl, userM, userT, callbacks) {
    if (callbacks && typeof callbacks.response == "function") {
        meetingRspFuncs[1] = callbacks.response;
    }
    tupMeeting.new(meetingHostKey, meetingTitle, meetingUserID, meetingOption, meetingSiteId, meetingUserType, meetingSiteUrl, meetingServerIp,meetingServerInterip, meetingEncryptionKey, meetingConfID, meetingUserCapability, meetingHandle, meetingUserName, meetingLogUrl, userM, userT, { response: onConferenceNewResult });
}

//This function is used to join conference.
function JoinConference(confHandle, callbacks) {
    if (callbacks && typeof callbacks.onJoinConference == "function") {
        meetingNotifyFuncs[1001] = callbacks.onJoinConference;
    }
    tupMeeting.join(confHandle, { onJoinConference: onJoinConference });
}

function onConferenceNewResult(data) {
    if (typeof meetingRspFuncs[1] == "function") {
        if (data.param.result == 0) {
            sessionStorage.meetingConfHandle = data.param.confHandle;
            JoinConference(parseInt(sessionStorage.meetingConfHandle));
        } else {

        }
        meetingRspFuncs[1](data.param.result);
    }
}

function onWbCurrentPageInd(data) {
    if (data.param.value2 != 0) {
        sessionStorage.meetingDOCId = data.param.value1;
        sessionStorage.meetingPageId = data.param.value2;
        meetingNotifyFuncs[2805](data.param);
        dsSetCurrentPage(parseInt(sessionStorage.meetingPageId), parseInt(sessionStorage.meetingDOCId), 512, 0);
    }

}

function onJoinConference(data) {
    if (typeof meetingNotifyFuncs[1001] == "function") {

        meetingNotifyFuncs[1001](data.param.result);
    }
    //After the success of the membership, the component ID is passed according to the actual needs
    tupMeeting.loadComponent(parseInt(sessionStorage.meetingConfHandle), 523, { onComponentLoad: onComponentLoad });
    function onComponentLoad(data) {
        if (data.param.value2 == 1) {
            tupMeeting.dsSetBgcolor(16777215, parseInt(sessionStorage.meetingConfHandle), 1); //Set the document canvas background color
            tupMeeting.dsSetDispmode(parseInt(sessionStorage.meetingConfHandle), 1, 0); //Set the document module display mode
            tupMeeting.dsSetCanvasSize(parseInt(sessionStorage.meetingConfHandle), 1, 1, { "cx": 11250, "cy": 9750 }); //Set the canvas size
            //Initialize the annotation resource
            annotationInit(1);
        } else if (data.param.value2 == 512) {
            tupMeeting.dsSetBgcolor(16777215, parseInt(sessionStorage.meetingConfHandle), 512); //Set the document canvas background color
            tupMeeting.dsSetDispmode(parseInt(sessionStorage.meetingConfHandle), 512, 0); //Set the document module display mode
            tupMeeting.dsSetCanvasSize(parseInt(sessionStorage.meetingConfHandle), 512, 1, { "cx": 11250, "cy": 9750 }); //Set the canvas size
            //Initialize the annotation resource
            annotationInit(512);
        } else if (data.param.value2 == 2) {
            //Initialize the annotation resource
            annotationInit(2);
        } else if (data.param.value2 == 8) {
            console.log("The video component is loaded");
        }
    }
}

//This function is used to terminate conference.
function TerminateConference(callbacks) {
    if (callbacks && typeof callbacks.response == "function") {
        meetingRspFuncs[102] = callbacks.response;
    }
    tupMeeting.terminate(parseInt(sessionStorage.meetingConfHandle), { response: onconfTerminate });
}

function onconfTerminate(data) {
    if (typeof meetingRspFuncs[102] == "function") {
        meetingRspFuncs[102](data.param.result);
    }
    tupMeeting.release(parseInt(sessionStorage.meetingConfHandle));
    sessionStorage.removeItem("meetingConfHandle");
}

//This function is used to leave conference.
function LeaveConference(callbacks) {
    if (callbacks && typeof callbacks.response == "function") {
        meetingRspFuncs[101] = callbacks.response;
    }
    tupMeeting.leave(parseInt(sessionStorage.meetingConfHandle), { response: onuserLeave });
}

function onuserLeave(data) {
    if (typeof meetingRspFuncs[101] == "function") {
        meetingRspFuncs[101](data.param.result);
    }
    tupMeeting.release(parseInt(sessionStorage.meetingConfHandle));
    sessionStorage.removeItem("meetingConfHandle");
}

//This function is used to mute conference.
function ConfMute() {

    tupMeeting.mute(0, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to lock conference.
function ConfLock() {

    tupMeeting.lock(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to get host of the conference.
function ConfUserGetHost(callbacks) {

    tupMeeting.userGetHost(parseInt(sessionStorage.meetingConfHandle), callbacks);
}

//This function is used to get presenter of the conference.
function UserGetPresenter(callbacks) {

    tupMeeting.userGetPresenter(parseInt(sessionStorage.meetingConfHandle), callbacks);
}

//This function is used to kickout user.
function ConfUserKickout(userid) {

    tupMeeting.userKickout(parseInt(sessionStorage.meetingConfHandle), userid);
}

//This function is used to set user role.
function ConfUserSetRole(roleType, userid) {

    tupMeeting.userSetRole(roleType, parseInt(sessionStorage.meetingConfHandle), userid);
}

//This function is used to request role.
function ConfUserRequestRole(roleType, rolePassword) {

    tupMeeting.userRequestRole(parseInt(sessionStorage.meetingConfHandle), roleType, rolePassword);
}

//This function is used to set IP list.
function ConfSetIpList() {

    tupMeeting.setiplist(parseInt(sessionStorage.meetingConfHandle), "10.177.28.99");
}

//This function is used to log delete.
function ConfLogDelete() {

    tupMeeting.logDelete(parseInt(sessionStorage.meetingConfHandle), 20);
}

//This function is used to flow control limit.
function ConfFlowcontrolLimit() {

    tupMeeting.flowcontrolLimit(4, parseInt(sessionStorage.meetingConfHandle), 262144);
}

//This function is used to update param.
function ConfUpdateParam() {

    tupMeeting.updateParam("paramtest", parseInt(sessionStorage.meetingConfHandle), "host", 10);
}

//This function is used to start screen sharing.
function ConfAsStart(userid) {

    tupMeeting.asSetOwner(1, parseInt(sessionStorage.meetingConfHandle), userid);

}

//This function is used to start the program sharing.
function ConfSetsharingapp(pappwnd) {
    tupMeeting.asSetsharingapp(1, parseInt(sessionStorage.meetingConfHandle), pappwnd); //action 0 delete 1 add
    tupMeeting.asStart(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to end screen sharing.
function ConfAsStop(userid) {

    tupMeeting.asStop(parseInt(sessionStorage.meetingConfHandle));
    tupMeeting.asSetOwner(0, parseInt(sessionStorage.meetingConfHandle), userid);
}

//This function is used to request remote control permissions.
function ConfAsRequestPrivilege() {

    tupMeeting.asRequestPrivilege(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to set remote control permissions.
function ConfAsSetPrivilege(privilege, action, userid) {

    tupMeeting.asSetPrivilege(privilege, action, parseInt(sessionStorage.meetingConfHandle), userid);
}

//This function is used to remote control input control information.
function ConfAsInputWndMsg(msgid, lparam, wparam, pt) {
    tupMeeting.asInputWndMsg(parseInt(sessionStorage.meetingConfHandle), msgid, lparam, wparam, pt);
}

//This function is used to start screen sharing annotation.
function ConfAsBeginAnnotation() {

    tupMeeting.asBeginAnnotation(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to end screen sharing annotation.
function ConfAsEndAnnotation() {

    tupMeeting.asEndAnnotation(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to screen sharing request key frame.
function ConfAsRequestKeyframe() {

    tupMeeting.asRequestKeyframe(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to open video.
var lcCanvas = null;
var viewW = null;
var viewH = null;
var meettingUserid = 0;

function ConfVideoOpen(videoParam) {
    lcCanvas = videoParam.lcCanvas;
    viewW = videoParam.width;
    viewH = videoParam.height;
    meettingUserid = videoParam.userid;
    tupMeeting.videoGetDeviceinfo(parseInt(sessionStorage.meetingConfHandle), { onVideoOnGetDeviceInfo: onVideoOnGetDeviceInfo });
}

var deviceid = null;

function onVideoOnGetDeviceInfo(data) {
    if (data.param.value1 == 0) {
        deviceid = data.param.value2;
        tupMeeting.videoSetparam(viewH, 15, 0, 0, viewW, parseInt(meettingUserid), parseInt(sessionStorage.meetingConfHandle), data.param.value2, 0, { response: onVideoSetparamResult });
        function onVideoSetparamResult(data) {
            if (data.param.result == 0) {
                //Need to get the device ID from the current callback to open the video
                tupMeeting.videoOpen(parseInt(sessionStorage.meetingConfHandle), 1, deviceid); 
            }
        }
    }

}

//This function is used to open video.
var remoteNumber = 0;
var rtCanvas = new Array();
var rtName = new Array();
var rtCanvas0;
var rtCanvas1;
var rtCanvas2;
var localR;

function onVideoOnSwitch(data) {
    var reCanvasName = [rtCanvas0, rtCanvas1, rtCanvas2];
    rtCanvas = [$('#meetingRemoteCanvas1')[0], $('#meetingRemoteCanvas2')[0], $('#meetingRemoteCanvas3')[0]];
    if (1 == data.param.value1 && data.param.value2 == meettingUserid && typeof localR == "undefined") {
        localR = new TUPRender({ getUri: meettingUserid, serviceName: "tup_dataconf_video_service_protocol", canvas: lcCanvas });
        localR.setViewWH(320, 240);
    } else if (1 == data.param.value1 && data.param.value2 == meettingUserid && typeof localR != "undefined") {
        localR.setViewWH(320, 240);
    } else if (1 == data.param.value1 && remoteNumber <= rtCanvas.length && typeof reCanvasName[remoteNumber] == "undefined") {
        reCanvasName[remoteNumber] = new TUPRender({ getUri: data.param.value2, serviceName: "tup_dataconf_video_service_protocol", canvas: rtCanvas[remoteNumber] });
        reCanvasName[remoteNumber].setViewWH(320, 240);
        rtName[remoteNumber] = data.param.value2;
        remoteNumber = ++remoteNumber;
    } else if (1 == data.param.value1 && remoteNumber <= rtCanvas.length && typeof reCanvasName[0] != "undefined") {
        reCanvasName[remoteNumber].setViewWH(320, 240);
    } else if (0 == data.param.value1) {
        console.log("close video");
    } else {
        console.log("The video is out of limit and the opening fails!");
    }
}

//This function is used to close video.
function ConfVideoClose() {
    tupMeeting.videoClose(parseInt(sessionStorage.meetingConfHandle), deviceid);
    localR.setViewWH(0, 0);
}

//This function is used to pause video.
function ConfVideoPause() {
    tupMeeting.videoPause(0, parseInt(sessionStorage.meetingConfHandle), 125, 0);
}

//This function is used to resume video.
function ConfVideoResume() {
    tupMeeting.videoResume(parseInt(sessionStorage.meetingConfHandle), 125, 0);
}

//This function is used to new doc.
function ConfDsNewDoc(callbacks) {
    if (callbacks && typeof callbacks.onWbDocNew == "function") {
        meetingNotifyFuncs[2801] = callbacks.onWbDocNew;
    }
    tupMeeting.dsNewDoc(parseInt(sessionStorage.meetingConfHandle), { onWbDocNew: onWbDocNew });
}

function onWbDocNew(data) {
    if (data.param.value1 != 0 && data.param.value2 != 0) {
        //Save the document information
        sessionStorage.meetingDOCId = data.param.value1;
        //The new whiteboard page needs to get the whiteboard document ID from the callback
        tupMeeting.dsNewPage(500, parseInt(sessionStorage.meetingConfHandle), data.param.value1, 500,{onWbPageNew:onWbPageNew});
        meetingNotifyFuncs[2801](data);
        tupMeeting.dsSetCurrentPage(1, parseInt(sessionStorage.meetingConfHandle), 512, parseInt(sessionStorage.meetingDOCId), 0);
    } else {
        //New document failed
    }
}

function onWbPageNew(data){
    sessionStorage.meetingDOCId = data.param.value1;
    sessionStorage.meetingPageId = data.param.value2;
}

//This function is used to delete doc.
function ConfDsDeleteDoc() {
    tupMeeting.dsDeleteDoc(parseInt(sessionStorage.meetingConfHandle), parseInt(sessionStorage.meetingDOCId));
}

//This function is used to delete page.
function ConfDsDeletePage() {
    tupMeeting.dsDeletePage(parseInt(sessionStorage.meetingPageId), parseInt(sessionStorage.meetingConfHandle), parseInt(sessionStorage.meetingDOCId));
}

//This function is used to start document sharing.
function ConfDsOpen(filename, callbacks) {
    if (callbacks && typeof callbacks.response == "function") {
        meetingRspFuncs[400] = callbacks.response;
    }
    tupMeeting.dsOpen(parseInt(sessionStorage.meetingConfHandle), filename, { response: dsOpenResult });
}

function dsOpenResult(data) {
    meetingRspFuncs[400](data.param.result);
}

//This function is used to synchronize document data (attendees synchronize to the server).
function dsGetSyncinfo(callbacks) {
    if (callbacks && typeof callbacks.onDsSyncInfo == "function") {
        meetingNotifyFuncs[2220] = callbacks.onDsSyncInfo;
    }
    tupMeeting.dsGetSyncinfo(parseInt(sessionStorage.meetingConfHandle), 1, { onDsSyncInfo: onDsSyncInfo });
}

function onDsSyncInfo(data) {
    dsSetCurrentPage(data.param.value2, data.param.value1, 1, 0);
    meetingNotifyFuncs[2220](data.param);
}

//This function is used to set the current page.
function dsSetCurrentPage(meetingPageId, meetingDOCId, ciid, sync, callbacks) {
    if (callbacks && typeof callbacks.response == "function") {
        meetingRspFuncs[402] = callbacks.response;
    }
    if (callbacks && typeof callbacks.onCurrentPage == "function") {
        meetingNotifyFuncs[2206] = callbacks.onCurrentPage;
    }
    if (callbacks && typeof callbacks.onWBCurrentPage == "function") {
        meetingNotifyFuncs[2806] = callbacks.onWBCurrentPage;
    }
    tupMeeting.dsSetCurrentPage(meetingPageId, parseInt(sessionStorage.meetingConfHandle), ciid, meetingDOCId, sync, { response: onSetCurrentPageResult, onCurrentPage: onCurrentPage, onWBCurrentPage: onWBCurrentPage });
    // tupMeeting.dsGetSurfacebmp(500, parseInt(sessionStorage.meetingConfHandle), 500);
}

function onSetCurrentPageResult(data) {
    if (data.param.result == 1102) {
        meetingRspFuncs[402](true);
    }
}

function onCurrentPage(data) {
    if (data.param.value2 != 0) {
        sessionStorage.meetingDOCId = data.param.value1;
        sessionStorage.meetingPageId = data.param.value2;
        meetingNotifyFuncs[2206](data);
    }
}

function onWBCurrentPage(data) {
    if (data.param.value2 != 0) {
        sessionStorage.meetingDOCId = data.param.value1;
        sessionStorage.meetingPageId = data.param.value2;
        meetingNotifyFuncs[2806](data);
    }
}

//This function is used to end document sharing.
function ConfDsClose() {
    tupMeeting.dsClose(parseInt(sessionStorage.meetingConfHandle), parseInt(sessionStorage.meetingDOCId));
}

//This function is used to rotate the document page background.
function ConfDsRotatePage() {
    tupMeeting.dsRotatePage(2, parseInt(sessionStorage.meetingConfHandle), 1, 1, 90);
}

//This function is used to set zoom.
function ConfDsSetZoom() {
    tupMeeting.dsSetZoom(1, 1, 4, 1, 50, parseInt(sessionStorage.meetingConfHandle), 1);
}

//This function is used to set canvas background color.
function ConfDsSetBgcolor() {
    tupMeeting.dsSetBgcolor(0x00FF00FF, parseInt(sessionStorage.meetingConfHandle), 1);
}

//This function is used to set the document display mode.
function ConfDsSetDispmode() {
    tupMeeting.dsSetDispmode(parseInt(sessionStorage.meetingConfHandle), 1, 0); 
}

//This function is used to save document.
function ConfDsSave(docid, filename) {
    tupMeeting.dsSave(parseInt(sessionStorage.meetingConfHandle), 1, docid, filename);
}

//This function is used to annotated.
function annotationInit(ciid) {
    tupMeeting.annotationRegCustomerType(parseInt(sessionStorage.meetingConfHandle), ciid);
    tupMeeting.annotationInitResource(parseInt(sessionStorage.meetingConfHandle), ciid);
    tupMeeting.annotationSetConfig(parseInt(sessionStorage.meetingConfHandle), ciid);
    tupMeeting.annotationSetPen(parseInt(sessionStorage.meetingConfHandle), ciid, { "style": 0, "color": 128, "width": 75 }, 1);
    tupMeeting.annotationSetBrush(parseInt(sessionStorage.meetingConfHandle), ciid, { "style": 0, "color": 128 });
}

//This function is used to start creating annotations.
function annotationCreateStart(point, subtype, ciid, type) {
    if (ciid == 2) {
        var meetingDOCId = 0;
        var meetingPageId = 0;
    } else {
        var meetingDOCId = parseInt(sessionStorage.meetingDOCId);
        var meetingPageId = parseInt(sessionStorage.meetingPageId);
    }
    tupMeeting.annotationCreateStart(meetingPageId, point, subtype, meetingDOCId, parseInt(sessionStorage.meetingConfHandle), ciid, type);
}

//This function is used to update a annotation  (custom graphics).
function annotationCreateCustomerUpdate(ciid, pdata) {

    tupMeeting.annotationCreateCustomerUpdate(parseInt(sessionStorage.meetingConfHandle), ciid, pdata);
}

//This function is used to update a annotation  (Geometric graphics).
function annotationCreateDrawingUpdate(ciid, pdata) {

    tupMeeting.annotationCreateDrawingUpdate(parseInt(sessionStorage.meetingConfHandle), ciid, pdata);
}

//This function is used to complete creation.
function annotationCreateDone(ret_annoid, ciid, bCancel) {
    tupMeeting.annotationCreateDone(ret_annoid, parseInt(sessionStorage.meetingConfHandle), ciid, bCancel);
}

//This function is used to select annotation.
function annotationSetselect(selectmode, ciid, annoid) {
    tupMeeting.annotationSetselect(selectmode, parseInt(sessionStorage.meetingConfHandle), ciid, annoid, parseInt(sessionStorage.meetingDOCId), parseInt(sessionStorage.meetingPageId));
}

//This function is used to delete annotation.
function annotationDelete(ciid, ids) {
    tupMeeting.annotationDelete(parseInt(sessionStorage.meetingConfHandle), ciid, ids, parseInt(sessionStorage.meetingPageId), parseInt(sessionStorage.meetingDOCId));
}

//This function is used to start edit annotation.
function annotationEditStart(refannotid, edittype, ciid, startpoint, annoid) {
    tupMeeting.annotationEditStart(parseInt(sessionStorage.meetingPageId), refannotid, edittype, parseInt(sessionStorage.meetingDOCId), parseInt(sessionStorage.meetingConfHandle), ciid, startpoint, annoid);
}

//This function is used to update edit annotation.
function annotationEditUpdate(ciid, currentpoint) {
    tupMeeting.annotationEditUpdate(parseInt(sessionStorage.meetingConfHandle), ciid, currentpoint);
}

//This function is used to end edit annotation.
function annotationEditDone(cancel, ciid) {
    tupMeeting.annotationEditDone(cancel, parseInt(sessionStorage.meetingConfHandle), ciid);
}

//This function is used to create text annotation.
function annotationTextCreate(pInfo, ret_annoid, ciid) {
    tupMeeting.annotationTextCreate(parseInt(sessionStorage.meetingPageId), pInfo, ret_annoid, parseInt(sessionStorage.meetingDOCId), parseInt(sessionStorage.meetingConfHandle), ciid);
}

//This function is used to update text annotation.
function annotationTextUpdate(redraw, pInfo, ciid, annoid, callbacks) {
    tupMeeting.annotationTextUpdate(redraw, parseInt(sessionStorage.meetingPageId), pInfo, parseInt(sessionStorage.meetingDOCId), parseInt(sessionStorage.meetingConfHandle), ciid, annoid);
}

//This function is used to end edit annotation.
function annotationTextGetinfo(ciid, annoid, callbacks) {
    if (callbacks && typeof callbacks.onAnnoTextGetInfo == "function") {
        meetingNotifyFuncs[2903] = callbacks.onAnnoTextGetInfo;
    }
    tupMeeting.annotationTextGetinfo(parseInt(sessionStorage.meetingPageId), parseInt(sessionStorage.meetingConfHandle), ciid, parseInt(sessionStorage.meetingDOCId), annoid, { onAnnoTextGetInfo: onAnnoTextGetInfo });
}

function onAnnoTextGetInfo(data) {
    meetingNotifyFuncs[2903](data.param);
}

//This function is used to hittest annotation on point.
function annotationHittest(pt, hitmode, ciid, callbacks) {
    if (callbacks && typeof callbacks.onAnnoHittest == "function") {
        meetingNotifyFuncs[2904] = callbacks.onAnnoHittest;
    }
    tupMeeting.annotationHittest(parseInt(sessionStorage.meetingPageId), pt, hitmode, parseInt(sessionStorage.meetingDOCId), parseInt(sessionStorage.meetingConfHandle), ciid, { onAnnoHittest: onAnnoHittest });
}

function onAnnoHittest(data) {
    meetingNotifyFuncs[2904](data.param);
}

//This function is used to hittest annotation in rectangle.
function annotationHittestRect() {
    tupMeeting.annotationHittestRect(parseInt(sessionStorage.meetingConfHandle), ciid, rect);
}

//This function is used to start the laser point.
function annotationLaserpointerStart(ciid, ptOffset, dispSize) {
    tupMeeting.annotationLaserpointerStart(0, 6, ptOffset, 0, 0, 0, 0, 1, parseInt(sessionStorage.meetingConfHandle), ciid, dispSize);
}

//This function is used to move the laser point.
function annotationLaserpointerMoveto(ciid, pdata) {
    tupMeeting.annotationLaserpointerMoveto(parseInt(sessionStorage.meetingConfHandle), ciid, pdata);
}

//This function is used to stop the laser point.
function annotationLaserpointerStop(ciid) {
    tupMeeting.annotationLaserpointerStop(parseInt(sessionStorage.meetingConfHandle), ciid);
}


function onaudioJsonDeviceNum() {
    //The number of audio devices is taken from the callback
    tupMeeting.audioGetDevice(TRUE, parseInt(sessionStorage.meetingConfHandle), 1, { onaudioJsonDeviceInfo: onaudioJsonDeviceInfo });
}

function onaudioJsonDeviceInfo() {

    tupMeeting.audioOpen(parseInt(sessionStorage.meetingConfHandle), 0, TRUE);
}

//This function is used to close audio.
function ConfAudioClose() {

    tupMeeting.audioClose(parseInt(sessionStorage.meetingConfHandle), TRUE);
}

//This function is used to lock conference.
function ConfLock() {

    tupMeeting.lock(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to set audio volume.
function ConfAudioSetVolume() {

    tupMeeting.audioSetVolume(parseInt(sessionStorage.meetingConfHandle), 80, FALSE, TRUE, { audioJsonDeviceInfo: onaudioJsonDeviceInfo });
}

//This function is used to get audio volume.
function ConfAudioGetVolume() {

    tupMeeting.audioGetVolume(parseInt(sessionStorage.meetingConfHandle), FALSE, TRUE);
}

//This function is used to play audio file.
function ConfAudioPlayFile() {

    tupMeeting.audioPlayFile(1, parseInt(sessionStorage.meetingConfHandle), "filename", 0, 0);
}

//This function is used to stop audio file.
function ConfAudioStopPlayFile() {

    tupMeeting.audioStopPlayFile(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to mute telephone conference.
function ConfPhoneConfMute() {

    tupMeeting.phoneConfMute(parseInt(sessionStorage.meetingConfHandle), TRUE);
}

//This function is used to lock telephone conference.
function ConfPhoneConfLock() {

    tupMeeting.phoneConfLock(parseInt(sessionStorage.meetingConfHandle), TRUE);
}

//This function is used to extend telephone conference.
function ConfPhoneConfExtend() {

    tupMeeting.phoneConfExtend(parseInt(sessionStorage.meetingConfHandle), 100);
}

//This function is used to kickout telephone conference.
function ConfPhoneCallKillOff() {

    tupMeeting.phoneCallKillOff(parseInt(sessionStorage.meetingConfHandle), 1);
}

//This function is used to call telephone user.
function ConfPhoneCallOut() {

    tupMeeting.phoneCallOut(parseInt(sessionStorage.meetingConfHandle), 1);
}

//This function is used to mute telephone user.
function ConfPhoneCallMute() {

    tupMeeting.phoneCallMuteSpeaker(parseInt(sessionStorage.meetingConfHandle), 1, TRUE);
}

//This function is used to recall telephone user.
function ConfPhoneCallRecall() {

    tupMeeting.phoneCallRecall(parseInt(sessionStorage.meetingConfHandle), 1);
}

//This function is used to request chairman.
function ConfPhoneConfChairmanReq() {

    tupMeeting.phoneConfChairmanReq(1, parseInt(sessionStorage.meetingConfHandle), 123456);
}

//This function is used to release chairman.
function ConfPhoneCallChairmanRelease() {

    tupMeeting.phoneConfChairmanRelease(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to hang up telephone user.
function ConfPhoneCallHangup() {

    tupMeeting.phoneCallHangup(parseInt(sessionStorage.meetingConfHandle), 1);
}

//This function is used to broadcast telephone user.
function ConfPhoneCallBroadcast() {

    tupMeeting.phoneConfBroadcast(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to active voice.
function ConfPhoneConfVoiceActive() {

    tupMeeting.phoneConfVoiceActive(parseInt(sessionStorage.meetingConfHandle), TRUE);
}

//This function is used to open free discussion.
function ConfPhoneConfFreeDiscuss() {

    tupMeeting.phoneConfFreeDiscuss(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to raised hand.
function ConfPhoneConfRaiseHand() {

    tupMeeting.phoneConfRaiseHand(parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to send an instant message.
function ConfChatSendMsg() {

    tupMeeting.chatSendMsg(parseInt(sessionStorage.meetingConfHandle), 1, 125, "hello world");
}

//This function is used to create group.
function ConfChatCreateGroup() {

    tupMeeting.chatCreateGroup(parseInt(sessionStorage.meetingConfHandle), "groupname", { chatGroupCreate: onchatGroupCreate });
}

//This function is used to destory group.
function ConfChatDestroyGroup() {

    tupMeeting.chatDestroyGroup(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to leave group.
function ConfChatLeaveGroup() {

    tupMeeting.chatLeaveGroup(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to invite users to join group.
function ConfChatInvite() {

    tupMeeting.chatInvite(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to remove the user from the group.
function ConfChatKickout() {

    tupMeeting.chatKickout(1, parseInt(sessionStorage.meetingConfHandle));
}

//This function is used to upload file.
function ConfFtUploadFile() {
    //Upload file to a user or all, need to get file handle from onftOnFileInfo callback
    tupMeeting.ftUploadFile(parseInt(sessionStorage.meetingConfHandle), 125, "filename", { ftOnFileInfo: onftOnFileInfo });
}

//This function is used to cancel uploading file.
function ConfFtCancelUploading() {

    tupMeeting.ftCancelUploading(parseInt(sessionStorage.meetingConfHandle), 125, 1356);
}

//This function is used to remove file.
function ConfFtRemoveFile() {

    tupMeeting.ftRemoveFile(parseInt(sessionStorage.meetingConfHandle), 125, 1356);
}

//This function is used to download file.
function ConfFtDownloadFile() {

    tupMeeting.ftDownloadFile(parseInt(sessionStorage.meetingConfHandle), 1356, "filename");
}

//This function is used to cancel downloading file.
function ConfFtCancelDownloading() {

    tupMeeting.ftCancelDownloading(parseInt(sessionStorage.meetingConfHandle), 125, 1356);
}

//This function is used to pause upload or download.
function ConfFtPause() {

    tupMeeting.ftPause(parseInt(sessionStorage.meetingConfHandle), 1356);
}

//This function is used to resume upload or download.
function ConfFtResume() {

    tupMeeting.ftResume(parseInt(sessionStorage.meetingConfHandle), 1356);
}
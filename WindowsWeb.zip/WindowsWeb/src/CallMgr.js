//This is used to create a object of tupCall, and init the basic configure when wsocket is opened
if(!tupCall){
   var tupCall = new TUPCall({ready : onCallReady, close : onCallClose}); 
}

function onCallReady(){
    var bool = sessionStorage.getItem("callKey");
    if(!bool){
        //unite init call service
        initCallCfg();
        //configure TPT service
        IPTConfig();
        sessionStorage.setItem("callKey", "true");
    }
}
function onCallClose(){
    sessionStorage.removeItem("callKey");
} 

var callNotifyFuncs = new Array();
function registerCallbcak(callbacks){
    if (callbacks && typeof callbacks.onCallIncoming == "function") {
        this.callNotifyFuncs[0] = callbacks.onCallIncoming;
    }
    if (callbacks && typeof callbacks.onCallRingBack == "function") {
        this.callNotifyFuncs[1] = callbacks.onCallRingBack;
    }
    if (callbacks && typeof callbacks.onCallConnected == "function") {
        this.callNotifyFuncs[2] = callbacks.onCallConnected;
    }
    if (callbacks && typeof callbacks.onCallEnded == "function") {
        this.callNotifyFuncs[3] = callbacks.onCallEnded;
    }
    if (callbacks && typeof callbacks.onCallDestroy == "function") {
        this.callNotifyFuncs[4] = callbacks.onCallDestroy;
    }
    if (callbacks && typeof callbacks.onCallAddVideo == "function") {
        this.callNotifyFuncs[5] = callbacks.onCallAddVideo;
    }
    if (callbacks && typeof callbacks.onCallDelVideo == "function") {
        this.callNotifyFuncs[6] = callbacks.onCallDelVideo;
    }    
    if (callbacks && typeof callbacks.onCallModifyVideoResult == "function") {
        this.callNotifyFuncs[7] = callbacks.onCallModifyVideoResult;
    }
    if (callbacks && typeof callbacks.onSpkDevVolumeChange == "function") {
        this.callNotifyFuncs[15] = callbacks.onSpkDevVolumeChange;
    }    
    if (callbacks && typeof callbacks.onMicDevVolumeChange == "function") {
        this.callNotifyFuncs[16] = callbacks.onMicDevVolumeChange;
    }
    if (callbacks && typeof callbacks.onSessionModified == "function") {
        this.callNotifyFuncs[37] = callbacks.onSessionModified;
    }            
}    

//This function is used to set call basic event, it is invoked by corresponding function.
tupCall.setBasicCallEvent({onCallIncoming : onIncoming,
                        onCallOutGoing : onOutGoing,
                        onCallRingBack : onRingBack,
                        onCallConnected : onConnected,
                        onCallEnded : onEnded,
                        onCallDestroy : onDestroy,
                        onCallRtpCreated : onRTPCreated,
                        onSessionModified : onSessionModifiedEvent});

//This function is used to set video call event, it will console log when state change
tupCall.setVideoCallEvent({
    onCallAddVideo : onAddVideo,
    onCallDelVideo : onDelVideo,
    onCallModifyVideoResult : onModifyVideoResult 
});

//This function is used to set callback for volume update, about speak and microphone 
tupCall.setVolumUpdate({onSpeakVolumeChange : onSpkVolChange, onMicVolumeChange : onMicVolChange});

//This variable is used to judge whether play media file 
var curPlayHdl = -1;
//This function is used to start log, 
function startLog(){
    //tupCall.setHMELog();
    tupCall.config({
        log_level: 3, //3 is debug mode, it is suggested
        max_size: 10,
        file_count: 5,        
        log_path : "./jsdemolog"
    }); 
 
}

//This function is used to set sip basic configure
function sipBasicCfg(){
    tupCall.config({
        sip :{
            user_type : 0, //0-NONE, 1- user=phone 2- user=ipcc
            // tls_rootcertpath : "F:/test/cert/root_cert_huawei.pem", //TLS must configure root cert
            tls_anonymous_enable : 1,//TLS anonymous enable mode
            trans_mode : 0 //0-UDP, 1-TLS, 2-TCP
        },        
        call : {
            call_ipcall_enable : 0 //it is used in test period, 0 means disenable
        },
        network :{
            user_agent : "Huawei TE Desktop"
        }
    });
}

//This function is used to set meida security configure.
function securityCfg(){
    tupCall.config({
        media :{
            srtp_mode : 1 //0-not enable， 1-option，2-force
        }
    });
}

//This function is used to set data bfcp configure, it is used in VC meeting.
function dataBfcpCfg(){
    tupCall.config({
        media :{
            enable_bfcp : 0,  //in pbx meeting, it is default to be 0
            enable_data : 0
        }
    });
}

//This function is used to set media configure, including audio and video.
function setMediaCfg(){
    tupCall.config({
        //This is used to set audio configure
        audio :{
            audio_codec : "112,98,18,9,8,0",//112-OPUS, 98-iLBC, 18-G729, 9-G722, 8-G711a, 0-G711u
            dtmf_mode : 0 //0-carry internal send mode，1-rf2833 auto consult，2-force 2833，4-info mode，5-H245
        },

        //This is used to set video configure
        media:{
            video_level :{   //This is used to configure video level and detail limit
                level :  0,  //H264 level {10,11,12,13,20,21,22,30,31,32,40,41,42,50,51}
                max_br : 0,  //H264 max-bmps  0 represent use corresponding level default
                max_fs : 0,  //H264 max-fs    0 represent use corresponding level default
                max_mbps : 0 //H264 max-br    0 represent use corresponding level default
            },
            video_codec :  $.trim("106,34"), //This is used to set video coder priority
            video_framesize :{ //This function is used to set frame size
                decode_framesize :  11, //maximum decode frame size
                min_framesize : 0, //minimum code frame size
                framesize : 11 //code frame size
            },
            video_framerate :{ //This is used to set frame rate
                frame_rate :  30, //frame rate, unit:fps，value from 1 to 30，default is 30
                min_frame_rate : 15 //minimum frame rate, unit:fps, value from 1 to frameRate, default is 15
            },
            clarity_fluency_enable : 0 //This function is used to set clear and smooze, it is need in telerepresent service. 0:enable-UC,1:enable-TE, default is 0 
        }
    });
}

//This function is used to unite init call service.
function initCallCfg(){
    //start log
    startLog();
    //sip basic congiure
    sipBasicCfg();
    //set media configure
    setMediaCfg()
    //data bfcp configure
    dataBfcpCfg();
    //media security configure
    securityCfg();    
}

//This function is used to set sip local configure
function sipLocalCfg(sipSvrAddr, localIpv4, localSipPort){
    tupCall.config({
        network:{
            sip_svr_addr : sipSvrAddr,
            sip_svr_port : 5060, //server default TLS port is 5061
            local_ipv4 : localIpv4,
            local_sip_port : localSipPort,              
        }
    });
}

//This function is used to configure TPT service
function IPTConfig(){
    //call wait
    callWaitCfg();
    //do not disturb
    DNDCfg();
    //uncondition forward
    unConditionForwardCfg();
    //noreply forward
    noReplyForwardCfg();
    //busy forward
    busyForwardCfg();
    //offline forward
    offLineForwardCfg();
}

//This function is used to configure IPT call wait service
function callWaitCfg(){
    tupCall.config({
        call :{
            call_callwait_enable : 0
        },
        service :{
            server_right : {
                type : 39,
                right : 1,
                register : 0,
                active_accesscode : "*43#",  
                deactive_accesscode : "#43#" 
            }
        }
    });
}

//This function is used to configure IPT call do not disturb service
function DNDCfg(){
    tupCall.config({
        service :{
            server_right : {
                type : 13,
                right : 1,
                register : 0,
                active_accesscode : "*56*#",
                deactive_accesscode : "#56#"
            }
        }
    });
}

//This function is used to configure IPT call uncondition forward service
function unConditionForwardCfg(){
    tupCall.config({
        service :{
            server_right : {
                type : 15,
                right : 1,
                register : 0,
                active_accesscode : "**21*",
                deactive_accesscode : "##21#"
            }
        }
    });
}

//This function is used to configure IPT call noreply forward service
function noReplyForwardCfg(){
    tupCall.config({
        service :{
            server_right : {
                type : 17,
                right : 1,
                register : 0,
                active_accesscode : "**61*",
                deactive_accesscode : "##61#"
            }
        }
    });
}

//This function is used to configure IPT call busy forward service
function busyForwardCfg(){
    tupCall.config({
        service :{
            server_right : {
                type : 16,
                right : 1,
                register : 0,
                active_accesscode : "**67*",
                deactive_accesscode : "##67#"
            }
        }
    });
}

//This function is used to configure IPT call offline forward service
function offLineForwardCfg(){
    tupCall.config({
        service :{
            server_right : {
                type : 18,
                right : 1,
                register : 0,
                active_accesscode : "**45*",
                deactive_accesscode : "##45#"
            }
        }
    });
}

//This function is used to set IPT service
function uniteSetIPTService(type, forwardNum){
    if(type>=25 && type <=32){
        tupCall.setForwardIPTService(type, forwardNum);
    } else {
        tupCall.setIPTService(type);
    }
}

//This function is used to register sip
function sipRegister(sipNum, sipName, sipPwd, pwdType, callbacks){
    if (callbacks && typeof callbacks.onRegStatusUpdate == "function") {
        this.callNotifyFuncs[8] = callbacks.onRegStatusUpdate;
    }    
    if (callbacks && typeof callbacks.onForceUnReg == "function") {
        this.callNotifyFuncs[9] = callbacks.onForceUnReg;
    }    
    tupCall.config({
        account:{
            account_pwd_type: pwdType
        }
    });

    tupCall.register(
        sipNum,
        sipName,
        sipPwd,
        {
            onRegStatusUpdate : onSipAccountUpate,
            onForceUnReg : onForcedUnReg
        }
    );
}
//This is callback of sip register, it carry information of sip state.
var userNumber = 0;
function onSipAccountUpate(data){
    userNumber = data.param.user_number;
    var state = ["unregister", "registering", "deregistering", "registered", "deregistered"];
    var reason = data.param.reason_code;
    if(reason == 403) {console.log("403:forbidden");}
    if(reason == 408) { console.log("408:request overtime");}
    var currentState = state[data.param.register_state];
    var obj = {userNum:userNumber, stateInfo:currentState}
    callNotifyFuncs[8](obj);
}

//This callback of force unregister 
function onForcedUnReg(data) {
    callNotifyFuncs[9]();
}

//This function is used to  sip deregister
function sipDeRegister(){
    tupCall.deRegister(userNumber);  
}

var currentCallID = 0;
var callType = 0;
//This function is used to  set video display window
function setAllVideoView(localView, remoteView, dataView)
{
    tupCall.setVideoRender(localView, remoteView);
    tupCall.setDataRender(dataView);
    tupCall.setLocalViewWH(480, 270);
    tupCall.setRemoteViewWH(480, 270);
    tupCall.setDataViewWH(1280, 720);
}

function startCall(calleeNum, startCallType){ 
    tupCall.startCall(calleeNum, startCallType, {response : function(msg){
        sessionStorage.setItem("callId",msg.param.call_id);
    }});
}

function onOutGoing(data){
    currentCallID = data.param.call_id;
}

//This function is used to  call incoming notify
var isIncoming = false;
function onIncoming(data){
    isIncoming = true;
    alertingCall();
    currentCallID = data.param.call_id;
    callType = data.param.call_type;
    var obj = {callType: callType, callerNum: data.param.tel_num}
    callNotifyFuncs[0](obj);
    //incoming(callerNum, callType);
    startMediaPlay("../../../bin/audio/callRing/In.wav");
}

function alertingCall(){
    tupCall.alertingCall(currentCallID);
}

function onRingBack(data){
    var needToRing = data.param.have_sdp;
    callNotifyFuncs[1]();
    if(needToRing){
        startMediaPlay("../../../bin/audio/callRing/ring.wav");
    }
}

//This function is used to according call type, accept call, if it is video call, create video windows
function acceptCall(){
    if(callType == 0){
        tupCall.acceptCall(currentCallID, 0);
    } else {
        tupCall.acceptCall(currentCallID, 1);
    } 
    stopPlayMediaFile();
}

function onConnected(data){
    if(sessionStorage.getItem("callId") || isIncoming){
        callNotifyFuncs[2](data);
        stopPlayMediaFile();
    }
}

//This function is used when a video call is coming, can invoked this method to accept audio call rather than video call
function chooseAudioAccept(){
    tupCall.acceptCall(currentCallID, 0);
}

function endCall(){
    tupCall.endCall(currentCallID); 
}

function onEnded(data){
    var reason = data.param.reason_code;
    if(reason == 404) { console.log("404:Not found");}
    if(reason == 480) { startMediaPlay("../../../bin/audio/callRing/480.wav", 1);}
    if(reason == 481) { startMediaPlay("../../../bin/audio/callRing/481.wav", 1);}
    if(reason == 486) { startMediaPlay("../../../bin/audio/callRing/486.wav", 1);}

    callNotifyFuncs[3](reason);
}

function onDestroy(data){
    if(currentCallID == data.param.call_id){
        currentCallID = 0;
    }
    isIncoming = false;
    stopPlayMediaFile();
    callNotifyFuncs[4]();
    sessionStorage.removeItem("callId");        
}

function onRTPCreated(data){
    stopPlayMediaFile();
}

function onSessionModifiedEvent(data){
    callNotifyFuncs[37](data);
}

//This function is used to stop play media file, it's invoked when call is accepted, connected, or destroyed. 
function stopPlayMediaFile(){
    if(curPlayHdl >= 0){
        tupCall.stopPlayMediaFile(curPlayHdl);
        curPlayHdl = -1;
    }
}

//This method is use to set dtmf, attach keytone to the call
function DTMF(keyTone){
    tupCall.dtmf(currentCallID, keyTone);
}

//This method is used to mute microphone
function muteMic(){
    tupCall.operateMic(currentCallID, 1);
}

//This method is used to unmute microphone
function unMuteMic(){
    tupCall.operateMic(currentCallID, 0); 
}

//This method is used to add video
function addVideo(){
    tupCall.addVideo(currentCallID);
}

function onAddVideo(){
    console.log("audio to video notify");
    callNotifyFuncs[5]();
}

function replyAddVideo(isAccept){
    tupCall.replyAddVideo(currentCallID, isAccept);
}

function onModifyVideoResult(data){
    var isAccept = data.param.is_video;
    callNotifyFuncs[7](isAccept);
    console.log("modify video result notify")
}

//This method is used to delete video
function delVideo(){
    tupCall.delVideo(currentCallID);
}

function onDelVideo(){
    console.log("video to audio notify");
    callNotifyFuncs[6]();
}

function mediaMuteVideo(isOn){
    tupCall.mediaMuteVideo(currentCallID, isOn);
}
//This function is used to hold call
function holdCall(callbacks) {
    if (callbacks && typeof callbacks.onCallHoldSuccess == "function") {
        this.callNotifyFuncs[10] = callbacks.onCallHoldSuccess;
    }    
    if (callbacks && typeof callbacks.onCallHoldFailed == "function") {
        this.callNotifyFuncs[11] = callbacks.onCallHoldFailed;
    }        
    tupCall.holdCall(currentCallID, {onCallHoldSuccess : onHoldSuccess, onCallHoldFailed : onHoldFailed});
}

//This is callback of hold call
function onHoldSuccess(data) {
    callNotifyFuncs[10]();    
}

//This is callback of hold call
function onHoldFailed(data) {
    callNotifyFuncs[11]();
}

//This function is used to unhold call
function unholdCall(callbacks) {
    if (callbacks && typeof callbacks.onCallUnHoldSuccess == "function") {
        this.callNotifyFuncs[12] = callbacks.onCallUnHoldSuccess;
    }    
    if (callbacks && typeof callbacks.onCallUnHoldFailed == "function") {
        this.callNotifyFuncs[13] = callbacks.onCallUnHoldFailed;
    }      
    tupCall.unholdCall(currentCallID, {onCallUnHoldSuccess : onUnHoldSuccess, onCallUnHoldFailed : onUnHoldFailed});
}

//This is callback of unhold call
function onUnHoldSuccess(data) {
    callNotifyFuncs[12]();
}

//This is callback of unhold call
function onUnHoldFailed(data) {
    callNotifyFuncs[13]();
}

//This function is used to divert call, it needs call id and number divert to
function divertCall(divertNumber, callbacks) {
    if (callbacks && typeof callbacks.onCallDivertFailed == "function") {
        this.callNotifyFuncs[14] = callbacks.onCallDivertFailed;
    }      
    tupCall.divertCall(currentCallID, divertNumber, {onCallDivertFailed : onDivertFailed});
}

//This is callback of divert
function onDivertFailed(data) {
    callNotifyFuncs[14]();
}

//This function is used to blind transfer, it needs call id and number trans to
function blindTransfer(transtoNumber) {
    tupCall.blindTransfer(currentCallID, transtoNumber);
}

//This function is used to start media play, it's invoked by notification of ringback and call incoming
function startMediaPlay(file, looptime)
{
    tupCall.startPlayMediaFile(file, looptime, {response : function(res){curPlayHdl = res.param.play_handle;}});
}

//This function is used to start record function
function startRec(){
    tupCall.startRecode(currentCallID, "testRec.mp3")
}

//This function is used to stop record function
function stopRec(){
    tupCall.stopRecode(currentCallID)
}

//This function is used to get microphone volume
function getMicVol(callbacks){
    if (callbacks && typeof callbacks.getMicVolResponse == "function") {
        this.callNotifyFuncs[17] = callbacks.getMicVolResponse;
    }       
    tupCall.getMicVol({response : function(msg){
        callNotifyFuncs[17](msg.param.volume);}}); 
}

//This is callback of microphone volume change, this callback will carry the actual volume 
function onMicVolChange(data){
    var volume = data.param.volume;
    callNotifyFuncs[16](volume);
}

//This function is used to set microphone volume
function setMicVol(micvol){
    tupCall.setMicVol(Number(micvol));  
}

//This function is used to get speak volume
function getSpkVol(callbacks){
    if (callbacks && typeof callbacks.getSpkVolResponse == "function") {
        this.callNotifyFuncs[18] = callbacks.getSpkVolResponse;
    }       
    tupCall.getSpkVol({response : function(msg){
        callNotifyFuncs[18](msg.param.volume);
    }});     
}

//This is callback of speak volume change, this callback will carry the actual volume 
function onSpkVolChange(data){
    var volume = data.param.volume;
    callNotifyFuncs[15](volume);
}

//This function is used to set speak volume
function setSpkVol(spkvol){
    tupCall.setSpkVol(Number(spkvol));  
} 

//This function is used to get media devices, type come from page, and it's choose by user. 
function getMediaDevices(type) {
    tupCall.getMediaDevices(Number(type));
}

//This function is used to get current microphone device index
function getMicIndex(callbacks){
    if (callbacks && typeof callbacks.getMicIndexResponse == "function") {
        this.callNotifyFuncs[19] = callbacks.getMicIndexResponse;
    } 
    tupCall.mediaGetMicIndex({response : function(msg){
        callNotifyFuncs[19](msg.param.index);
    }});
}

//This function is used to set current microphone device index
function setMicIndex(spkIndex){
    tupCall.setMicIndex(Number(spkIndex));
}

//This function is used to get current speak device index
function getSpkIndex(callbacks){
    if (callbacks && typeof callbacks.getSpkIndexResponse == "function") {
        this.callNotifyFuncs[20] = callbacks.getSpkIndexResponse;
    }     
    tupCall.mediaGetSpeakIndex({response : function(msg){
        callNotifyFuncs[20](msg.param.index);
    }});
}

//This function is used to set current speak device index
function setSpkIndex(spkIndex){
    tupCall.setSpkIndex(Number(spkIndex));
}

//This function is used to get current video device index
function getVideoIndex(callbacks){
    if (callbacks && typeof callbacks.getVideoIndexResponse == "function") {
        this.callNotifyFuncs[21] = callbacks.getVideoIndexResponse;
    }      
    tupCall.mediaGetVideoIndex({response : function(msg){
        callNotifyFuncs[21](msg.param.index);
    }});
}

//This function is used to set current microphone device index
function setVideoIndex(videoIndex){
    tupCall.setVideoIdx(Number(videoIndex));
}

function setCaptureFile(fileName){
    tupCall.setCaptureFile(currentCallID, fileName);
}

function videoControl(operation){
    tupCall.videoControl(false, currentCallID, 4, operation);
}

function startPreview(videoIndex){
    tupCall.startPreview(videoIndex);
}

function stopPreview(){
     tupCall.stopPreview();
}

//This function is used to start timer
var timerId = null;
function initTimer(timeInterval){
    if(timerId != null){
        endTimer(); 
    }
    var myTmp = timeInterval;
    if($.isNumeric(myTmp)){
        timerId = window.setInterval(getChannelInfo, myTmp); 
    }
};

//This function is used to end timer
function endTimer(){
    window.clearInterval(timerId);
}

//This function is used to get channel information
function getChannelInfo(callbacks){
    if (callbacks && typeof callbacks.getChannelInfoResponse == "function") {
        this.callNotifyFuncs[22] = callbacks.getChannelInfoResponse;
    }     
    tupCall.getChannelInfo({response : function(msg){
        callNotifyFuncs[22](msg);
    }});
}

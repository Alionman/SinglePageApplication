var app = angular.module('TUPApp', ['ngRoute', 'ngSanitize']);

app.config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: 'login',
            controller: 'loginController'
        }).when("/call", {
            templateUrl: 'call',
            controller: 'callController'
        }).when("/im", {
            templateUrl: 'im',
            controller: 'imController'
        }).when("/eaddr", {
            templateUrl: 'eaddr',
            controller: 'eaddrController'
        }).when("/exception", {
            templateUrl: 'exception',
            controller: 'exceptionController'
        }).when("/confctrl", {
            templateUrl: 'meeting',
            controller: 'confctrlController'
        }).when("/meeting", {
            templateUrl: 'html/TUPMeeting.html',
            controller: 'meetingController'
        });
}]);

app.run(function($rootScope, $window, $location, $log) {
    var locationChangeStartOff = $rootScope.$on('$locationChangeStart', function(event) {
    });
    var locationChangeSuccessOff = $rootScope.$on('$locationChangeSuccess', function(event) {
    });
    var routeChangeStartOff = $rootScope.$on('$routeChangeStart', function(event) {
    });
    var routeChangeSuccessOff = $rootScope.$on('$routeChangeSuccess', function(event) {
        if (event.currentScope.tab == 3) {
            $rootScope.uProtalLoginFn;
        }
    });
});

app.controller("myCtrl", function($rootScope, $scope, $interval, $route, $window) {
    $scope.tabNum = function(para) {
        $rootScope.tab = para;
        if (para == 3) {
            imLogin();
        }
    };
});





app.controller("imController", function($rootScope, $scope, $timeout, $route, $window, $sce) {
    var dropTargetEle = document.getElementById("dropTarget");
    dropTargetEle.addEventListener("dragenter", dragHandle, false);
    dropTargetEle.addEventListener("dragover", dragHandle, false);
    dropTargetEle.addEventListener("drop", dragHandle, false);
    var dropP2pFile = document.getElementById("p2pFile");
    dropP2pFile.addEventListener("dragenter", dragHandle, false);
    dropP2pFile.addEventListener("dragover", dragHandle, false);
    dropP2pFile.addEventListener("drop", dragHandle, false);

    function dragHandle(event) {
        event.preventDefault();
        if (event.type == "drop") {
            var files = event.dataTransfer.files;
            switch (event.type) {
                case "dragover":
                case "dragenter":
                    event.returnValue = false;
                    break;
                case "drop":
                    $scope.fileName = files[0].name;
                    if (event.currentTarget.attributes.id.nodeValue == "p2pFile") {
                        $scope.Sendp2pFile();
                    } else if (event.currentTarget.attributes.id.nodeValue == "dropTarget") {
                        $scope.UploadFile();
                    }
            }
        }
    }

    $rootScope.tab = 3;
    $scope.LoginPageShow = true;

    $scope.imTabNum = function(para) {
        $scope.tabItem = para;

    };

    if (sessionStorage.authorize_result) {
        $scope.LoginPageShow = false;
        $scope.AccountVal = JSON.parse(localStorage.loginAccountInfo).AccountVal;
    } else {
        $scope.AccountName = "IM_jiyuanyuan_A_02";
        $scope.AccountValB = "im_jiyuanyuan_b_02";
        $scope.AccountNameB = "IM_jiyuanyuan_B_02";

        $scope.AccountVal = "im_jiyuanyuan_a_02";
        $scope.Password = "1qaz@WSX";
        $scope.server_addr = "10.184.99.233";
        $scope.server_port = 8011;
    }

    $rootScope.uProtalLoginFn = $timeout(function() {
        if (sessionStorage.authorize_result) {
            $scope.QueryentAddressBook();
            $scope.getUserInfo($scope.AccountVal);
            $scope.getContactList();
            $scope.RichMediaLogin();
            $scope.DetectUserStatus();
            uiSetP2pFileImEvent();
            uiSetBasicImEvent();
            uiSetGroupImEvent();
        }
    }, 1);

    $scope.imLogin = function() {
        $scope.LoginPageShow = sessionStorage.LoginPageShow == "false" ? false : true;
        if (sessionStorage.authorize_result) {
            imLogin();
        } else {
            imNormalLogin($scope.AccountVal, $scope.Password, $scope.server_addr, $scope.server_port, {
                imLoginResult: function(data) {
                    if (data.result == 0) {
                        $scope.LoginPageShow = false;
                        sessionStorage.imLoginState = true;
                        $scope.$digest();
                    } else {
                        alert("imLogin Faild!")
                        $scope.LoginPageShow = true;
                        sessionStorage.removeItem("imLoginState");
                        $scope.$digest();
                    }
                }
            });
            /*Rich media login*/
            $scope.RichMediaLogin();
            /*Get user information*/
            $scope.getUserInfo($scope.AccountVal);
            /*Get friends and group lists*/
            $scope.getContactList();
            /*Query enterprise address book*/
            $scope.QueryentAddressBook();
            /*Detect user status*/
            $scope.DetectUserStatus();
            /*Subscribe to non-friends user status*/
            //$timeout($scope.SubscribeUserStatus(), 3000);
        }
        $scope.$digest();
    };

    function uiSetBasicImEvent(){
        setBasicImEvent({
            onAddFriend: function(data) {
                var account = data.param.account;
                var display_name = data.param.display_name;
                var server_msg_id_str = data.param.server_msg_id_str;

                $scope.SetMessageRead(4, account, server_msg_id_str);
            },
            onUserStatusList: function(data) {
                var myUserListsTemp = $scope.myUserLists;
                for (var i = 0; i < data.param.userstatus_list.length; i++) {
                    for (var j = 0; j < myUserListsTemp.length; j++) {
                        if (data.param.userstatus_list[i].origin == myUserListsTemp[j].account) {
                            myUserListsTemp[j].status = data.param.userstatus_list[i].status;
                        }
                    }
                }
                $scope.$digest();
            },
            onSendImInput: function(data) {
                var account = data.param.account;
                var status = data.param.status;
                var obj = {};
                obj[account] = status
                $scope.inputState = obj;

                $timeout(function() {
                    obj[account] = 1
                    $scope.inputState = obj;
                }, 2000);

                $scope.$digest();
            },            
            onCodeChat: function(data) {
                var origin = data.param.origin;
                if(confirm("new message from "+origin+", read it now?")){
                    $scope.startChat(origin, "");
                    $("#imcontact").click();
                }else{

                }
                $scope.chatInfoLists.unshift({
                    "origin": origin,
                    "content": data.param.content
                });
                $scope.$digest();
            },
            onChatList: function(data) {
                var chatList = data.param.chat_list;

                for (var i = 0; i < chatList.length; i++) {
                    var chat_type = chatList[i].chat_type;
                    var client_chat_id = chatList[i].client_chat_id;
                    var content = chatList[i].content;
                    var content_type = chatList[i].content_type;
                    var deliver_time = chatList[i].deliver_time;
                    var group_id = chatList[i].group_id;
                    var group_name = chatList[i].group_name;
                    var media_type = chatList[i].media_type;
                    var name = chatList[i].name;
                    var origin = chatList[i].origin;
                    var region_id = chatList[i].region_id;
                    var server_chat_id = chatList[i].server_chat_id;
                    var server_chat_id_str = chatList[i].server_chat_id_str;
                    var source_flag = chatList[i].source_flag;
                    var target = chatList[i].target;

                    $scope.SetMessageRead(chat_type, origin, server_chat_id_str);

                    imAddFriend({
                        "account": origin,
                        "group_id": Number($scope.userGroupLists[0].id),
                        "display_name": origin
                    }, {
                        onAddFriend: function(data) {
                            $scope.getContactList();
                        }
                    });
                }
            }                                    
        });
    }

    function uiSetGroupImEvent(){
        setGroupImEvent({
            onApplyJoinFixedGroupResult: function(data) {
                $scope.getContactList();
            },
            onReceiveInviteToFixedGroup: function(data) {
                var adminAccount = data.param.admin_account;
                var groupId = data.param.group_id;
                var groupName = data.param.group_name;
                var msgId = data.param.server_msg_id_str;

                $scope.ConfirmFixedGroupInvite(groupId, groupName, adminAccount);

                $scope.SetMessageRead(4, groupId, msgId); 
            },
            onReceiveInviteJoinFixedGroup: function(data) {
                var groupId = data.param.group_id;
                var groupName = data.param.group_name;
                var memberAccount = data.param.member_account;
                var memberName = data.param.member_name;
                var msgId = data.param.server_msg_id_str;

                $scope.ConfirmFixedGroupApply(groupId, groupName, memberAccount);
                $scope.SetMessageRead(4, groupId, msgId); 
            },
            onFixedGroupDismiss: function(data) {
                var adminAccount = data.param.admin_account;
                var groupId = data.param.group_id;
                var groupName = data.param.group_name;
                var memberAccount = data.param.member_account;
                var memberName = data.param.member_name;
                var msgId = data.param.server_msg_id_str;

                $scope.SetMessageRead(4, groupId, msgId);
            }                                  
        });
    }
    
    //This function is used to get the system link
    $scope.GetSysUrl = function() { 
        imGetSysUrl({
            onGetSysUrl: function(data) {
                var d = data;
            },
            onSysUrlRet: function(data) {
                var download_url = data.param.download_url;
                var establish_account_help_url = data.param.establish_account_help_url;
                var forget_pwd_url = data.param.forget_pwd_url;
                var login_fail_url = data.param.login_fail_url;
                var net_error_url = data.param.net_error_url;
                var update_report_url = data.param.update_report_url;
                var update_server_addr = data.param.update_server_addr;
                var user_help_url = data.param.user_help_url;
                var user_protal_url = data.param.user_protal_url;
                var vpn_names = data.param.vpn_names;

                alert("download_url:" + download_url + "\n" +
                    "establish_account_help_url:" + establish_account_help_url + "\n" +
                    "forget_pwd_url:" + forget_pwd_url + "\n" +
                    "login_fail_url:" + login_fail_url + "\n" +
                    "net_error_url:" + net_error_url + "\n" +
                    "update_report_url:" + update_report_url + "\n" +
                    "update_server_addr:" + update_server_addr + "\n" +
                    "user_help_url:" + user_help_url + "\n" +
                    "user_protal_url:" + user_protal_url + "\n" +
                    "vpn_names:" + vpn_names);
            }
        });
    }

    window.onunload = function() {
        imUninit();
    }

    $scope.Loginout = function() {
        imLoginout();
        $scope.LoginPageShow = true;
        $scope.showConfig = false;
        sessionStorage.removeItem("imLoginState");
        // unsubscribe non-friend user status
        $scope.UnSubscribeUserStatus();
    };

    //This function is used to get the buddy list and group list
    $scope.getContactList = function() {
        //var userStatusArray = $scope.userStatusArray;

        imGetContactList({
            "is_sync_all": 1,
            "time_stamp": "19000000000000"
        }, {
            onGetContactList: function(data) {
                if (data.result == 0) {
                    var objContact = {};
                    for (i in data.param.contact_list) {
                        objContact[data.param.contact_list[i]["id"]] = data.param.contact_list[i]["staff_id"];
                    }
                    var objUser = {};
                    for (i in data.param.user_list) {
                        objUser[data.param.user_list[i]["staff_id"]] = [
                            data.param.user_list[i]["name"],
                            data.param.user_list[i]["account"]
                        ];
                    }

                    var arr = [];
                    for (i in data.param.user_group_member_list) {
                        if (objContact[data.param.user_group_member_list[i]["contact_id"]] != 0) {
                            var obj = {};
                            obj["contact_id"] = data.param.user_group_member_list[i]["contact_id"];
                            obj["group_id"] = data.param.user_group_member_list[i]["group_id"];
                            obj["name"] = objUser[objContact[obj["contact_id"]]][0];
                            obj["account"] = objUser[objContact[obj["contact_id"]]][1];
                            obj["status"] = $scope[obj["account"]] || '';
                            arr.push(obj);
                        }
                    }
                    for (i in data.param.contact_list) {
                        if (data.param.contact_list[i]["staff_id"] == 0) {
                            var userDefineObj = {};
                            userDefineObj["contact_id"] = data.param.contact_list[i]["id"];
                            userDefineObj["group_id"] = data.param.user_group_member_list && data.param.user_group_member_list[0]["group_id"];
                            userDefineObj["name"] = data.param.contact_list[i]["name"];
                            userDefineObj["account"] = '';
                            userDefineObj["status"] = '';
                            arr.push(userDefineObj);
                        }
                    }
                    $scope.myUserLists = arr;
                    $scope.imGroups = data.param.im_group_list;
                    $scope.userGroupLists = data.param.user_group_list;
                    $scope.$digest();
                }
            }
        });
    };


    $scope.userListContactId = 0;
    $scope.userListOldGroupId = 0;
    $scope.chooseGroupOption = function(contactId, oldGroupId) {
        $scope.userListContactId = contactId;
        $scope.userListOldGroupId = oldGroupId;
        $("#moveUserToGroup").show();
        $("#moveToGroupSelect").empty();
        $("#moveToGroupSelect").append("<option>choose group:</option>")
        for (x in $scope.userGroupLists) {
            $("#moveToGroupSelect").append("<option>" + $scope.userGroupLists[x].id + ":" + $scope.userGroupLists[x].name + "</option>")
        }
    }

    //This function is used to move or copy contacts / buddies to other groups
    $scope.MoveContactGroup = function() {
        var newGroupId = $("#moveToGroupSelect").find("option:selected").text();
        imMoveContactGroup({
            "contact_id": Number($scope.userListContactId),
            "old_group_id": Number($scope.userListOldGroupId),
            "new_group_id": parseInt(newGroupId),
            "type": 0 //0 move, 1 copy
        }, {
            onMoveContactGroup: function(data) {
                $scope.getContactList();
            }
        });
        $("#moveUserToGroup").hide();
    };

    //This function is used to get user information
    $scope.getUserInfo = function(account) {
        imGetUserInfo(account, {
            omImGetUserInfo: function(data) {
                var imageId = data.param.image_id;
                switchHeadImg(imageId);
                $scope.userInfos = data.param;
            }
        });
    };

    $scope.SetUserInfo = function() {
        var UserInfoParam = {
            "staff_id": $scope.userInfos.staff_id, 
            "account": $scope.userInfos.account,
            "staff_no": "201601",
            "name": $scope.userInfos.name,
            "native_name": "wewe",
            "q_pin_yin": $scope.userInfos.q_pin_yin,
            "gender": $scope.userInfos.gender,
            "birthday": "19921111",
            "age": "25",
            "bind_no": "88890",
            "mobile": $scope.userInfos.mobile,
            "home_phone": $scope.userInfos.home_phone,
            "office_phone": $scope.userInfos.office_phone,
            "short_phone": $scope.userInfos.short_phone,
            "other_phone": $scope.userInfos.other_phone,
            "voip": "88",
            "ip_phone": "56321",
            "fax": $scope.userInfos.fax,
            "email": $scope.userInfos.email,
            "website": $scope.userInfos.website,
            "signature": $scope.userInfos.signature,
            "desc": "describe",
            "address": $scope.userInfos.address,
            "image_id": $scope.userInfos.image_id,
            "postcode": $scope.userInfos.postcode,
            "is_security": true,
            "title": $scope.userInfos.title,
            "dept_id": $scope.userInfos.dept_id,
            "dept_name_en": "sail",
            "dept_name_cn": $scope.userInfos.dept_name_cn,
            "image_sync_time": "20",
            "old_account": "20150602",
            "state": $scope.userInfos.state,
            "modify_time": "2016-3-18"
        };

        imSetUserInfo(UserInfoParam, {
            onUserInfoChange: function(data) {
                var d = data;
            }
        });
    };

    $scope.SetSelfDefineImage = function() {
        imSetSelfDefineImage({
            "length": 9,
            "data": "myImgName"
        }, {
            onImSetSelfDefineImage: function(data) {
                var d = data;
            }
        });

        imGetUserDefineImage({
            "id": $scope.AccountVal,
            "time_stamp": "19000000000000"
        }, {
            onGetUserDefineImage: function(data) {
                var imgName = data.param.data;
                var id = data.param.id;
                var length = data.param.length;

                switchHeadImg(imgName);
            }
        });
    };

    function switchHeadImg(imageId) {
        switch (imageId) {
            case "00":
            case "0":
                $scope.imgHeadSrc = "bin/img/headimg/0.png";
                $scope.$digest();
                break;
            case "01":
            case "1":
                $scope.imgHeadSrc = "bin/img/headimg/1.png";
                $scope.$digest();
                break;
            case "02":
            case "2":
                $scope.imgHeadSrc = "bin/img/headimg/2.png";
                $scope.$digest();
                break;
            case "03":
            case "3":
                $scope.imgHeadSrc = "bin/img/headimg/3.png";
                $scope.$digest();
                break;
            case "04":
            case "4":
                $scope.imgHeadSrc = "bin/img/headimg/4.png";
                $scope.$digest();
                break;
            case "05":
            case "5":
                $scope.imgHeadSrc = "bin/img/headimg/5.png";
                $scope.$digest();
                break;
            case "06":
            case "6":
                $scope.imgHeadSrc = "bin/img/headimg/6.png";
                $scope.$digest();
                break;
            case "07":
            case "7":
                $scope.imgHeadSrc = "bin/img/headimg/7.png";
                $scope.$digest();
                break;
            case "08":
            case "8":
                $scope.imgHeadSrc = "bin/img/headimg/8.png";
                $scope.$digest();
                break;
            case "09":
            case "9":
                $scope.imgHeadSrc = "bin/img/headimg/9.png";
                $scope.$digest();
                break;
            case "myImgName":
                $scope.imgHeadSrc = "bin/img/headimg/10.png";
                $scope.$digest();
                break;
            default: 
                $scope.imgHeadSrc = "bin/img/headimg/10.png";
                $scope.$digest();
                break;
        }
    }

    $scope.imgHeadSrc = $scope.imgHeadSrc || "bin/img/headimg/0.png";
    $scope.Setsystemimage = function(imgNum) {
        imSetsystemimage(imgNum, {
            onImSetSystemImage: function(data) {
                if (data.result == 0) {
                    switchHeadImg(imgNum);
                }
            }
        });
    };

    $("#imAddressBookPicture").click(function() {
        $(".contentRight").show();
        $(".contentLeft").hide();
    });

    $scope.backToContentLeft = function() {
        $(".contentRight").hide();
        $(".contentLeft").show();
    }

    //This function is used to query the enterprise address book
    $scope.QueryentAddressBook = function() {
        var params = {
            "is_need_amount": 1,
            "order_type": 1,
            "order_model": 0,
            "off_set": 0,
            "count": 30,
            "dept_id": -1,
            "query_key": $scope.filterUserList || "1"
        }
        imQueryentAddressBook(params, {
            onQueryentAddressBook: function(data) {
                var userLists = data.param.user_list;
                var arr = [];
                for (x in data.param.user_list) {
                    var obj = {};
                    obj["account"] = userLists[x].account;
                    obj["dept_name_en"] = userLists[x].dept_name_en;
                    obj["name"] = userLists[x].name;
                    obj["staff_id"] = userLists[x].staff_id;
                    obj["status"] = $scope[userLists[x].account] || '';
                    arr.push(obj);
                }
                $scope.userLists = arr;
                $scope.SubscribeUserStatus();
                $scope.$digest();
            }
        });
    };

    $scope.contentShow = false;
    //This function is used to query contacts and fixed groups
    $scope.QueryUserInfoAndGroup = function() {
        if ($scope.queryUserInfo) {
            $scope.contentShow = true;
        } else {
            $scope.contentShow = false;
        }

        $scope.QueryUserInfo();
        $scope.GetFixedGroups();
    };

    //This function is used to get contact information (fuzzy query)
    $scope.QueryUserInfo = function() {
        imQueryUserInfo({
            "key": $scope.queryUserInfo,
            "type": 1 //0 number; 1 account; 2 binding number; 3 mailbox; 
        }, {
            onQueryUserInfo: function(data) {
                $scope.Contacts = data.param.user_list;
                $scope.$digest();
            }
        });
    };

    //This function is used to query fixed groups (fuzzy queries)
    $scope.GetFixedGroups = function() {
        imGetFixedGroups({
            "is_need_amount": 1,
            "offset": 0,
            "count": 10,
            "query_key": $scope.queryUserInfo || "",
            //Group query type, 0 query by name; 1 query with group ID; 2 query with name and ID
            "query_type": 0 
        }, {
            onGetFixedGroups: function(data) {
                $scope.Groups = data.param.group_list;
                $scope.$digest();
            }
        });
    };

    $scope.userListAccount = "";
    $scope.chooseUserOption = function(account) {
        $scope.userListAccount = account;
        $("#addUserToGroup").show();
        $("#groupIdSelect").empty();
        $("#groupIdSelect").append("<option>choose group:</option>")
        for (x in $scope.userGroupLists) {
            $("#groupIdSelect").append("<option>" + $scope.userGroupLists[x].id + ":" + $scope.userGroupLists[x].name + "</option>")
        }
    }

    //This function is used to add business users as friends
    $scope.AddFriend = function() {
        var groupId = $("#groupIdSelect").find("option:selected").text();
        var account = $scope.userListAccount;
        imAddFriend({
            "account": account,
            "group_id": parseInt(groupId), 
            "display_name": account
        }, {
            onAddFriend: function(data) {
                $scope.getContactList();
            }
        })
        $("#addUserToGroup").hide();
    };

    //This function is used to delete friends or contacts
    $scope.DelFriendOrContact = function(contactId, groupId) {
        if (confirm("delete this friend？")) {
            imDelFriendOrContact({
                "contact_id": contactId,
                "group_id": groupId
            }, {
                onDelFriendOrContact: function(data) {
                    $scope.getContactList();
                }
            })
            $scope.userListShow = true;
        }
    };

    //This function is used to add buddy and contact groups
    $scope.AddUserGroup = function() {
        var groupName = prompt("friends group name:");
        if (groupName) {
            imAddUserGroup({
                "name": groupName,
                "index": -1
            }, {
                onAddUserGroup: function(data) {
                    $scope.getContactList();
                    $scope.UpdateUserGroup();
                }
            })
        }
    }

    //This function is used to delete buddy and contact groups
    $scope.DelUserGroup = function(id) {
        if (confirm("delete this group？")) {
            imDelUserGroup(id, {
                onDelUserGroup: function(data) {
                    $scope.getContactList();
                    $scope.UpdateUserGroup();
                }
            });
        }
    };

    //This function is used to modify friends and contact groups
    $scope.ModUserGroup = function(id) {
        var name = prompt("modified group name：");
        if (name) {
            imModUserGroup({
                "id": id,
                "name": name,
                "index": -1
            }, {
                onModUserGroup: function(data) {
                    $scope.getContactList();
                }
            })
        }
    };

    //This function is used to update the list of contact groups to the server
    $scope.UpdateUserGroup = function() {
        var groupIds = [];
        for (x in $scope.userGroupLists) {
            groupIds.push({
                "user_group": $scope.userGroupLists[x].id
            });
        }
        imUpdateUserGroup({
            "user_group_list": groupIds
        }, {
            onUpdateUserGroup: function(data) {}
        })
    };

    $scope.statusNum = [{
        index: 1,
        status: "online"
    }, {
        index: 3,
        status: "busy"
    }, {
        index: 4,
        status: "leave"
    }];
    $scope.selectedStatus = $scope.statusNum[0];
    //Inform the server of their own state changes
    $scope.PublishStatus = function() { 
        imPublishStatus({
            "status": $scope.selectedStatus.index, 
            "desc": "ok"
        }, {
            onPublishStatus: function(data) {
                var d = data;
            }
        })
    };

    //This function is used to subscribe to non-friend user status
    $scope.SubscribeUserStatus = function(account) {
        $scope.AddressBookShow = !$scope.AddressBookShow

        var accounts = [];
        for (x in $scope.userLists) {
            accounts.push({
                "account": $scope.userLists[x].account
            });
        }

        imSubscribeUserStatus({ 
            "account_list": accounts
        }, {
            onSubscribeUserStatusResponse: function(data) {
            }
        })
    };

    //This function is used to unsubscribe non-friend user status
    $scope.UnSubscribeUserStatus = function() {
        var accounts = [];
        for (x in $scope.userLists) {
            accounts.push({
                "account": $scope.userLists[x].account
            });
        }
        imUnSubscribeUserStatus({
            "account_list": accounts
        }, {
            onUnSubscribeUserStatus: function(data) {
            }
        })
    };

    //This function is used to probe user status
    $scope.DetectUserStatus = function() {
        var accounts = [];
        for (x in $scope.myUserLists) {
            accounts.push({
                "account": $scope.myUserLists[x].account
            });
        }
        imDetectUserStatus({ 
            "account_list": accounts
        }, {
            onDetectUserStatusResponse: function(data) {
            }
        });
    };

    //This function is used to chatting
    $scope.startChat = function(account, contactId) {
        $scope.target = account;
        $(".contentRight").show();
        $(".contentLeft").hide();
        if(account == $scope.p2pAccount){
            $scope.sendFileBtn = false;
            $scope.cancelFileBtn = true;
            $scope.rejectFileBtn = false;
        }else{
            $scope.sendFileBtn = true;
            $scope.cancelFileBtn = false;
            $scope.rejectFileBtn = false;            
        }
        $scope.QueryHistoryMessage();
        if (account == "") {
            $scope.ModContact(contactId);
        }
    };

    //This function is used to send text messages
    $scope.SendIm = function() {
        imSendIm({
            "region_id": 1, 
            "chat_type": 0, 
            "source_flag": 0,
            "content_type": 1, 
            "origin": $scope.AccountVal, 
            "target": $scope.target, 
            "group_id": "", 
            "content": $scope.message || "", 
            "display_name": "3", 
            "utc_stamp": 1,
            "client_chat_id": 1, 
            "media_type": $scope.mediaType 
        }, {
            onSendImResponse: function(data) {},
            onMsgSendAck: function(data) {
                $scope.chatInfoLists = $scope.chatInfoLists || [{
                    "origin": "",
                    "content": "",
                    "media_type": ""
                }];
                $scope.chatInfoLists.unshift({
                    "origin": data.param.target,
                    "content": $scope.message,
                    "media_type": $scope.mediaType
                });
                $scope.message = "";

                $timeout(function() {
                    document.querySelector("#p2pFile div:last-child br").scrollIntoView();
                }, 1);
                $scope.$digest();
            }
        });
    };

    //This function is used to get roaming messages
    $scope.QueryHistoryMessage = function() {
        imQueryHistoryMessage({
            "operation_type": 1, 
            "msg_type": 0, 
            "sender": $scope.target, 
            "msg_id": 1, 
            "count": 10 
        }, {
            onQueryHistoryMessage: function(data) {
                $scope.chatInfoLists = data.param.chat_info_list;
                $scope.$digest();                
                if($scope.chatInfoLists!=null){
                $timeout(function() {
                    document.querySelector("#p2pFile div:last-child br").scrollIntoView();
                }, 1);
                }

            }
        });
    };

    //This function is used to send its own input status to the server
    $scope.NotifyImInputting = function() {
        $scope.mediaType = 0;
        imNotifyImInputting({
            "account": $scope.target,
            "type": 0
        }, {
            onNotifyImInputtingResponse: function(data) {},
            onNotifyInputting: function(data) {}
        })
    };

    //This function is used to set the message to read
    $scope.SetMessageRead = function(msgType, sender, msgId) {
        imSetMessageRead({
            "message_list": [{
                "msg_type": msgType, 
                "sender": sender,
                "str_msgid": msgId
            }]
        }, {
            onSetMessageRead: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to add a custom contact
    $scope.AddContact = function() {
        var name = prompt("custom contact name：");
        if (name) {
            imAddContact({
                "id": 999,
                "staff_id": Number($scope.userInfos.staff_id),
                "name": name,
                "nick_name": "nichen",
                "foreign_name": "bili",
                "birthday": "2016-01-12",
                "gender": 0,
                "corp_name": "huawei",
                "dept_name": "sisi",
                "title": "manager",
                "mobile": "555",
                "office_phone": "000",
                "home_phone": "654",
                "other_phone": "666",
                "fax": "0571",
                "email": "@com",
                "website": "www.com",
                "im_no": "555",
                "address": "china",
                "desc": "desc",
                "postcode": "3301",
                "state": 0,
                "group_id": $scope.userGroupLists[0].id 
            }, {
                onAddContact: function(data) {
                    $scope.getContactList();
                }
            });
        }
    }

    //This function is used to modify a custom contact friend
    $scope.ModContact = function(id, staffId) {
        var name = prompt("changed contact name：");

        if (name) {
            imModContact({
                "id": id,
                "staff_id": 0, 
                "name": name,
                "nick_name": "nichen",
                "foreign_name": "bili",
                "birthday": "2016-01-12",
                "gender": 0,
                "corp_name": "huawei",
                "dept_name": "sisi",
                "title": "manager",
                "mobile": "555",
                "office_phone": "000",
                "home_phone": "654",
                "other_phone": "666",
                "fax": "0571",
                "email": "@com",
                "website": "www.com",
                "im_no": "555",
                "address": "china",
                "desc": "desc",
                "postcode": "3301",
                "state": 0
            }, {
                onModContact: function(data) {
                    $scope.getContactList();
                }
            });
        }
    };

    //This function is used to create a fixed group
    $scope.AddFixedGroup = function() {
        var name = prompt("please enter a fixed group name：");
        if (name) {
            imAddFixedGroup({
                "id": "",
                "name": name,
                "capacity": 1,
                "manifesto": "",
                "desc": "desc",
                "owner": $scope.AccountVal,
                "auto_join_flag": 1,
                "msg_policy_type": 1,
                "group_type": 0, 
                "fix_discuss": 0,
                "state": "0"
            }, {
                onAddFixedGroup: function(data) {
                    $scope.getContactList();
                }
            })
        }
    };

    //This function is used to create discussion groups
    $scope.AddDiscussionGroup = function() {
        var discussionGroupName = prompt("Please enter discussion group name：");
        if (discussionGroupName) {
            imAddDiscussionGroup({
                "id": "",
                "name": discussionGroupName,
                "capacity": 100,
                "manifesto": "manifesto",
                "desc": "desc",
                "owner": $scope.AccountVal,
                "auto_join_flag": 0,
                "msg_policy_type": 1,
                "group_type": 1,
                "fix_discuss": 0,
                "state": "0"
            }, {
                onAddDiscussionGroup: function(data) {
                    $scope.getContactList();
                }
            });
        }
    };

    //This function is used to delete a fixed group or discussion group
    $scope.DelGroup = function(type, id) {
        if (confirm("delete this group？")) {
            if (type == 0) { 
                $scope.DelFixedGroup(id);
            } else if (type == 1) {
                $scope.DelDiscussionGroup(id);
            }
        }
    };

    //This function is used to delete a fixed group
    $scope.DelFixedGroup = function(id) {
        imDelFixedGroup(id, {
            onDelFixedGroup: function(data) {
                $scope.getContactList();
            }
        });
    };

    //This function is used to delete discussion groups
    $scope.DelDiscussionGroup = function(groupId) {
        imDelDiscussionGroup({
            "id": groupId
        }, {
            onDelDiscussionGroup: function(data) {
                $scope.getContactList();
            },
            onDiscussGroupDismiss: function(data) {
                var d = data;
            }
        })
    };

    //This function is used to modify fixed group or discussion group information
    $scope.ModGroup = function(type, id) {
        var name = prompt("Please enter changed fixed group name：");
        if (name) {
            if (type == 0) { 
                $scope.ModFixedGroup(name, id);
            } else if (type == 1) { 
                $scope.ModDiscussionGroup(name, id);
            }
        }
    };

    //This function is used to modify fixed group information
    $scope.ModFixedGroup = function(name, id) {
        imModFixedGroup({
            "id": id,
            "name": name,
            "capacity": 1,
            "manifesto": "",
            "desc": "desc",
            "owner": "manager",
            "auto_join_flag": 0,
            "msg_policy_type": 0,
            "group_type": 0,
            "fix_discuss": 0,
            "state": "0"
        }, {
            onModFixedGroup: function(data) {
                $scope.getContactList();
            },
            onFixedGroupInfChg: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to modify the discussion group information
    $scope.ModDiscussionGroup = function(name, groupId) {
        imModDiscussionGroup({
            "id": groupId,
            "name": name,
            "capacity": 100,
            "manifesto": "manifesto",
            "desc": "desc",
            "owner": "manager", 
            "auto_join_flag": 0, 
            "msg_policy_type": 0, 
            "group_type": 0, 
            "fix_discuss": 0, 
            "state": "1" 
        }, {
            onModDiscussionGroup: function(data) {
                $scope.getContactList();
            },
            onDiscussGroupInfoChange: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to get group details
    $scope.GetFixedGroupDetail = function(id) {
        imGetFixedGroupDetail({
            "group_id": id
        }, {
            onGetFixedGroupDetail: function(data) {
                alert("group info：" + "\n" +
                    "auto_join_flag:" + data.param.auto_join_flag + "\n" +
                    "capacity:" + data.param.capacity + "\n" +
                    "desc:" + data.param.desc + "\n" +
                    "fix_discuss:" + data.param.fix_discuss + "\n" +
                    "group_type:" + data.param.group_type + "\n" +
                    "id:" + data.param.id + "\n" +
                    "manifesto:" + data.param.manifesto + "\n" +
                    "msg_policy_type:" + data.param.msg_policy_type + "\n" +
                    "name:" + data.param.name + "\n" +
                    "owner:" + data.param.owner + "\n" +
                    "state:" + data.param.state);
            }
        });
    };

    //This function is used to send text messages
    $scope.SendGroupIm = function() {
        var chatType = 0;
        if ($scope.groupType) {
            chatType = 2;
        } else {
            chatType = 6;
        }
        imSendIm({
            "region_id": 1, 
            "chat_type": chatType, 
            "source_flag": 0, 
            "content_type": 1,
            "origin": $scope.AccountVal, 
            "target": "", 
            "group_id": $scope.groupId, 
            "content": $scope.message || "",
            "display_name": "3", 
            "utc_stamp": 1, 
            "client_chat_id": 1, 
            "media_type": $scope.mediaType 
        }, {
            onSendImResponse: function(data) {},
            onMsgSendAck: function(data) {
                $scope.chatInfoLists = $scope.chatInfoLists || [{
                    "origin": "",
                    "content": "",
                    "media_type": ""
                }];
                $scope.chatInfoLists.unshift({
                    "origin": data.param.target,
                    "content": $scope.message,
                    "media_type": $scope.mediaType
                });
                $scope.message = "";
                $timeout(function() {
                    document.querySelector("#p2pFile div:last-child br").scrollIntoView();
                }, 1);
                $scope.$digest();
            }
        });
    };

    //This function is used to get roaming messages
    $scope.QueryGroupHistoryMessage = function() {
        imQueryHistoryMessage({
            "operation_type": 1, 
            "msg_type": 1, 
            "sender": $scope.groupId, 
            "msg_id": 1,
            "count": 10 
        }, {
            onQueryHistoryMessage: function(data) {
                $scope.chatInfoLists = data.param.chat_info_list;
                $scope.$digest();
                $timeout(function() {
                    document.querySelector("#p2pFile div:last-child br").scrollIntoView();
                }, 1);
            }
        });
    };

    //This function is used to start group chat
    $scope.startGroupChat = function(name, groupId, groupType) {
        $(".contentRight").show();
        $(".contentLeft").hide();
        $scope.groupName = name;
        $scope.groupId = groupId;
        $scope.groupType = groupType;
        $scope.GetGroupMembers();
        $scope.QueryGroupHistoryMessage();
    };

    //This function is used to get a list of members of a group (fixed group or discussion group)
    $scope.GetGroupMembers = function() {
        imGetFixedGroupMembers({
            "is_sync_all": 1,
            "group_id": $scope.groupId,
            "time_stamp": "19000000000000"
        }, {
            onGetFixedGroupMembers: function(data) {
                $scope.groupMembers = data.param.member_info;
                $scope.$digest();
            }
        });
    };

    //This function is used to add fixed groups or discussion group members
    $scope.AddGroupMember = function(groupId, groupName) {
        var account = prompt("Please enter account number：");
        if (account) {
            if ($scope.groupType == 0) {
                $scope.AddFixedGroupMember(groupId, account, groupName);
            } else if ($scope.groupType == 1) {
                $scope.AddDiscussionGroupMember(groupId, account, groupName);
            }
        }
    };

    //This function is used to add fixed group members
    $scope.AddFixedGroupMember = function(groupId, account, groupName) {
        imAddFixedGroupMember({
            "group_id": groupId,
            "account": account,
            "group_name": groupName,
            "display_name": "jx"
        }, {
            onAddFixedGroupMember: function(data) {
            }
        });
    };

    //This function is used to add discussion group members
    $scope.AddDiscussionGroupMember = function(groupId, account, groupName) {
        imAddDiscussionGroupMember({
            "group_id": groupId,
            "account": account,
            "group_name": groupName,
            "display_name": "zhangsan"
        }, {
            onAddDiscussionGroupMember: function(data) {
                $scope.SendDisgroupOpMessage(0);
                $scope.GetGroupMembers();
            }
        });
    };

    //This function is used by the user to deny / agree to a fixed group invitation
    $scope.ConfirmFixedGroupInvite = function(groupId, groupName, adminAccount) {
        var agreeJoin;
        if (confirm("fixed group apply？")) {
            agreeJoin = 1; //agree
        } else {
            agreeJoin = 0; //Refuse
        }
        if (agreeJoin) {
            imConfirmFixedGroupInvite({
                "agree_join": agreeJoin,
                "group_id": groupId,
                "group_name": groupName,
                "member_account": adminAccount,
                "display_name": "zhangsan"
            }, {
                onConfirmFixedGroupInvite: function(data) {
                    $scope.getContactList();
                },
                onFixedGroupMemberAdd: function(data) {
                    var d = data;
                }
            });
        }
    };

    //This function is used by the user to join a fixed group
    $scope.JoinFixedGroup = function(groupId, groupName) {
        if (confirm("join fixed group?")) {
            imJoinFixedGroup({
                "group_id": groupId,
                "group_name": groupName,
                "display_name": $scope.AccountVal
            }, {
                onJoinFixedGroup: function(data) {
                    var d = data;
                }
            });
        }
    };

    //This function is used by the administrator to approve fixed group join request notifications
    $scope.ConfirmFixedGroupApply = function(groupId, groupName, memberAccount) {
        var agreeJoin;
        if (confirm("fixed group apply？")) {
            agreeJoin = 1; 
        } else {
            agreeJoin = 0; 
        }
        if (agreeJoin) {
            imConfirmFixedGroupApply({
                "agree_join": agreeJoin,
                "group_id": groupId,
                "group_name": groupName,
                "member_account": memberAccount,
                "display_name": "user6"
            }, {
                onConfirmFixedGroupApply: function(data) {
                    var d = data;
                },
                onFixedGroupMemberAdd: function(data) {
                    var d = data;
                }
            });
        }
    };

    //This function is used by the administrator to remove fixed group members or discussion group members
    $scope.DelGroupMember = function(account) {
        if (confirm("delete group member？")) {
            if ($scope.groupType == 0) {
                $scope.DelFixedGroupMember(account);
            } else if ($scope.groupType == 1) {
                $scope.DelDiscussionGroupMember(account);
            }
        }
    };

    //This function is used by the administrator to remove fixed group members
    $scope.DelFixedGroupMember = function(account) {
        imDelFixedGroupMember({
            "group_id": $scope.groupId,
            "account": account
        }, {
            onDelFixedGroupMember: function(data) {
                $scope.GetGroupMembers();
            },
            onFixedGroupMemberDel: function(data) {
                var d = data;
            },
            onFixedGroupKickout: function(data) {
                var d = data;
            }
        });
    };

    //This function is used by the administrator to delete the discussion group members
    $scope.DelDiscussionGroupMember = function(account) {
        imDelDiscussionGroupMember({
            "group_id": $scope.groupId,
            "account": account
        }, {
            onDelDiscussionGroupMember: function(data) {
                $scope.SendDisgroupOpMessage(1);
                $scope.GetGroupMembers();
            }
        });
    };

    //This function is used to exit a fixed group or discussion group
    $scope.LeaveGroup = function() {
        if (confirm("leave group?")) {
            if ($scope.groupType == 0) {
                $scope.LeaveFixedGroup();
            } else if ($scope.groupType == 1) {
                $scope.LeaveDiscussionGroup();
            }
        }
    };

    //This function is used to exit a fixed group
    $scope.LeaveFixedGroup = function() {
        imLeaveFixedGroup({
            "arg": $scope.groupId
        }, {
            onLeaveFixedGroup: function(data) {
                $scope.getContactList();
            },
            onFixedGroupLeaveResult: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to leave the discussion group
    $scope.LeaveDiscussionGroup = function() {
        imLeaveDiscussionGroup({
            "group_id": $scope.groupId
        }, {
            onLeaveDiscussionGroup: function(data) {
                $scope.getContactList();
            }
        });
    };

    //This function is used to transfer fixed groups or discussion group administrators
    $scope.TransferGroup = function(groupId, account) {
        if (confirm("transfer to group manager?")) {
            if ($scope.groupType == 0) {
                $scope.TransferFixedGroup(groupId, account);
            } else if ($scope.groupType == 1) {
                $scope.TransferDiscussionGroup(groupId, account);
            }
        }
    };

    //This function is used to transfer fixed group administrators
    $scope.TransferFixedGroup = function(groupId, account) {
        imTransferFixedGroup({
            "group_id": groupId,
            "account": account
        }, {
            onTransferFixedGroup: function(data) {
                var d = data;
            },
            onFixedGroupOwnerChg: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to transfer discussion group administrators
    $scope.TransferDiscussionGroup = function(groupId, account) {
        imTransferDiscussionGroup({
            "group_id": groupId,
            "account": account
        }, {
            onTransferDiscussionGroup: function(data) {
                var d = data;
            },
            onDiscussGroupOwnerChange: function(data) {
                var d = data;
            }
        });
    };

    //This function is used by administrators to add discussion group phone members
    $scope.AddDiscussioGroupPhoneMember = function() {
        var phone = prompt("add discussion group member of the discussion group：");
        if (phone) {
            imAddDiscussioGroupPhoneMember({
                "group_id": $scope.groupId,
                "phone_list": [{
                    "phone": phone 
                }]
            }, {
                onAddDiscussioGroupPhoneMember: function(data) {
                    if (data.result == 0) {
                        alert("add discussion group phonemember success");
                    } else {
                        alert("add discussion group phonemember fail");
                    }
                }
            });
        }
    };

    //This function is used by the administrator to delete the discussion group cell phone members
    $scope.DelDiscussionGroupPhoneMember = function() {
        var phone = prompt("delete discussion group member：");
        if (phone) {
            imDelDiscussionGroupPhoneMember({
                "group_id": $scope.groupId,
                "phone_list": [{
                    "phone": phone 
                }]
            }, {
                onDelDiscussioGroupPhoneMember: function(data) {
                    if (data.result == 0) {
                        alert("delete discussion group phonemember success");
                    } else {
                        alert("delete discussion group phonemember fail");
                    }
                }
            });
        }
    };

    //This function is used for fixed discussion groups
    $scope.SetDisgroupPolicy = function() {
        if (confirm("fixed discussion group?")) {
            imSetDisgroupPolicy({
                "group_id": $scope.groupId,
                "policy": 1 
            }, {
                onSetDisgroupPolicy: function(data) {
                    var d = data;
                }
            });
        }
    };

    //This function is used to send files
    function uiSetP2pFileImEvent(){
        setP2pFileImEvent({
            onP2pFileProcess:onP2pFileProcess,
            onP2pFileStartResult:onP2pFileStartResult,
            onP2pFileStop:onP2pFileStop,
            onP2pFileStopResult:onP2pFileStopResult,
            onP2pFileIncomming:onP2pFileIncomming
        });
    }
    function onP2pFileProcess(data){

    }
    function onP2pFileStartResult(data){

    }
    function onP2pFileStop(data){
        $scope.sendFileBtn = true;
        $scope.cancelFileBtn = false;
        $scope.rejectFileBtn = false;
        $scope.p2pAccount = null; 
        $scope.$digest();
    }
    function onP2pFileStopResult(data){
        $scope.sendFileBtn = true;
        $scope.cancelFileBtn = false;
        $scope.rejectFileBtn = false;
        $scope.p2pAccount = null; 
        $scope.$digest();
    }
    function onP2pFileIncomming(data){
        var fileName = data.param.file_name;
        $scope.Acceptp2pFileOrNot(fileName);
        $scope.fileName = fileName;
        $scope.$digest();
    } 

    $scope.p2pAccount;
    $scope.Sendp2pFile = function() {
        $scope.sendFileBtn = false;
        $scope.cancelFileBtn = true;
        $scope.rejectFileBtn = false;
        var sendFilePath = prompt("please input file path(include file name)：");
        if (sendFilePath) {
            sendFilePath = sendFilePath.replace(/\\/g, "/");
            $scope.sendFilePath = sendFilePath;
            $scope.p2pAccount = $scope.target;
            imSendp2pFile({
                "account": $scope.target, 
                "file_path": $scope.sendFilePath, 
                "timeout_seconds": 60, 
                "is_encrypt": 1 
            }, {
                onSendp2pFile: function(data) {
                    var d = data;
                }
            });
        }
    };

    //This function is used to cancel the sending of files
    $scope.Cancelp2pFile = function() {
        $scope.sendFileBtn = true;
        $scope.cancelFileBtn = false;
        $scope.rejectFileBtn = false;
        imCancelp2pFile({
            "account": $scope.target, 
            "file_path": $scope.sendFilePath, 
        }, {
            onCancelp2pFile: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to receive p2p files
    $scope.Acceptp2pFileOrNot = function(fileName) {
        if (confirm("accept p2p file?")) {
            $scope.Acceptp2pFile(fileName);
        } else {
        }
    }

    //This function is used to receive files
    $scope.Acceptp2pFile = function(fileName) {
        $scope.sendFileBtn = false;
        $scope.cancelFileBtn = false;
        $scope.rejectFileBtn = true;
        var acceptFilePath = prompt("please input file path(include file name)：");
        if (acceptFilePath) {
            acceptFilePath = acceptFilePath.replace(/\\/g, "/");
            $scope.acceptFilePath = acceptFilePath;
            imAcceptp2pFile({
                "account": $scope.target, 
                "file_path": $scope.acceptFilePath,
            }, {
                onAcceptp2pFile: function(data) {
                    var d = data;
                }
            });
        }
    };

    //This function is used to deny received files
    $scope.Rejectp2pfile = function(fileName) {
        $scope.sendFileBtn = true;
        $scope.cancelFileBtn = false;
        $scope.rejectFileBtn = false;
        imRejectp2pfile({
            "account": $scope.target, 
            "file_path": $scope.acceptFilePath, 
        }, {
            onRejectp2pfile: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to discuss group broadcast operation messages (multimedia conference scenarios)
    $scope.SendDisgroupOpMessage = function(type) {
        imSendDisgroupOpMessage({
            "type": type, 
            "group_id": $scope.groupId,
            "param_list": [{
                "param": $scope.AccountVal
            }]
        }, {
            onSendDisgroupOpMessage: function(data) {
                var d = data;
            },
            onDiscussGroupBroadcast: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to get the department list
    $scope.GetDepts = function() {
        imGetDepts({
            "dept_id": -1 
        }, {
            onGetDepts: function(data) {
                var deptList = data.param.dept_list;

                var deptId = deptList[0].dept_id;
                var deptLevel = deptList[0].dept_level;
                var deptName = deptList[0].dept_name;
                var fullDeptName = deptList[0].full_dept_name;
                var parentDeptId = deptList[0].parent_dept_id;
                alert("deptId:" + deptId + "\n" +
                    "deptLevel:" + deptLevel + "\n" +
                    "deptName:" + deptName + "\n" +
                    "fullDeptName:" + fullDeptName + "\n" +
                    "parentDeptId:" + parentDeptId);
            }
        });
    };

    //This function is used for rich media login
    $scope.RichMediaLogin = function() {
        var passWord = $scope.Password || sessionStorage.tupImBase64DecodeToken;
        var tokenParam = {
            "log_file_size": {
                "device_version": "v3.1.0.100",
                "device_sn": "e0u0nkexmzvfltcyrtytndfdos04qzi5ltgzmju1mdveouncqn0=",
                "app_name": "espace",
                "device_type": "pc",
                "login_type": "3",
                "device_os": "microsoft windows 7",
                "pass_word": passWord,
                "login_name": $scope.AccountVal,
                "device_name": "hgh1000016341"
            },
            "reverseproxy": {
                "reverse_port": null,
                "reverse_ip": ""
            },
            "pst_login_info": {
                "max_file_size": 3221225472,
                "try_connect_time_out": 10,
                "en_server_mode": 2,
                "en_tls_mode": 1,
                "https_ser_list": {
                    "server_url": [{
                        "ui_host_port": 8443,
                        "en_tls_mode": 1,
                        "host_ip": "10.174.12.147",
                        "pc_url": sessionStorage.um_server_https_list
                    }],
                    "ul_cnt": 1
                },
                "min_part_size": 41943040,
                "encry_trans": 1,
                "server_expired_at": 1800000,
                "local_ip": "10.194.205.222",
                "part_trans": 1,
                "part_trans_size": 5242880,
                "st_tls_para": {
                    "client_cert_path": "",
                    "client_key_kype": "",
                    "en_verify_server_mode": 1,
                    "client_key_path": "",
                    "client_priv_keypw": "",
                    "ca_cert_path": "",
                    "client_cert_type": ""
                },
                "time_out": 120,
                "http_ser_list": {
                    "server_url": [{
                        "ui_host_port": 8443,
                        "en_tls_mode": 0,
                        "host_ip": "10.174.12.147",
                        "pc_url": sessionStorage.um_server_http_list
                    }],
                    "ul_cnt": 1
                }
            }
        };

        var accountParam = {
            "pst_login_info": {
                "en_tls_mode": 4,
                "st_tls_para": {
                    "ca_cert_path": "",
                    "client_cert_path": "",
                    "client_cert_type": "",
                    "client_key_path": "",
                    "client_key_kype": "",
                    "client_priv_keypw": "",
                    "en_verify_server_mode": 1
                },
                "local_ip": "10.146.100.89",
                "time_out": 100,
                "try_connect_time_out": 100,
                "encry_trans": 0, 
                "en_server_mode": 2, 
                "http_ser_list": {
                    "server_url": [{
                        "host_ip": "",
                        "ui_host_port": 8443,
                        "pc_url": "http://10.184.99.233:8820/umserver2/UM",   
                        "en_tls_mode": 0 
                    }],
                    "ul_cnt": 1
                },
                "https_ser_list": {
                    "server_url": [{
                        "host_ip": "",
                        "ui_host_port": 0, 
                        "pc_url": "https://10.184.99.233:18820/umserver2/UM",
                        "en_tls_mode": 0
                    }],
                    "ul_cnt": 1
                },
                "server_expired_at": 1800000, 
                "max_file_size": 3221225472, 
                "part_trans": 1, 
                "min_part_size": 41943040, 
                "part_trans_size": 5242880 
            },
            "log_file_size": {
                "login_name": $scope.AccountVal,
                "pass_word": passWord, 
                "app_name": "eSpace", 
                "login_type": "1",
                "device_type": "web",
                "device_name": "W00192586AK",
                "device_os": "windows.7.sp1.32bit",
                "device_sn": "WjJBODk3SjYwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDA=",
                "device_version": "1.2.3.17"
            }
        };
        var param = !!sessionStorage.tupImBase64DecodeToken ? tokenParam : accountParam;
        imRichMediaLogin(param, {
            onRichMediaLogin: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to upload files
    $scope.UploadFile = function() {
        $scope.mediaType = 1;
        imUploadFile({
            "up_file_info": {
                "file_path": "D:\\" + $scope.fileName,
                "file_name": $scope.fileName, 
                "resume_file_id": "", 
                "resume_up_url": "",
                "resume_down_url": "", 
                "resume_md5": "", 
                "resume_signature": "", 
                "delete_file": true, 
                "use_svn_file": true, 
                "file_type": "", 
                "operation_token": "", 
                "group_id": ""
            }
        }, {
            onUploadFile: function(data) {
                $scope.fileHandle = data.param.pfile_handle;
                $scope.$digest();
            },
            onOffLineRspNotify: function(data) {
                    var d = data.param.code +
                        data.param.file_handle +
                        data.param.filersp.callback_type +
                        data.param.filersp.code_msg +
                        data.param.filersp.file_id +
                        data.param.filersp.handle +
                        data.param.filersp.plain_access_code +
                        data.param.filersp.status_code +
                        data.param.filersp.url;
                    $scope.fileDownUrl = data.param.filersp.url;
                    $scope.$digest();
                    $scope.message = $scope.fileName + "<a href='javascript:void(0);' onclick=\'DownLoadFile(\"" + $scope.fileName + "\",\"" + $scope.fileDownUrl + "\")\'>下载</a>";
                    if ($scope.fileDownUrl) {
                        $scope.SendIm();
                    }
                }
        });
    };

    $scope.to_trusted = function(html_code) {
        return $sce.trustAsHtml(html_code);
    }

    $scope.notSendRechMedia = function(partTrans) {
        $scope.Release();
        $scope.Cancel();
    };

    //This function is used to cancel the fragment file upload
    $scope.Cancel = function() {
        imCancel({
            "file_handle": $scope.fileHandle || fileHandle
        }, {
            onCancel: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to cancel the file upload
    $scope.Release = function() {
        //Make the cancel button hidden
        //$scope.richMedia = false;
        imRelease({
            "file_handle": $scope.fileHandle || fileHandle
        }, {
            onRelease: function(data) {
                var d = data;
            }
        });
    };

    //This function is used to renew the file
    $scope.GetResumeupUrl = function() {
        imGetResumeupUrl({
            "file_handle": $scope.fileHandle
        }, {
            onGetResumeupUrl: function(data) {
                var d = data;
            }
        });
    };

    $scope.imGetContactList = function() {

    };

    //Background switch
    $scope.imageShow = false;
    $scope.imageSwitch = function(imageShow) {
        if (imageShow) {
            $scope.imageShow = false;
        } else {
            $scope.imageShow = true;
        }
    }
});

//This function is used for rich media file downloads
var fileHandle;
function DownLoadFile(fileName, fileDownUrl) {
    imDownLoadFile({
        "down_file_info": {
            "pcfile_path": "D:\\z1\\" + fileName, 
            "pcfile_down_url": fileDownUrl, 
            "user_info": "", 
            "bdown_delete": false, 
            "buse_svn_file": true, 
            "pplain_access": { 
                "access_code": "",
                "pctype": "",
                "pcheight": "",
                "pcwidth": ""
            }
        }
    }, {
        onDownLoadFile: function(data) {
            fileHandle = data.param.pcfile_handle;
        },
        onOffLineRspNotify: function(data) {
            var d = data;
        },
        onOffLineProgNotify: function(data) {
            var d = data;
        }
    });
    return false;
};

app.directive('ngRightClick', function($parse) {
    return function(scope, element, attrs) {
        var fn = $parse(attrs.ngRightClick);
        element.bind('contextmenu', function(event) {
            scope.$apply(function() {
                event.preventDefault();
                fn(scope, {
                    $event: event
                });
            });
        });
    };
});
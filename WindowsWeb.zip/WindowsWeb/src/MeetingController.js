app.controller("meetingController", function($rootScope, $scope) {
    /*load page,then give tab a value*/
    $rootScope.tab = 4;
    $scope.MeetingPageShow = true;
    $scope.confSeachShow = true;
    $scope.screenShow = 0;

    if (sessionStorage.meetingConfHandle != null && sessionStorage.meetingConfHandle != '' && sessionStorage.meetingConfHandle != undefined) {
        $scope.MeetingPageShow = false;
    }
    // $scope.LoginPageShow = false;
    $scope.SVNVersion = "20170508-0858_svn17658_json";
    // 入会参数
    $scope.meetingTitle = "DataConf"; //会议主题名称
    $scope.meetingOption = 4096; //会议控制选项，0 只提供会议基本功能；1 支持用户数据内部维护；2 最优服务器登录
    $scope.meetingUserType = 1; //用户类型，1 主持人； 2 主讲人 ；8  普通与会者
    $scope.meetingUserID = 155; //用户ID
    $scope.meetingUserName = "ding"; //用户名称
    $scope.meetingHostKey = 456; //主持人密码：主持人入会必须设置
    $scope.meetingConfID = 8; //会议ID
    $scope.meetingEncryptionKey = "123"; //入会密码

    //屏幕共享
    $scope.imgScreenSrc = "bin/img/headimg/0.png"; //屏幕截图
    $scope.imgDSSrc = "bin/img/confctrl/loading.gif"; //文档共享加载中

    //文档共享
    $scope.meetingCurrentPage = parseInt(sessionStorage.meetingPageId) || 0; //当前页
    $scope.meetingDSannotation = 0;
    $scope.localIndex = 0;
    $scope.meetingtype = 0;
    $scope.subtype = 0;
    $scope.pString = ""; //text info
    $scope.canvasX = 0;
    $scope.canvasY = 0;
    $scope.confSync = 1;
    $scope.annoid = 0; //标注ID
    $scope.annoidType = 0; //标注类型

    //与会者列表信息
    $scope.meetingAttendeeList = new Array();
    if (sessionStorage.meetingAttendeeList != null && sessionStorage.meetingAttendeeList != '' && sessionStorage.meetingAttendeeList != undefined) {
        $scope.meetingAttendeeList = JSON.parse(sessionStorage.meetingAttendeeList);
    }

    $scope.meetingBasicEvent = function() {
        setBasicMeetingEvent({
            onUserEnterInd: onUserEnterInd,
            onuserLeaveKickout: onuserLeaveKickout,
            onConfLeave: onConfLeave,
            onAsOnSharingSession: onAsOnSharingSession,
            onAsOnScreenData: onAsOnScreenData,
            onAsOnSharingState: onAsOnSharingState,
            onDocNew: onDocNew,
            onPageNew: onPageNew,
            onCurrentPageInd: onCurrentPageInd,
            onDocDel: onDocDel,
            onPageDel: onPageDel,
            onWbDocDel:onWbDocDel,
            onWbPageDel:onWbPageDel,
            onDrawDataNotify: onDrawDataNotify,
            onWbdrawDataNotify: onWbdrawDataNotify,
            hostChangeInd: hostChangeInd,
            onAsSaveResult: onAsSaveResult,
            onWbCurrentPageInd: onWbCurrentPageInd
        });
    }

    function onUserEnterInd(data) {

        $scope.meetingAttendeeList.push(data);
        $scope.$digest();
        sessionStorage.meetingAttendeeList = JSON.stringify($scope.meetingAttendeeList);
    }

    function onuserLeaveKickout(data) {
        alert("您已离开会议");
        sessionStorage.removeItem("meetingConfHandle");
        sessionStorage.removeItem("meetingAttendeeList");
        $scope.MeetingPageShow = true;
        $scope.$digest();

    }

    function onConfLeave(data) {
        for (var i = 0; i < $scope.meetingAttendeeList.length; i++) {
            if ($scope.meetingAttendeeList[i].user_alt_id == data.user_alt_id) {
                delete $scope.meetingAttendeeList[i];
            }
        }
        $scope.$digest();
    }

    function onAsOnSharingSession(data) {
        alert("共享通道已开启");
    }

    var i = 0;

    function onAsOnScreenData(data) {
        // $scope.screenShow = 2;
        // $scope.imgScreenSrc = "Tup/windows/"+$scope.SVNVersion+"/2.jpg";
        // $scope.$digest();
        $scope.imgScreenSrc = "file:/" + data.filepath;
        $scope.$digest();
        console.log("屏幕共享传输中。。。。");

    }

    function onAsOnSharingState(data) {
        if (data.value2 == 2) {
            alert("共享端开始共享");
            console.log("屏幕共享抓取中。。。。");
            $scope.screenShow = 1;
            $scope.$digest();
        } else if (data.value2 == 0) {
            alert("共享端结束共享");
            console.log("屏幕共享已结束。。。。");
            $scope.screenShow = 0;
            $scope.$digest();
        } else if (data.value2 == 1) {
            alert("观看端观看");
            console.log("观看端观看中···");
            $scope.screenShow = 2;
            $scope.$digest();
        }

        // $scope.imgScreenSrc = "bin/img/headimg/" + i + ".png";
        // $scope.$digest();

    }

    function onDocNew(data) {

    }

    function onPageNew(data) {
        $scope.screenShow = 3;
        $scope.$digest();
    }

    function onCurrentPageInd(data) {

        $scope.meetingCurrentPage = data.value2;
        $scope.$digest();
    }

    function onDocDel(data) {
        $scope.screenShow = 0;
        $scope.$digest();
        alert("文档共享已停止");
    }

    function onPageDel(data) {

    }

    function onWbDocDel(data) {
        $scope.screenShow = 0;
        $scope.$digest();
        alert("白板共享已停止");
    }

    function onWbPageDel(data) {

    }


    //定时刷新，图片 如果频繁请求导致崩溃、

    // $scope.drawDataRefresh = function() {

    //     DrawDataTime = setInterval(function() {
    //         $scope.imgDSSrc = "Tup/windows/" + $scope.SVNVersion + "/trace/1.jpg" + "?tempid=" + Math.random();
    //         $scope.$digest();
    //     }, 500);
    // };

    // $scope.endDrawDataRefresh = function() {
    //     clearInterval(DrawDataTime);
    // }

    function onDrawDataNotify(data) {
        if (data.value2 != 0) {
            // 非0页
            // $scope.imgDSSrc = "Tup/windows/" + $scope.SVNVersion + "/trace/" + data.filepath + "1.jpg" + "?tempid=" + Math.random();
            $scope.imgDSSrc = "file:/" + data.filepath;
            $scope.$digest();
        }

    }

    function onWbdrawDataNotify(data) {

    }

    function hostChangeInd(data) {
        for (var i = 0; $scope.meetingAttendeeList.length; i++) {
            if ($scope.meetingAttendeeList[i].user_alt_id == data.value2) {
                $scope.meetingAttendeeList[i].value2 = 1;
            }
        }
        sessionStorage.meetingAttendeeList = JSON.stringify(meetingAttendeeList);
        $scope.$digest();
    }

    var i = 1;

    function onAsSaveResult(data) {
        // if (data.result == 0) {
        //     $scope.screenShow = 2;
        //     if (i == 2) {
        //         $scope.imgScreenSrc = "Tup/windows/" + $scope.SVNVersion + "/" + i + ".jpg";
        //         i = 1;
        //     } else {
        //         $scope.imgScreenSrc = "Tup/windows/" + $scope.SVNVersion + "/" + i + ".jpg";
        //         i = 2;
        //     }
        //     $scope.$digest();
        // }
    }

    function onWbCurrentPageInd(data) {
        $scope.meetingCurrentPage = data.value2;
        $scope.$digest();
    }


    $scope.meetingNew = function() {
            CreateConference($scope.meetingTitle, parseInt($scope.meetingOption), parseInt($scope.meetingUserType), parseInt($scope.meetingUserID), $scope.meetingUserName, $scope.meetingHostKey, parseInt($scope.meetingConfID), $scope.meetingEncryptionKey, "CN30", "huawei", "10.173.19.108", 0, 0, 0,0,0, { response: onConferenceNewResult });
            // JoinConference({ onJoinConference: onjoinConferenceResult });

        }
        //语音会议升级为数据会议页面跳转
    setTimeout(function() {
        if (sessionStorage.getItem("upgrade") == "true") {
            $("#upgradeConfLoading").hide();
            $scope.MeetingPageShow = false;
            $scope.$digest();
            if (sessionStorage.getItem("timeController") == "true") {
                $scope.timing();
                alert("创会成功");
                sessionStorage.removeItem("timeController");
            }
        } else {
            //alert("创会失败");
        }
    }, 2500);

    function onConferenceNewResult(data) {
        if (data == 0) {
            $scope.MeetingPageShow = false;
            $scope.$digest();
            $scope.timing();
            // alert("创会成功");
        } else {
            alert("创会失败");
        }
    }

    function onjoinConferenceResult(data) {
        if (data == 0) {
            // $scope.MeetingPageShow = false;
            // $scope.$digest();
            // alert("入会成功");
        } else {
            alert("入会失败");
        }
    }
    //终止会议
    $scope.TerminateConference = function() {
        TerminateConference({ response: onconfTerminate });
    }

    function onconfTerminate(data) {
        if (data == 0) {
            $scope.MeetingPageShow = true;
            $scope.$digest();
            $scope.meetingAttendeeList = new Array();
            // alert("终止会议成功");
        } else {
            alert("终止会议失败");
        }
    }
    //离开会议
    $scope.LeaveConference = function() {
        LeaveConference({ response: onuserLeave });
    }

    function onuserLeave(data) {
        if (data == 0) {
            $scope.MeetingPageShow = true;
            $scope.$digest();
            $scope.meetingAttendeeList = new Array();
            alert("离开会议成功");
        } else {
            alert("离开会议失败");
        }
    }

    //踢出与会者

    $scope.ConfUserKickout = function(userid) {
        ConfUserKickout(userid);
    }

    //设置取消会议锁定
    $scope.ConfLock = function() {
        ConfLock();
    }


    //设置取消会议闭音
    $scope.ConfMute = function() {
        ConfMute();
    }


    //开始屏幕共享
    $scope.ConfAsStart = function(sharingtype) {
        sessionStorage.sharingtype = sharingtype;
        ConfAsStart($scope.meetingAttendeeList[0].user_alt_id);
    }

    //结束屏幕共享
    $scope.ConfAsStop = function() {
        ConfAsStop($scope.meetingAttendeeList[0].user_alt_id);
    }

    //授予远程控制
    $scope.ConfAsSetPrivilege = function(privilege, action, userid) {
        ConfAsSetPrivilege(privilege, action, userid);
    }

    //开始屏幕标注
    $scope.ConfAsBeginAnnotation = function() {
        ConfAsBeginAnnotation();
    }

    //结束屏幕标注
    $scope.ConfAsEndAnnotation = function() {
        ConfAsEndAnnotation();
    }

    //开始白板共享
    $scope.ConfDsNewDoc = function() {
        ConfDsNewDoc({ onWbDocNew: onWbDocNew });
    }

    function onWbDocNew(data) {
        $scope.screenShow = 5;
        $scope.$digest();
    }

    //结束白板共享
    // $scope.ConfDsNewDoc = function() {
    //     ConfDsNewDoc();
    // }


    //开始文档共享
    $scope.ConfDsOpen = function() {
        ConfDsOpen("D:/1.docx", { response: dsOpenResult });
    }

    function dsOpenResult(data) {
        $scope.screenShow = 3;
        $scope.$digest();
    }
    // 下一页
    $scope.nextMeetingInfo = function() {
        $scope.meetingCurrentPage = $scope.meetingCurrentPage + 1;
        dsSetCurrentPage($scope.meetingCurrentPage, parseInt(sessionStorage.meetingDOCId), 1, $scope.confSync, { response: onSetCurrentPageResult, onCurrentPage: onCurrentPage });
    }

    //上一页
    //This function is used to Page up
    $scope.preMeetingInfo = function() {
        $scope.meetingCurrentPage = ($scope.meetingCurrentPage - 1) <= 0 ? 1 : ($scope.meetingCurrentPage - 1);
        dsSetCurrentPage($scope.meetingCurrentPage, parseInt(sessionStorage.meetingDOCId), 1, $scope.confSync, { response: onSetCurrentPageResult, onCurrentPage: onCurrentPage });
    }

    function onSetCurrentPageResult(data) {
        $scope.meetingCurrentPage = parseInt(sessionStorage.meetingPageId);
        $scope.$digest();
        alert("已经到底啦！");
    }

    function onCurrentPage(data) {
        $scope.imgDSSrc = "bin/img/confctrl/loading.gif";
        $scope.$digest();
        //当前页
    }

    function onWBCurrentPage(data) {
        $scope.imgDSSrc = "bin/img/confctrl/loading.gif";
        $scope.$digest();
    }

    //与会者同步文档共享数据
    $scope.dsGetSyncinfo = function() {
        $scope.confSync = 1;
        dsGetSyncinfo({ onDsSyncInfo: onDsSyncInfo });
    }

    function onDsSyncInfo(data) {
        // alert("同步成功");
    }

    //结束文档共享
    $scope.confDsClose = function() {
        ConfDsClose();
       // $scope.endDrawDataRefresh();
    }

    //结束白板共享
    $scope.confWBClose = function() {
        ConfDsDeleteDoc();
       // $scope.endDrawDataRefresh();
    }

    //标注
    $scope.annotationCreateStart = function(point, subtype, ciid, type) {
        annotationCreateStart(point, subtype, ciid, type);
    }

    $scope.annotationCreateUpdate = function(ciid, pdata) {
        annotationCreateUpdate(ciid, pdata);
    }

    $scope.annotationCreateDone = function(ret_annoid, ciid, bCancel) {
        annotationCreateDone(ret_annoid, ciid, bCancel);
    }

    //Local page
    $scope.confPageSync = function(isSync) {
        $scope.confSync = isSync;
    }


    //annotation切换
    $scope.annotationSwitch = function(annotation) {
        switch (annotation) {
            case 0:
                $scope.meetingDSannotation = 0;
                $scope.annoidType = 1;
                break;
            case 1:
                $scope.meetingDSannotation = 1;
                $scope.annoidType = 1;
                break;
            case 2:
                $scope.meetingDSannotation = 2;
                $scope.annoidType = 1;
                break;
            case 3:
                if ($scope.meetingDSannotation == 20) {
                    annotationSetselect(0, $scope.annoidType, $scope.annoid);
                    $scope.meetingDSannotation = 3;
                } else {
                    $scope.meetingDSannotation = 3;
                }
                $scope.annoidType = 1;
                break;
            case 4:
                $scope.meetingDSannotation = 4;
                $scope.annoidType = 1;
                break;
            case 5:
                $scope.meetingDSannotation = 5;
                $scope.subtype = 1;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 6:
                $scope.meetingDSannotation = 6;
                $scope.subtype = 2;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 7:
                $scope.meetingDSannotation = 7;
                $scope.subtype = 3;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 8:
                $scope.meetingDSannotation = 8;
                $scope.subtype = 4;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 9:
                $scope.meetingDSannotation = 9;
                $scope.subtype = 10;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 10:
                $scope.meetingDSannotation = 10;
                $scope.subtype = 11;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 11:
                $scope.meetingDSannotation = 11;
                $scope.subtype = 12;
                $scope.meetingtype = 12;
                $scope.annoidType = 1;
                break;
            case 12:
                $scope.meetingDSannotation = 12;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 0;
                $scope.annoidType = 1;
                break;
            case 13:
                $scope.meetingDSannotation = 13;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 1;
                $scope.annoidType = 1;
                break;
            case 14:
                $scope.meetingDSannotation = 14;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 2;
                $scope.annoidType = 1;
                break;
            case 15:
                $scope.meetingDSannotation = 15;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 3;
                $scope.annoidType = 1;
                break;
            case 16:
                $scope.meetingDSannotation = 16;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 4;
                $scope.annoidType = 1;
                break;
            case 17:
                if ($scope.meetingDSannotation == 17) {
                    annotationLaserpointerStop(1);
                } else {
                    $scope.meetingDSannotation = 17;
                }
                $scope.annoidType = 1;
                break;
            case 18:
                $scope.meetingDSannotation = 18;
                $scope.annoidType = 1;
                break;

            case 30:
                $scope.meetingDSannotation = 30;
                $scope.annoidType = 512;
                break;
            case 31:
                $scope.meetingDSannotation = 31;
                $scope.annoidType = 512;
                break;
            case 32:
                $scope.meetingDSannotation = 32;
                $scope.annoidType = 512;
                break;
            case 33:
                if ($scope.meetingDSannotation == 50) {
                    annotationSetselect(0, 512, $scope.annoid);
                    $scope.meetingDSannotation = 33;
                } else {
                    $scope.meetingDSannotation = 33;
                }
                $scope.annoidType = 512;
                break;
            case 34:
                $scope.meetingDSannotation = 34;
                $scope.annoidType = 512;
                break;
            case 35:
                $scope.meetingDSannotation = 35;
                $scope.subtype = 1;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 36:
                $scope.meetingDSannotation = 36;
                $scope.subtype = 2;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 37:
                $scope.meetingDSannotation = 37;
                $scope.subtype = 3;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 38:
                $scope.meetingDSannotation = 38;
                $scope.subtype = 4;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 39:
                $scope.meetingDSannotation = 39;
                $scope.subtype = 10;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 40:
                $scope.meetingDSannotation = 40;
                $scope.subtype = 11;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 41:
                $scope.meetingDSannotation = 41;
                $scope.subtype = 12;
                $scope.meetingtype = 12;
                $scope.annoidType = 512;
                break;
            case 42:
                $scope.meetingDSannotation = 42;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 0;
                $scope.annoidType = 512;
                break;
            case 43:
                $scope.meetingDSannotation = 43;
                $scope.subtype = 1;
                $scope.meetingtype = 13;
                $scope.localIndex = 1;
                $scope.annoidType = 512;
                break;
            case 44:
                $scope.meetingDSannotation = 44;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 2;
                $scope.annoidType = 512;
                break;
            case 45:
                $scope.meetingDSannotation = 45;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 3;
                $scope.annoidType = 512;
                break;
            case 46:
                $scope.meetingDSannotation = 46;
                $scope.subtype = 2;
                $scope.meetingtype = 13;
                $scope.localIndex = 4;
                $scope.annoidType = 512;
                break;
            case 47:
                if ($scope.meetingDSannotation == 47) {
                    annotationLaserpointerStop(512);
                } else {
                    $scope.meetingDSannotation = 47;
                }
                $scope.annoidType = 512;
                break;
            case 48:
                $scope.meetingDSannotation = 48;
                $scope.annoidType = 512;
                break;
            default:

        }
    }

    //创建文字标注（文档）
    $scope.annotationTextCreate = function(x, y, pString, ciid) {
        var pInfo = {
            "bounds": {
                "left": x,
                "top": y,
                "right": x + 1500,
                "bottom": y + 300
            },
            "pString": pString,
            "pFont": "宋体",
            "color": 255,
            "size": 240,
            "reserve": 0
        }
        annotationTextCreate(pInfo, 0, ciid);
    }

    //更新文字标注（文档）

    //探测坐标
    $scope.annotationHittest = function(point) {
        annotationHittest(point, 0, $scope.annoidType, { onAnnoHittest: onAnnoHittest });

    }

    //获取当前标注内容
    $scope.annotationTextGetinfo = function(ciid, annoid) {
        annotationTextGetinfo(ciid, annoid, { onAnnoTextGetInfo: onAnnoTextGetInfo });
    }

    function onAnnoTextGetInfo(data) {
        if (data.annoid) {
            var x = $scope.canvasX;
            var y = $scope.canvasY;
            var pInfo = {
                "bounds": {
                    "left": x,
                    "top": y,
                    "right": x + 1500,
                    "bottom": y + 300
                },
                "pString": diag($scope.pString),
                "pFont": "宋体",
                "color": 255,
                "size": 240,
                "reserve": 0
            }
            $scope.annotationTextUpdate($scope.annoidType, pInfo, parseInt(data.annoid));
        }

    }

    //编辑标注

    $scope.annotationTextUpdate = function(ciid, pInfo, annoid) {
        annotationTextUpdate(true, pInfo, ciid, annoid);
    }

    //删除文字标
    $scope.annotationDelete = function(point, ciid) {
        annotationHittest(point, 0, ciid, { onAnnoHittest: onAnnoHittest });

    }

    function onAnnoHittest(data) {
        if (data.annoid != 0) {
            $scope.annoid = data.annoid;
            if ($scope.meetingDSannotation == 2 || $scope.meetingDSannotation == 32) {
                annotationDelete($scope.annoidType, data.annoid);
            } else if ($scope.meetingDSannotation == 4 || $scope.meetingDSannotation == 34) {
                // annotationSetselect(1, 1, data.annoid);
                $scope.annotationTextGetinfo($scope.annoidType, data.annoid);

            } else if ($scope.meetingDSannotation == 3) {
                //此处确定标注
                // $scope.annotationTextGetinfo(1, parseInt(data.annoid));
                annotationSetselect(1, $scope.annoidType, data.annoid);
                $scope.meetingDSannotation = 20;
                // annotationEditStart();
                // annotationEditStart(1, 6, 1, { "x": $scope.canvasX, "y": $scope.canvasY }, $scope.annoid);
            } else if ($scope.meetingDSannotation == 33) {
                annotationSetselect(1, $scope.annoidType, data.annoid);
                $scope.meetingDSannotation = 50;
            }

        }
    }

    //开始激光笔
    $scope.annotationLaserpointerStart = function() {
        AnnotationInit();
        annotationLaserpointerStart();
    }

    //移动激光笔
    $scope.annotationLaserpointerMoveto = function() {
        annotationLaserpointerMoveto();
    }

    //结束激光笔
    $scope.annotationLaserpointerStop = function() {
        annotationLaserpointerStop();
    }

    //隐藏显示搜索框
    $scope.ConfSeach = function() {
        if ($scope.confSeachShow) {
            $scope.confSeachShow = false;
        } else {
            $scope.confSeachShow = true;
        }
    }


    //屏幕共享


    setTimeout(function() { meetingASboard(); }, 2000)

    // 白板共享文档界面canvas操作
    function meetingASboard() {
        var c = document.getElementById("imgASCanvas");
        var ctx = c.getContext("2d");
        var imgDS = document.getElementById("screenShow");
        imgDS.onload = function() {
            ctx.drawImage(imgDS, 0, 0, 750, 650);
        }

        //获取当前鼠标的坐标
        c.onmousedown = function(e) {
            var x = e.clientX,
                y = e.clientY,
                left = this.parentNode.offsetLeft + 4,
                top = this.parentNode.offsetTop + 155,
                canvasX = (x - left) * 15,
                canvasY = (y - top) * 15; //此处坐标定位有问题，需开发者根据自身分辨率调整
            console.log(x + "===========" + y);
            ConfAsInputWndMsg(513, 0, 0, { "x": canvasX, "y": canvasY });
            document.onmousemove = function(e) {
                var x = e.clientX,
                    y = e.clientY,
                    canvasX = (x - left),
                    canvasY = (y - top); //此处坐标定位有问题，需开发者根据自身分辨率调整
                // alert(x + "*****" + y + "***" + canvasX + "***" + canvasY);

                ConfAsInputWndMsg(512, 0, 0, { "x": canvasX, "y": canvasY });
            }

        }
    }



    //延时加载数据
    setTimeout(function() { meetingWhiteboard(); }, 2000)

    // 白板共享文档界面canvas操作
    function meetingWhiteboard() {
        var c = document.getElementById("imgWBCanvas");
        var ctx = c.getContext("2d");
        var imgDS = document.getElementById("DOCWBShow");
        imgDS.onload = function() {
            ctx.drawImage(imgDS, 0, 0);
        }

        //获取当前鼠标的坐标
        c.onmousedown = function(e) {
            var x = e.clientX,
                y = e.clientY,
                left = this.parentNode.offsetLeft + 4,
                top = this.parentNode.offsetTop + 155,
                canvasX = (x - left) * 15,
                canvasY = (y - top) * 15; //此处坐标定位有问题，需开发者根据自身分辨率调整
            $scope.canvasX = canvasX;
            $scope.canvasY = canvasY;
            // alert(left + "****" + x + "*****" + top + "****" + y + "***" + canvasX + "***" + canvasY);
            //判断是否操作白板
            if ($scope.meetingDSannotation == 31) {
                var pString = diag("");
                $scope.pString = pString;
                $scope.annotationTextCreate(canvasX, canvasY, pString, 512);
            } else if ($scope.meetingDSannotation == 32) {
                $scope.annotationDelete({ "x": canvasX, "y": canvasY }, 512);
            } else if ($scope.meetingDSannotation == 33) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation == 34) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation >= 35 && $scope.meetingDSannotation <= 41) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 512, $scope.meetingtype);
            } else if ($scope.meetingDSannotation >= 42 && $scope.meetingDSannotation <= 46) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 512, $scope.meetingtype);
            } else if ($scope.meetingDSannotation == 47) {
                annotationLaserpointerStart(512, { "x": canvasX, "y": canvasY }, { "cx": 28 * 15, "cy": 28 * 15 });
            } else if ($scope.meetingDSannotation == 50) {
                annotationEditStart($scope.annoid, 6, 512, { "x": $scope.canvasX, "y": $scope.canvasY }, $scope.annoid);
            }

            //获取鼠标移动事件
            document.onmousemove = function(e) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left),
                        canvasY = (y - top); //此处坐标定位有问题，需开发者根据自身分辨率调整
                    // alert(x + "*****" + y + "***" + canvasX + "***" + canvasY);
                    if ($scope.meetingDSannotation == 33) {

                    } else if ($scope.meetingDSannotation >= 42 && $scope.meetingDSannotation <= 46) {
                        //自定义图形
                        var pdata = {
                            "bLocal": 1,
                            "localIndex": $scope.localIndex,
                            "dispRect": {
                                "left": canvasX * 15 - 14 * 15,
                                "top": canvasY * 15 - 14 * 15,
                                "right": (canvasX + 28) * 15,
                                "bottom": (canvasY + 28) * 15
                            }
                        }
                        annotationCreateCustomerUpdate(512, pdata);
                    } else if ($scope.meetingDSannotation >= 35 && $scope.meetingDSannotation <= 41) {
                        // 几何标注
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationCreateDrawingUpdate(512, pdata);
                    } else if ($scope.meetingDSannotation == 47) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationLaserpointerMoveto(512, pdata);
                    } else if ($scope.meetingDSannotation == 50) {
                        annotationEditUpdate(512, { "x": canvasX * 15, "y": canvasY * 15 });
                    }
                }
                //获取鼠标弹起事件
            document.onmouseup = function(e) {
                var t = e.target;
                if (t == c) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left) * 15,
                        canvasY = (y - top) * 15; //此处坐标定位有问题，需开发者根据自身分辨率调整

                    if ($scope.meetingDSannotation >= 35 && $scope.meetingDSannotation <= 46) {
                        annotationCreateDone(0, 512, false);
                    } else if ($scope.meetingDSannotation == 47) {

                    } else if ($scope.meetingDSannotation == 33) {

                    } else if ($scope.meetingDSannotation == 50) {
                        annotationEditDone(false, 512);
                    }
                }
                this.onmousemove = null;
            }

        }
    }


    //文档共享(canvas)
    setTimeout(function() { meetingDSBoard(); }, 500);

    function meetingDSBoard() {
        var c = document.getElementById("imgDSCanvas");
        var ctx = c.getContext("2d");
        var imgDS = document.getElementById("DOCShow");
        imgDS.onload = function() {
            ctx.drawImage(imgDS, 0, 0);
        }

        //获取当前鼠标的坐标
        c.onmousedown = function(e) {
            var x = e.clientX,
                y = e.clientY,
                left = this.parentNode.offsetLeft + 3,
                top = this.parentNode.offsetTop + 155,
                canvasX = (x - left) * 15,
                canvasY = (y - top) * 15; //此处坐标定位有问题，需开发者根据自身分辨率调整
            $scope.canvasX = canvasX;
            $scope.canvasY = canvasY;
            // alert(left + "****" + x + "*****" + top + "****" + y + "***" + canvasX + "***" + canvasY);
            //判断是否操作文档
            if ($scope.meetingDSannotation == 1) {
                var pString = diag("");
                $scope.pString = pString;
                $scope.annotationTextCreate(canvasX, canvasY, pString, 1);

            } else if ($scope.meetingDSannotation == 2) {
                $scope.annotationDelete({ "x": canvasX, "y": canvasY }, 1);
            } else if ($scope.meetingDSannotation == 3) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation == 4) {
                $scope.annotationHittest({ "x": canvasX, "y": canvasY });
            } else if ($scope.meetingDSannotation >= 5 && $scope.meetingDSannotation <= 11) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 1, $scope.meetingtype);
            } else if ($scope.meetingDSannotation >= 12 && $scope.meetingDSannotation <= 16) {
                $scope.annotationCreateStart({ "x": canvasX, "y": canvasY }, $scope.subtype, 1, $scope.meetingtype);
            } else if ($scope.meetingDSannotation == 17) {
                annotationLaserpointerStart(1, { "x": canvasX, "y": canvasY }, { "cx": 28 * 15, "cy": 28 * 15 });
            } else if ($scope.meetingDSannotation == 20) {
                annotationEditStart($scope.annoid, 6, $scope.annoidType, { "x": $scope.canvasX, "y": $scope.canvasY }, $scope.annoid);
            }

            //获取鼠标移动事件
            document.onmousemove = function(e) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left),
                        canvasY = (y - top); //此处坐标定位有问题，需开发者根据自身分辨率调整
                    // alert(x + "*****" + y + "***" + canvasX + "***" + canvasY);
                    if ($scope.meetingDSannotation == 3) {

                    } else if ($scope.meetingDSannotation >= 12 && $scope.meetingDSannotation <= 16) {
                        //自定义图形
                        var pdata = {
                            "bLocal": 1,
                            "localIndex": $scope.localIndex,
                            "dispRect": {
                                "left": canvasX * 15 - 14 * 15,
                                "top": canvasY * 15 - 14 * 15,
                                "right": (canvasX + 28) * 15,
                                "bottom": (canvasY + 28) * 15
                            }
                        }
                        annotationCreateCustomerUpdate(1, pdata);
                    } else if ($scope.meetingDSannotation >= 5 && $scope.meetingDSannotation <= 11) {
                        // 几何标注
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationCreateDrawingUpdate(1, pdata);
                    } else if ($scope.meetingDSannotation == 17) {
                        var pdata = {
                            "x": canvasX * 15,
                            "y": canvasY * 15
                        }
                        annotationLaserpointerMoveto(1, pdata);
                    } else if ($scope.meetingDSannotation == 20) {
                        annotationEditUpdate($scope.annoidType, { "x": canvasX * 15, "y": canvasY * 15 });
                    }
                }
                //获取鼠标弹起事件
            document.onmouseup = function(e) {
                var t = e.target;
                if (t == c) {
                    var x = e.clientX,
                        y = e.clientY,
                        canvasX = (x - left) * 15,
                        canvasY = (y - top) * 15; //此处坐标定位有问题，需开发者根据自身分辨率调整

                    if ($scope.meetingDSannotation >= 5 && $scope.meetingDSannotation <= 16) {
                        annotationCreateDone(0, 1, false);
                    } else if ($scope.meetingDSannotation == 17) {

                    } else if ($scope.meetingDSannotation == 3) {

                    } else if ($scope.meetingDSannotation == 20) {
                        annotationEditDone(false, $scope.annoidType);
                    }
                }
                this.onmousemove = null;
            }

        }

    }

    function diag(pString) {
        var str = prompt("enter the contents", pString);
        if (str) {
            return str;
        }

    }
    // setInterval(function() { ctx.drawImage(imgDS, 0, 0); }, 200);

    //文字标注
    $(function() {
        $("#annotationFont").click(function() {
            $("#annotationTypeFont").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#annotationTypeFont").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationTypeFont").hide();
        });
    })

    //WB
    $(function() {
        $("#annotationWBFont").click(function() {
            $("#annotationWBTypeFont").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#annotationWBTypeFont").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationWBTypeFont").hide();
        });
    })

    //图形标注
    $(function() {
        $("#annotationCustomer").click(function() {
            $("#annotationTypeCustomer").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#annotationTypeCustomer").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationTypeCustomer").hide();
        });
    })

    //WB
    $(function() {
        $("#annotationWBCustomer").click(function() {
            $("#annotationWBTypeCustomer").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#annotationWBTypeCustomer").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationWBTypeCustomer").hide();
        });
    })


    //几何标注
    $(function() {
        $("#annotationDrawing").click(function() {
            $("#annotationTypeDrawing").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#annotationTypeDrawing").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationTypeDrawing").hide();
        });
    })

    //WB
    $(function() {
        $("#annotationWBDrawing").click(function() {
            $("#annotationWBTypeDrawing").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#annotationWBTypeDrawing").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#annotationWBTypeDrawing").hide();
        });
    })



    $(function() {
        $("#screenShare").click(function() {
            $("#screenShareType").show();
            return false; //关键是这里，阻止冒泡
        });
        $("#screenShareType").click(function() {
            return false;
        });
        $(document).click(function() {
            $("#screenShareType").hide();
        });
    })


    //视频窗口
    var localView = $('#meetingLocalCanvas')[0];
    var remoteView1 = $('#meetingRemoteCanvas1')[0];
    var remoteView2 = $('#meetingRemoteCanvas2')[0];
    var remoteView3 = $('#meetingRemoteCanvas3')[0];

    $scope.confVideo = function() {
        ConfVideoOpen({ lcCanvas: localView, width: 320, height: 240 ,userid:($scope.meetingUserID)});
        // ConfVideoOpen({ rtCanvas: remoteView1, width: 320, height: 240 ,userid:156});
        // ConfVideoOpen({ rtCanvas: remoteView2, width: 320, height: 240 ,userid:157});
        // ConfVideoOpen({ rtCanvas: remoteView3, width: 320, height: 240 ,userid:158});
    }


    $scope.confVideoClose = function() {
        ConfVideoClose();
    }



});
app.controller("callController", function($rootScope, $scope) {
	$rootScope.tab = 2;
	$scope.callShow = true;
    //If you are logged in, the switch back is still out of the login page after the label is switched
    if(sessionStorage.authorize_result && sessionStorage.getItem("sipLogin")){
        $('#sipLoginPanel').hide();
        $('#callFullPanel').show();
        displaySipNum();
        loadStorage();  
    } else {
        $('#sipLoginPanel').show();
        $('#callFullPanel').hide();
    }  
    //This method is auto invoked when onload page, and it's used to memory registered account last time
   loadAccount();
   //This method is auto invoked when onload page, and it's used to memory local configure information last time
   loadLoaclCfg();
   uiregisterCallbcak();
    // hide the video window
    $('#myCanvas').hide();
    //panel switch
    $('#callingPanel').hide();
    $('#incomingPanel').hide();        
  
    $('#startCall').click(function (){
        $('#callPanel').hide();
        $('#callingPanel').show();
    });
    $('#videoCall').click(function (){
        $('#callPanel').hide();
        $('#callingPanel').show();
    });
    $('#endCall').click(function (){
        $('#callingPanel').hide();
        $('#callPanel').show();
    });
    $('#acceptCall').click(function (){
        $('#incomingPanel').hide();
        $('#callingPanel').show();
    });
    $('#unmutMic').hide();
    $('#muteMic').click(function(){
        $('#muteMic').hide();
        $('#unmutMic').show();
    });
    $('#unmutMic').click(function(){
        $('#unmutMic').hide();
        $('#muteMic').show();
    });
    $('#unholdCall').hide();
    $('#holding').hide();

    $('#delVideo').hide();
    $('#addVideo').click(function(){
        $('#addVideo').hide();
        $('#delVideo').show();
    });
    $('#delVideo').click(function(){
        $('#delVideo').hide();
        $('#addVideo').show();
    });      
    $('#stopRec').hide();
    $('#startRec').click(function(){
        $('#startRec').hide();
        $('#stopRec').show();
    });
    $('#stopRec').click(function(){
        $('#stopRec').hide();
        $('#startRec').show();
    });  
    $('#dtmfDial').hide();
    $('#keyBoard').click(function(){
        $('#dtmfDial').toggle();
        $('#calling_num').toggle();
        $('#caller_num').toggle();        
    });    
    $('#transDial').hide();
    $('#blindTransfer').click(function(){
        $('#transDial').toggle();
        $('#blind').show();
        $('#divert').hide();
        $('#calling_num').toggle();
        $('#transto_number').val("");        
    });
    $('#divertCall').click(function(){
        $('#transDial').toggle();
        $('#divert').show();
        $('#blind').hide();
        $('#transto_number').val(""); 
    });
    $('#divert').click(function(){
        $('#transDial').hide();
    });  
    $('#blind').click(function(){
        $('#transDial').hide();
    }); 
    $('#toAudio').hide();
    $('#toAudio').click(function(){
        $('#incomingPanel').hide();
        $('#callingPanel').show();
    });
    $('#iptPanel').hide();
    $('#iptSet').click(function(){
        $('#iptPanel').toggle();
    });
    // show the ctd call page
    $('#initCtd').click(function(){
        if($('#ctdCallerNum').val() !=""){
            $('.normal_Call').hide();
            $('.ctd_Call').show();
            $('.buttons').hide();            
        } else {
            $('.normal_Call').show();
            $('.ctd_Call').hide();
            $('.buttons').show();
        }    
    });
    $('#uninitCtd').click(function(){
        $('.normal_Call').show();
        $('.ctd_Call').hide();
        $('.buttons').show();        
    });    
    $('#mediaPanel').hide();
    $('#mediaSet').click(function(){
        $('#mediaPanel').toggle();
    });

    $("#p2pTransToConf").hover(function(){
        $('#hoverDisplayP2p').hide();
        $('#displayTransButton').show();        
    })
    $("#p2pTransToConf").mouseleave(function(){
        $('#hoverDisplayP2p').show();
        $('#displayTransButton').hide();        
    })
    if(sessionStorage.getItem("lock")){
        $('#callPanel').hide();
        $('#callingPanel').show();
        $('#timing').show();
        $('#callState').val("");
        $('#callState').val("call connected");
        $('#calling_num').val(sessionStorage.getItem("telNum"));
        sessionStorage.removeItem("callerNum");
    }
    if(sessionStorage.getItem("callerNum")){
        $('#caller_num').val(sessionStorage.getItem("callerNum"));
        $('#callPanel').hide();
        $('#callingPanel').hide();
        $('#incomingPanel').show(); 
    }
});

function autoRegister(){
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = JSON.parse(authorize_result);
    if(authorizeResult){
        sipLocalCfg(authorizeResult.site_info[0].access_server[0].sip_uri,
                    sessionStorage.getItem("local_ip"),
                    5060);
        sipRegister(authorizeResult.sip_impi, 
                    authorizeResult.sip_impi,  
                    authorizeResult.sip_password,
                    authorizeResult.password_type,     
                    {onRegStatusUpdate: registerState, onForceUnReg: forceUnregInfo});
    }

}

function displaySipNum(){
    var authorize_result = sessionStorage.authorize_result;
    var authorizeResult = JSON.parse(authorize_result);
    $('#sipNumDisplay').val("[+" + parseInt(authorizeResult.sip_impi) + "]");
}

//This function is used to register a callback event
function uiregisterCallbcak(){
    registerCallbcak({onCallIncoming: incoming,
                    onCallRingBack : ringback,
                    onCallConnected : connected,
                    onCallEnded : ended,
                    onCallDestroy : destroy,
                    onCallAddVideo: uiOnAddVideo,
                    onCallDelVideo: uiOnDelVideo,
                    onCallModifyVideoResult: uiModifyVideo,
                    onSpkDevVolumeChange: spkVolChange,
                    onMicDevVolumeChange: micVolChange,
                    onSessionModified: sessionModified
    });
}

//This method is used to set sip basic init configure
function uiSipLocalCfg(){
   var localCfgStorage = {sipSvrAddr: $('#sip_svr_addr').val(),
                         localIpv4: $('#local_ipv4').val(),  
                         localSipPort: Number($('#local_sip_port').val())
    }
    localStorage.localCfg = JSON.stringify(localCfgStorage);

    sipLocalCfg($('#sip_svr_addr').val(),
                $('#local_ipv4').val(),
                Number($('#local_sip_port').val()));
}

function loadLoaclCfg(){
    if(localStorage.localCfg){
        var localCfg = JSON.parse(localStorage.localCfg);
        $('#sip_svr_addr').val(localCfg.sipSvrAddr);
        $('#local_ipv4').val(localCfg.localIpv4);
        Number($('#local_sip_port').val(localCfg.localSipPort));
    }
}

//This method is used to set IPT service
function uiSetIPTService(type){
    if (type==25 || type ==26){
        uniteSetIPTService(type, $('#forwardNumber3').val());
    } else if (type==29 || type ==30){
        uniteSetIPTService(type, $('#forwardNumber4').val());
    } else if (type==27 || type ==28){
        uniteSetIPTService(type, $('#forwardNumber5').val());
    } else if (type==31 || type ==32){
        uniteSetIPTService(type, $('#forwardNumber6').val());
    } else {
        uniteSetIPTService(type, 0);
    }
}

var iptStorage = {};
function saveSet(){
    iptStorage = {ctdCallerNum: $('#ctdCallerNum').val(),
                    wait: $("input[name='callWait']:checked").attr('id'),
                    dnd: $("input[name='dnd']:checked").attr('id'),
                    uncondition: $("input[name='unconditionForward']:checked").attr('id'),
                    forwardNumber3: $('#forwardNumber3').val(),
                    noReply: $("input[name='noReplyForward']:checked").attr('id'),
                    forwardNumber4: $('#forwardNumber4').val(),
                    busy: $("input[name='busyForward']:checked").attr('id'),
                    forwardNumber5: $('#forwardNumber5').val(),
                    offLine: $("input[name='offLineForward']:checked").attr('id'),
                    forwardNumber6: $('#forwardNumber6').val()
    }
    localStorage.checked = JSON.stringify(iptStorage);
    alert("save successfully");
}
function loadStorage(){
    if(localStorage.checked){
        var idArray = JSON.parse(localStorage.checked);
        for(var i in idArray){
            if(isNaN(idArray[i])){
                $("#"+idArray[i]).attr("checked", true);
            }else{
                $("#"+i).val(idArray[i]);
            }
        }
    }
}

var pwdType = 0;
function uiRegister(){
   var accountStorage = {sipNumber: $('#sipNumber').val(),
                         sipName: $('#sipName').val(),  
                         sipPassword: $('#sipPassword').val()
    }
    localStorage.account = JSON.stringify(accountStorage); 
    sipRegister($('#sipNumber').val(), 
        $('#sipName').val(),  
        $('#sipPassword').val(),
        pwdType,     
        {onRegStatusUpdate: registerState, onForceUnReg: forceUnregInfo});
    loadStorage();  
}

function loadAccount(){
    if(localStorage.account){
        var account = JSON.parse(localStorage.account);
        $('#sipNumber').val(account.sipNumber); 
        $('#sipName').val(account.sipName);
        $('#sipPassword').val(account.sipPassword);
    }
}

function registerState(obj){
    if(obj.stateInfo == "registered"){
        $('#sipLoginPanel').hide();
        $('#callFullPanel').show();
        $('#sipNumDisplay').val("[" + obj.userNum + "]");
        sessionStorage.setItem("sipLogin","true");       
    }else if(obj.stateInfo == "deregistered"){
        sessionStorage.clear();
        uiDeRegister(); 
    }
}

function forceUnregInfo(){
    uiDeRegister();
}

function uiDeRegister(){
    sipDeRegister();
    sessionStorage.removeItem("sipLogin"); 
    $('#callFullPanel').hide();
    $('#sipLoginPanel').show();
    //when deregister acount, it will turn to login page, and at this time web will be refresh for next time login
    window.location.reload();
}
//This function is used to open the video window
function callSetAllVideoView(){
    $('#myCanvas').show();
    var localView = $('#localCanvas')[0];
    var remoteView = $('#remoteCanvas')[0];
    var dataView = $('#dataCanvas')[0];
    setAllVideoView(localView, remoteView, dataView);
    $('#addVideo').hide();
    $('#delVideo').show();
}
//This function is used to close the video window
function closeVideoView(){
    $('#localCanvas')[0].width = 0;
    $('#remoteCanvas')[0].width = 0;
    $('#dataCanvas')[0].width = 0;
    $('#localCanvas')[0].height = 0;
    $('#remoteCanvas')[0].height = 0;
    $('#dataCanvas')[0].height = 0;
    $('#myCanvas').hide();
    $('#addVideo').show();
    $('#delVideo').hide(); 
}
//This function is used to initiate an audio call
function uiStartCall(){
    startCall($('#callee_num').val(), 0);
    $('#calling_num').val($('#callee_num').val());  
}
//This function is used to initiate a video call
function uiVideoCall(){
    startCall($('#callee_num').val(), 1);
    $('#calling_num').val($('#callee_num').val());  
    callSetAllVideoView();
}

function ringback(){
    $('#callState').val("");
    $('#callState').val("ring back");
}

function incoming(obj){
    $('#caller_num').val(obj.callerNum);
    sessionStorage.setItem("callerNum", obj.callerNum);
    $('#callPanel').hide();
    $('#callingPanel').hide();
    $('#incomingPanel').show();   
    if(obj.callType == 1){
        $('#toAudio').show();
        callSetAllVideoView();
    }    
}

//This function is used to answer incoming calls
function uiAcceptCall(){
    acceptCall();
    var callerNum = $('#caller_num').val();     
    $('#calling_num').val(callerNum);
}

var callIdUsedForConf = 0;
var telNumForConf = 0;
function connected(data){
    timing();
    $('#timing').show();
    $('#callState').val("");
    $('#callState').val("call connected");
    sessionStorage.setItem("lock","locked");

    callIdUsedForConf = data.param.call_id;
    telNumForConf = data.param.tel_num;
    sessionStorage.setItem("telNum",telNumForConf);
}

//This function is used for point-to-point calls
function uiP2pTransferToConf(){
    var attendeeList = new Array();
    attendeeList[0]={number:$('#sipNumDisplay').val()+"", name:"", email:"", sms:"", is_mute:0, role:1, type:0, is_auto_invite:0};
    attendeeList[1]={number:telNumForConf, name:"", email:"", sms:"", is_mute:0, role:0, type:0, is_auto_invite:0};
    var confInfo={subject:"", group_uri:"", welcome_voice_enable:0, enter_prompt:0, leave_prompt:0, conf_filter:0, record_flag:0, multi_stream_flag:0, 
                    media_type:1, language:0, conf_encrypt_mode:0,user_type:0, num_of_attendee:2, attendee:attendeeList}
    p2pTransferToConf(confInfo, callIdUsedForConf);
}

//This function is used to end the call
function uiEndCall(){
    endCall();
    closeVideoView();
}

function ended(reason){
    $('#callState').val("");  
    $('#callState').val("call ended");
    $('#callPanel').show();
    $('#callingPanel').hide();
    $('#incomingPanel').hide();
    $('#timing').hide();
    closeVideoView();
    stopPlayMediaFile();
    sessionStorage.removeItem("telNum");
    sessionStorage.removeItem("callerNum");
    sessionStorage.removeItem("lock");
}

function destroy(){
    $('#caller_num').val("");
    $('#callState').val("");
    closeVideoView();
    endCallTimer();    
}

function uiMuteMic(){
    muteMic();
}

function uiunMuteMic(){
    unMuteMic();
}

function uiAddVideo(){
    callSetAllVideoView();
    addVideo();
}

function uiOnAddVideo(){
    callSetAllVideoView();
    $('#isAcceptVideo').show();
}

function uiReplyAddVideo(isAccept){
    if(isAccept){
        replyAddVideo(true);
    } else {
        replyAddVideo(false);
        closeVideoView(); 
    }
     $('#isAcceptVideo').hide();
}

function uiModifyVideo(isAccept){
    if(!isAccept){
        closeVideoView(); 
    }
}

function uiDelVideo(){
    delVideo();
    closeVideoView();
}

function uiOnDelVideo(){
    closeVideoView();
}
//This function is used to pause the video
// function uiMuteVideo(isOn){
//     if(isOn){
//         mediaMuteVideo(true);
//         $('#stopVideo').hide();
//         $('#resumeVideo').show();
//     } else {
//         mediaMuteVideo(false);
//         $('#stopVideo').show();
//         $('#resumeVideo').hide();
//     }
// }

function uiSetCaptureFile(){
    setCaptureFile("../../../bin/img/call/flower.bmp");
}

//This function is used to control the camera. Can be opened, closed, paused, and continued
function uiVideoControl(isOn){
    if(isOn){
        videoControl(8);
        $('#stopVideo').hide();
        $('#resumeVideo').show();
    } else {
        videoControl(4);
        $('#stopVideo').show();
        $('#resumeVideo').hide();
    }    
}

function uiHoldCall(){
    holdCall({onCallHoldSuccess: holdSuccess, onCallHoldFailed: holdFailed});
}

function uiUnholdCall(){
    unholdCall({onCallUnHoldSuccess: unHoldSuccess, onCallUnHoldFailed: unHoldFailed});
}

function holdSuccess(){
    $('#callState').val("");      
    $('#callState').val("holding call");
    $('#holdCall').hide();
    $('#unholdCall').show();
    $('#timing').hide();
    $('#holding').show();    
}

function holdFailed(){
    $('#callState').val("");
    $('#callState').val("hold call failed");
}

function unHoldSuccess(){
    $('#callState').val("");
    $('#callState').val("call connected");
    $('#unholdCall').hide();
    $('#holdCall').show();
    $('#timing').show();
    $('#holding').hide();
}

function unHoldFailed(){
    $('#callState').val("unhold failed");
}

function uiDivertCall() {
    var divertNumber = $('#transto_number').val();
    divertCall(divertNumber, {onCallDivertFailed: divertFailed});
}


function divertFailed(){
    $('#callState').val("");
    $('#callState').val("divert failed");
}

function uiBlindTransfer() {
    var transtoNumber = $('#transto_number').val();
    blindTransfer(transtoNumber);
}

function uiGetMicVol(){
    getMicVol({getMicVolResponse: micVolRes});
}

function micVolRes(volume){
     $('#micVol').val(volume);
}

function micVolChange(volume){
    $('#micVol').val(volume);  
}

function uiSetMicVol(){
    setMicVol($('#micVol').val());
}

function uiGetSpkVol(){
    getSpkVol({getSpkVolResponse: spkVolRes});
}

function spkVolRes(volume){
    $('#spkVol').val(volume);
}

function spkVolChange(volume){
    $('#spkVol').val(volume);  
}

function uiSetSpkVol(){
    setSpkVol($('#spkVol').val());  
} 

function uiGetMicIndex(){
    getMicIndex({getMicIndexResponse: micIndexResponse});
}

function micIndexResponse(micIndex){
    $('#micIndex').val(micIndex);
}

function uiSetMicIndex(){
    setMicIndex($('#micIndex').val());
}

function uiGetMediaDevices(type){
    getMediaDevices(type);
}

function uiGetSpkIndex(){
    getSpkIndex({getSpkIndexResponse: spkIndexResponse});
}

function spkIndexResponse(spkIndex){
    $('#spkIndex').val(spkIndex);
}

function uiSetSpkIndex(){
    setSpkIndex($('#spkIndex').val());
}

function uiGetVideoIndex(){
    getVideoIndex({getVideoIndexResponse: videoIndexResponse});
}

function videoIndexResponse(videoIndex){
    $('#videoIndex').val(videoIndex);
}

function uiSetVideoIndex(){
    setVideoIndex($('#videoIndex').val());
}


function uiStartPreview(){
    startPreview($('#videoIndex').val());
    callSetAllVideoView();
}

function uiStopPreview(){
    stopPreview();
    closeVideoView();
}

function sessionModified(data){
    if(data.param.is_focus){
$("#callPageToConfPage").click();
    }
}

function timer(){
    initTimer($("#timeInterval").val());
}

function uiGetChannelInfo(){
    getChannelInfo({getChannelInfoResponse: channelInfoResponse});
}

function channelInfoResponse(msg){
    $("#uiCt").val (msg.param.uiCt);
    $("#szAudioCodec").val (msg.param.szAudioCodec);
    $("#szVideoCodec").val (msg.param.szVideoCodec);
    //audio
    $("#bIsCalling").val (msg.param.bIsCalling);
    $("#bIsSRTP_a").val (msg.param.bIsSRTP_a);
    $("#acEncodeProtocol").val (msg.param.acEncodeProtocol);
    $("#acDecodeProtocol").val (msg.param.acDecodeProtocol);
    $("#ulChannelID").val (msg.param.ulChannelID);
    $("#ulSendBitRate").val (msg.param.ulSendBitRate);
    $("#ulRecvBitRate").val (msg.param.ulRecvBitRate);
    $("#ulSendTotalLostPacket").val (msg.param.ulSendTotalLostPacket);
    $("#fSendLossFraction").val (msg.param.fSendLossFraction);
    $("#fSendNetLossFraction").val (msg.param.fSendNetLossFraction);
    $("#fSendJitter").val (msg.param.fSendJitter);
    $("#fSendDelay").val (msg.param.fSendDelay);
    $("#ulRecvTotalLostPacket").val (msg.param.ulRecvTotalLostPacket);
    $("#fRecvLossFraction").val (msg.param.fRecvLossFraction);
    $("#fRecvNetLossFraction").val (msg.param.fRecvNetLossFraction);
    $("#fRecvJitter").val (msg.param.fRecvJitter);
    $("#fRecvDelay").val (msg.param.fRecvDelay);
    $("#ucSendMOSValidFlag").val (msg.param.ucSendMOSValidFlag);
    $("#ucRecvMOSValidFlag").val (msg.param.ucRecvMOSValidFlag);
    $("#fSendAverageMosQ").val (msg.param.fSendAverageMosQ);
    $("#fSendMaxMosQ").val (msg.param.fSendMaxMosQ);
    $("#fSendMinMosQ").val (msg.param.fSendMinMosQ);
    $("#fSendCurMosQ").val (msg.param.fSendCurMosQ);
    $("#fRecvAverageMosQ").val (msg.param.fRecvAverageMosQ);
    $("#fRecvMaxMosQ").val (msg.param.fRecvMaxMosQ);
    $("#fRecvMinMosQ").val (msg.param.fRecvMinMosQ);
    $("#fRecvCurMosQ").val (msg.param.fRecvCurMosQ);
    //video
    $("#acEncodeName").val (msg.param.acEncodeName);
    $("#acDecodeName").val (msg.param.acDecodeName);
    $("#acEncoderSize").val (msg.param.acEncoderSize);
    $("#acDecoderSize").val (msg.param.acDecoderSize);
    $("#bIsSRTP_v").val (msg.param.bIsSRTP_v);
    $("#ulSendFrameRate").val (msg.param.ulSendFrameRate);
    $("#ulRecvFrameRate").val (msg.param.ulRecvFrameRate);
    $("#ulVideoSendBitRate").val (msg.param.ulVideoSendBitRate);
    $("#ulVideoRecvBitRate").val (msg.param.ulVideoRecvBitRate);
    $("#acEncoderProfile").val (msg.param.acEncoderProfile);
    $("#acDecoderProfile").val (msg.param.acDecoderProfile);
    $("#fVideoSendLossFraction").val (msg.param.fVideoSendLossFraction);
    $("#fVideoSendJitter").val (msg.param.fVideoSendJitter);
    $("#fVideoSendDelay").val (msg.param.fVideoSendDelay);
    $("#fVideoRecvLossFraction").val (msg.param.fVideoRecvLossFraction);
    $("#fVideoRecvJitter").val (msg.param.fVideoRecvJitter);
    $("#fVideoRecvDelay").val (msg.param.fVideoRecvDelay);
    $("#ulWidth").val (msg.param.ulWidth);
    $("#ulHeight").val (msg.param.ulHeight);
    //data
    $("#acEncodeName_fl").val (msg.param.acEncodeName_fl);
    $("#acDecodeName_fl").val (msg.param.acDecodeName_fl);
    $("#acEncoderSize_fl").val (msg.param.acEncoderSize_fl);
    $("#acDecoderSize_fl").val (msg.param.acDecoderSize_fl);
    $("#bIsSRTP_v_fl").val (msg.param.bIsSRTP_v_fl);
    $("#ulSendFrameRate_fl").val (msg.param.ulSendFrameRate_fl);
    $("#ulRecvFrameRate_fl").val (msg.param.ulRecvFrameRate_fl);
    $("#ulVideoSendBitRate_fl").val (msg.param.ulVideoSendBitRate_fl);
    $("#ulVideoRecvBitRate_fl").val (msg.param.ulVideoRecvBitRate_fl);
    $("#acEncoderProfile_fl").val (msg.param.acEncoderProfile_fl);
    $("#acDecoderProfile_fl").val (msg.param.acDecoderProfile_fl);
    $("#fVideoSendLossFraction_fl").val (msg.param.fVideoSendLossFraction_fl);
    $("#fVideoSendJitter_fl").val (msg.param.fVideoSendJitter_fl);
    $("#fVideoSendDelay_fl").val (msg.param.fVideoSendDelay_fl);
    $("#fVideoRecvLossFraction_fl").val (msg.param.fVideoRecvLossFraction_fl);
    $("#fVideoRecvJitter_fl").val (msg.param.fVideoRecvJitter_fl);
    $("#fVideoRecvDelay_fl").val (msg.param.fVideoRecvDelay_fl);
    $("#ulWidth_fl").val (msg.param.ulWidth_fl);
    $("#ulHeight_fl").val (msg.param.ulHeight_fl);
    //other
    $("#bIsIn").val (msg.param.bIsIn);
    $("#bIsEndCall").val (msg.param.bIsEndCall);
    $("#acLocalIP").val (msg.param.acLocalIP);
    $("#acRemoteNum").val (msg.param.acRemoteNum);
    $("#acLocalNum").val (msg.param.acLocalNum);

}

//This function is used to input dtmf.
function dtmfInputNum(e){
    var obj = e.target || e.srcElement;
    if(obj.nodeName != "INPUT"){
        return;
    }
    var value = obj.value;
    var dialNumber = $("#dtmfNum").val();
    if(value){
        $("#dtmfNum").val(dialNumber+value);
    }
}

function transInputNum(e){
    var obj = e.target || e.srcElement;
    if(obj.nodeName != "INPUT"){
        return;
    }
    var value = obj.value;
    var calleeNum = $("#transto_number").val();
    var sub = calleeNum.substr(0,calleeNum.length-1);
    if(value=="<-"){
        $("#transto_number").val(sub);
    } else {
        $("#transto_number").val(calleeNum+value);
    }
}

//This function is used to calculate the duration of the call
var mytimer = 0;
var str = "";
function timing(){
    var HH = 0;
    var mm = 0;
    var ss = 0;
    mytimer = setInterval(function(){
        str = "";
        if(++ss==60)
        {
            if(++mm==60)
            {
                HH++;
                mm=0;
            }
            ss=0;
        }
        str+=HH<10?"0"+HH:HH;
        str+=":";
        str+=mm<10?"0"+mm:mm;
        str+=":";
        str+=ss<10?"0"+ss:ss;
        if($("#timing").html() != null){
            $("#timing").html(str);
        }
    },1000);
};

//This function is used to clear the call duration
function endCallTimer() {
    str = "";
    clearInterval(mytimer);
}

function inputNum(e){
    var obj = e.target || e.srcElement;
    if(obj.nodeName != "INPUT"){
    return;
    }
    var value = obj.value;
    var calleeNum = $("#callee_num").val();
    var sub = calleeNum.substr(0,calleeNum.length-1);
    if(value==" <= "){
        $("#callee_num").val(sub);
    } else {
        $("#callee_num").val(calleeNum+value);
    }
}









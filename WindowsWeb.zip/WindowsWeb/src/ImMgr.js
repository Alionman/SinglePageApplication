var imNotifyFuncs = new Array();

var tupIm = new TUPIm({
    ready: onImReady,
    close: onImClose
});

function imUninit() {
    tupIm.uninit({
        response: function(data) {
            var d = data;
        }
    });
}

var tupOfflinefile = new TUPOfflinefile({
    ready: onOfflinefileReady,
    close: onOfflinefileClose
});

function onImReady() {
    tupIm.init();
}

function onImClose() {

}

function onOfflinefileReady() {

}

function onOfflinefileClose() {

}
function setBasicImEvent(callbacks){
    if (callbacks && typeof callbacks.onAddFriend == "function") {
        imNotifyFuncs[100] = callbacks.onAddFriend;
    }
    if (callbacks && typeof callbacks.onUserStatusList == "function") {
        imNotifyFuncs[101] = callbacks.onUserStatusList;
    }
    if (callbacks && typeof callbacks.onSendImInput == "function") {
        imNotifyFuncs[102] = callbacks.onSendImInput;
    }
    if (callbacks && typeof callbacks.onCodeChat == "function") {
        imNotifyFuncs[103] = callbacks.onCodeChat;
    }
    if (callbacks && typeof callbacks.onChatList == "function") {
        imNotifyFuncs[104] = callbacks.onChatList;
    } 

    tupIm.setBasicImEvent({
        onKickOut: function(data) {},
        onMultiDevice: function(data) {},
        onGeneral: function(data) {},
        onAddFriend: function(data) {
            imNotifyFuncs[100](data);
        },
        onUserStatusList: function(data) {
            imNotifyFuncs[101](data);
        },
        onUserInfoChange: function(data) {},
        onSendImInput: function(data) {
            imNotifyFuncs[102](data)
        },
        onCodeChat: function(data) {
            imNotifyFuncs[103](data);
        },
        onChatList: function(data) {
            imNotifyFuncs[104](data);
        },
        onUnDeliver: function(data) {},
        onMsgRead: function(data) {}
    });
}

function setGroupImEvent(callbacks){
    if (callbacks && typeof callbacks.onApplyJoinFixedGroupResult == "function") {
        imNotifyFuncs[105] = callbacks.onApplyJoinFixedGroupResult;
    }
    if (callbacks && typeof callbacks.onReceiveInviteToFixedGroup == "function") {
        imNotifyFuncs[106] = callbacks.onReceiveInviteToFixedGroup;
    }
    if (callbacks && typeof callbacks.onReceiveInviteJoinFixedGroup == "function") {
        imNotifyFuncs[107] = callbacks.onReceiveInviteJoinFixedGroup;
    }
    if (callbacks && typeof callbacks.onFixedGroupDismiss == "function") {
        imNotifyFuncs[108] = callbacks.onFixedGroupDismiss;
    }
    tupIm.setGroupImEvent({
        onApplyJoinFixedGroupResult: function(data) {
            imNotifyFuncs[105](data);
        },
        onFixedGroupMemberAdd: function(data) {},
        onFixedGroupMemberDel: function(data) {},
        onFixedGroupInfoChg: function(data) {},
        onFixedGroupOwnerChg: function(data) {},
        onReceiveInviteToFixedGroup: function(data) {
            imNotifyFuncs[106](data);
        },
        onReceiveInviteJoinFixedGroup: function(data) {
            imNotifyFuncs[107](data);
        },
        onFixedGroupWasAddedToGroup: function(data) {},
        onFixedGroupDismiss: function(data) {
           imNotifyFuncs[108](data); 
        },
        onFixedGroupOwnerInviteResult: function(data) {},
        onDiscussGroupAddMember: function(data) {},
        onDiscussGroupDelMember: function(data) {},
        onDiscussGroupMemListAddMember: function(data) {},
        onDiscussGroupMemListDelMember: function(data) {},
        onDiscussGroupInfoChange: function(data) {},
        onDiscussGroupWasAddToGroup: function(data) {},
        onDiscussGroupOwnerChange: function(data) {
            alert("onDiscussGroupOwnerChange");
        },
        onDiscussGroupDismiss: function(data) {},
        onDiscussGroupOp: function(data) {},
        onGroupFile: function(data) {}
    });
}


//This function is used to IM login.
function imLogin() {
    if (sessionStorage.authorize_result) {
        var authorize_result = JSON.parse(sessionStorage.authorize_result);
        /*get server address and port*/
        var serverInfo = authorize_result.site_info[0].access_server[0].eserver_uri.split(":");
        var serverAddr = serverInfo[0];
        var port = Number(serverInfo[1]);
        var token = authorize_result.auth_token;

        imSetserveraddress(serverAddr, port);

        tupIm.tupImBase64Decode(token, {
            response: function(data) {
                //var account = authorize_result.
                var account = JSON.parse(localStorage.loginAccountInfo).AccountVal;
                var password = "";
                var version = "v3.0.5.2";
                var loginType = 4;
                /*after decode token*/
                var token = data.param.ack;
                sessionStorage.tupImBase64DecodeToken = token;

                IMLogin(account, password, version, loginType, token);
            }
        });
    }
}

/*This function is used to  IM login out*/
function imLoginout() {
    tupIm.logout({
        onLogout: function(data) {
            //after logout todo 
        }
    });
}

function imNormalLogin(account, password, normalServerAddr, normalPort, callbacks) {
    var version = "v3.0.5.2";
    var loginType = 1;
    var token = "";

    imSetserveraddress(normalServerAddr, normalPort);
    IMLogin(account, password, version, loginType, token, callbacks);
}

function imSetserveraddress(serverAddr, port) {
    tupIm.setServerAddress(serverAddr, port);
}

//This function is used to  IM upotal login.
function IMLogin(account, password, version, loginType, token, callbacks) {
    if (callbacks && typeof callbacks.imLoginResult == "function") {
        imNotifyFuncs[0] = callbacks.imLoginResult;
    }

    var Token = token || "";

    var param = {
        "account": account,
        "password": password,
        "version": version,
        "auth_type": loginType, //1:normal;2:fingerprint;3:ticket;4:token
        "language": "zh-cn",
        "client_desc": "pc",
        "ticket": "123-523",
        "token": Token
    };
    tupIm.login(param, {
        response: onImLoginResult
    });

    imGetServiceProfile();
};

function onImLoginResult(data) {
    if (typeof imNotifyFuncs[0] == "function") {
        imNotifyFuncs[0](data);
    }
    if (data.result == 0) {
        sessionStorage.LoginPageShow = false;
    }
}

//This function is used to  get service profile.
function imGetServiceProfile() {
    var param = {
            "time_stamp": "19000000000000",
            "is_vpn_access": 0,
            "local_ip": "10.46.15.226",
            "is_sync_all": 0,
            "need_icon": 0
        }
        /*get server business config info*/
    tupIm.getServiceProfile(param, {
        response: onImGetserviceprofileResult
    });
}

//This is callback of getting serviceprofile
var um_server_http_list = null;
var um_server_https_list = null;

function onImGetserviceprofileResult(data) {
    um_server_http_list = data.param.um_server_http_list[0].um_server_addr;
    um_server_https_list = data.param.um_server_https_list[0].um_server_addr;
    sessionStorage.um_server_http_list = um_server_http_list;
    sessionStorage.um_server_https_list = um_server_https_list;
}

//This function is used to  get service profile.
function imGetUserInfo(account, callbacks) {
    if (callbacks && typeof callbacks.omImGetUserInfo == "function") {
        imNotifyFuncs[1] = callbacks.omImGetUserInfo;
    }

    var param = {
        "account": account,
        "staff_id": 1
    };
    tupIm.getUserInfo(param, {
        response: omImGetUserInfo
    });
}

//This is callback of getting serviceprofile
function omImGetUserInfo(data) {
    if (typeof imNotifyFuncs[1] == "function") {
        imNotifyFuncs[1](data);
    }
}

//This function is used to set system image.
function imSetsystemimage(imgNum, callbacks) {
    if (callbacks && typeof callbacks.onImSetSystemImage == "function") {
        imNotifyFuncs[2] = callbacks.onImSetSystemImage;
    }

    tupIm.setSystemImage(imgNum, {
        response: onImSetSystemImage
    });
}
//This is callback of setting system image.
function onImSetSystemImage(data) {
    if (typeof imNotifyFuncs[2] == "function") {
        imNotifyFuncs[2](data);
    }
}

//This function is used to set self define image.
function imSetSelfDefineImage(param, callbacks) {
    if (callbacks && typeof callbacks.onImSetSelfDefineImage == "function") {
        imNotifyFuncs[5] = callbacks.onImSetSelfDefineImage;
    }

    tupIm.setSelfDefineImage(param, {
        response: onImSetSelfDefineImage
    });
}

//This is callback of setting self define image.
function onImSetSelfDefineImage(data) {
    if (typeof imNotifyFuncs[5] == "function") {
        imNotifyFuncs[5](data);
    }
}

//This function is used to get self define image.
function imGetUserDefineImage(param, callbacks) {
    if (callbacks && typeof callbacks.onGetUserDefineImage == "function") {
        imNotifyFuncs[6] = callbacks.onGetUserDefineImage;
    }
    tupIm.getUserDefineImage(param, {
        response: onGetUserDefineImage
    })
}

//This is callback of getting self define image.
function onGetUserDefineImage(data) {
    if (typeof imNotifyFuncs[6] == "function") {
        imNotifyFuncs[6](data);
    }
}

//This function is used to set user info.
function imSetUserInfo(UserInfoParam, callbacks) {
    if (callbacks && typeof callbacks.onUserInfoChange == "function") {
        imNotifyFuncs[3] = callbacks.onUserInfoChange;
    }

    tupIm.setUserInfo(UserInfoParam, {
        response: onImSetUserInfo
    });
}

//This is callback of setting user info.
function onImSetUserInfo(data) {
    if (typeof imNotifyFuncs[3] == "function") {
        imNotifyFuncs[3](data);
    }
}

//This function is used to get contact list.
function imGetContactList(param, callbacks) {
    if (callbacks && typeof callbacks.onGetContactList == "function") {
        imNotifyFuncs[4] = callbacks.onGetContactList;
    }

    tupIm.getContactList(param, {
        response: onImGetContactList
    });
}

//This is callback of getting contact list.
function onImGetContactList(data) {
    if (typeof imNotifyFuncs[4] == "function") {
        imNotifyFuncs[4](data);
    }
}

//This function is used to query address book.
function imQueryentAddressBook(param, callbacks) {
    if (callbacks && typeof callbacks.onQueryentAddressBook == "function") {
        imNotifyFuncs[7] = callbacks.onQueryentAddressBook;
    }
    tupIm.queryEntaddressBook(param, {
        response: onImQueryentAddressBook
    });
}

//This is callback of query address book.
function onImQueryentAddressBook(data) {
    if (typeof imNotifyFuncs[7] == "function") {
        imNotifyFuncs[7](data);
    }
}

//This function is used to query user info.
function imQueryUserInfo(param, callbacks) {
    if (callbacks && typeof callbacks.onQueryUserInfo == "function") {
        imNotifyFuncs[8] = callbacks.onQueryUserInfo;
    }
    tupIm.queryUserInfo(param, {
        response: omImQueryUserInfo
    });
}

//This is callback of get user info.
function omImQueryUserInfo(data) {
    if (typeof imNotifyFuncs[8] == "function") {
        imNotifyFuncs[8](data);
    }
}

//This function is used to add friend.
function imAddFriend(param, callbacks) {
    if (callbacks && typeof callbacks.onAddFriend == "function") {
        imNotifyFuncs[9] = callbacks.onAddFriend;
    }

    tupIm.addFriend(param, {
        response: onImAddFriend //onAddFriend
    });
}

//This is callback of adding friend.
function onImAddFriend(data) {
    if (typeof imNotifyFuncs[9] == "function") {
        imNotifyFuncs[9](data);
    }
}

//This function is used to delete friend or contact.
function imDelFriendOrContact(param, callbacks) {
    if (callbacks && typeof callbacks.onDelFriendOrContact == "function") {
        imNotifyFuncs[10] = callbacks.onDelFriendOrContact;
    }

    tupIm.delFriendOrContact(param, {
        response: onImDelFriendOrContact
    });
};

//This is callback of delete friend or contact.
function onImDelFriendOrContact(data) {
    if (typeof imNotifyFuncs[10] == "function") {
        imNotifyFuncs[10](data);
    }
}

//This function is used to subscribe user status.
function imSubscribeUserStatus(param, callbacks) {
    if (callbacks && typeof callbacks.onSubscribeUserStatusResponse == "function") {
        imNotifyFuncs[11] = callbacks.onSubscribeUserStatusResponse;
    }

    tupIm.subscribeUserStatus(param, {
        response: onImSubscribeUserStatusResponse
    });
}

//This is callback of subscribe user status.
function onImSubscribeUserStatusResponse(data) {
    if (typeof imNotifyFuncs[11] == "function") {
        imNotifyFuncs[11](data);
    }
}

//This function is used to unsubscribe user status.
function imUnSubscribeUserStatus(param, callbacks) {
    if (callbacks && typeof callbacks.onUnSubscribeUserStatus == "function") {
        imNotifyFuncs[13] = callbacks.onUnSubscribeUserStatus;
    }

    tupIm.unSubscribeUserStatus(param, {
        response: onImUnSubscribeUserStatus
    });
}

//This is callback of unsubscribe user status.
function onImUnSubscribeUserStatus(data) {
    if (typeof imNotifyFuncs[13] == "function") {
        imNotifyFuncs[13](data);
    }
}

//This function is used to detect user status.
function imDetectUserStatus(param, callbacks) {
    if (callbacks && typeof callbacks.onDetectUserStatusResponse == "function") {
        imNotifyFuncs[14] = callbacks.onDetectUserStatusResponse;
    }

    tupIm.detectUserStatus(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[14] == "function") {
                imNotifyFuncs[14](data);
            }
        }
    });
}

//This function is used to add user group.
function imAddUserGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onAddUserGroup == "function") {
        imNotifyFuncs[16] = callbacks.onAddUserGroup;
    }

    tupIm.addUserGroup(param, {
        response: onImAddUserGroup
    });
}

//This is callback of adding user and group.
function onImAddUserGroup(data) {
    if (typeof imNotifyFuncs[16] == "function") {
        imNotifyFuncs[16](data);
    }
}

//This function is used to delete user and group.
function imDelUserGroup(id, callbacks) {
    if (callbacks && typeof callbacks.onDelUserGroup == "function") {
        imNotifyFuncs[17] = callbacks.onDelUserGroup;
    }

    tupIm.delUserGroup({
        "id": id
    }, {
        response: onImDelUserGroup
    });
};

//This is callback of deleting user and group.
function onImDelUserGroup(data) {
    if (typeof imNotifyFuncs[17] == "function") {
        imNotifyFuncs[17](data);
    }
}

//This function is used to modify user and group.
function imModUserGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onModUserGroup == "function") {
        imNotifyFuncs[18] = callbacks.onModUserGroup;
    }

    tupIm.modUserGroup(param, {
        response: onImModUserGroup
    });
}

//This is callback of modifiing user and group.
function onImModUserGroup(data) {
    if (typeof imNotifyFuncs[18] == "function") {
        imNotifyFuncs[18](data);
    }
}

//This function is used to update user and group.
function imUpdateUserGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onUpdateUserGroup == "function") {
        imNotifyFuncs[19] = callbacks.onUpdateUserGroup;
    }

    tupIm.updateUsergroup(param, {
        response: onImUpdateUserGroup
    });
}

//This is callback of updating user and group.
function onImUpdateUserGroup(data) {
    if (typeof imNotifyFuncs[19] == "function") {
        imNotifyFuncs[19](data);
    }
}

//This function is used to publish status.
function imPublishStatus(param, callbacks) {
    if (callbacks && typeof callbacks.onPublishStatus == "function") {
        imNotifyFuncs[20] = callbacks.onPublishStatus;
    }

    tupIm.publishStatus(param, {
        response: onImPublishStatus
    });
}

//This is callback of publish status.
function onImPublishStatus(data) {
    if (typeof imNotifyFuncs[20] == "function") {
        imNotifyFuncs[20](data);
    }
}

//This function is used to send im.
function imSendIm(param, callbacks) {
    if (callbacks && typeof callbacks.onSendImResponse == "function") {
        imNotifyFuncs[21] = callbacks.onSendImResponse;
    }
    if (callbacks && typeof callbacks.onMsgSendAck == "function") {
        imNotifyFuncs[22] = callbacks.onMsgSendAck;
    }
    tupIm.sendIm(param, {
        response: onImSendImResponse,
        onMsgSendAck: onMsgSendAck
    });
};

//This is callback of send im result.
function onImSendImResponse(data) {
    if (typeof imNotifyFuncs[21] == "function") {
        imNotifyFuncs[21](data);
    }
}

//This is callback of send im.
function onMsgSendAck(data) {
    if (typeof imNotifyFuncs[22] == "function") {
        imNotifyFuncs[22](data);
    }
}

//This function is used to query history message.
function imQueryHistoryMessage(param, callbacks) {
    if (callbacks && typeof callbacks.onQueryHistoryMessage == "function") {
        imNotifyFuncs[23] = callbacks.onQueryHistoryMessage;
    }

    tupIm.queryHistoryMessage(param, {
        response: onImQueryHistoryMessage
    });
};

//This is callback of send im.
function onImQueryHistoryMessage(data) {
    if (typeof imNotifyFuncs[23] == "function") {
        imNotifyFuncs[23](data);
    }
}

//This function is used to send input status.
function imNotifyImInputting(param, callbacks) {
    if (callbacks && typeof callbacks.onNotifyImInputtingResponse == "function") {
        imNotifyFuncs[24] = callbacks.onNotifyImInputtingResponse;
    }
    if (callbacks && typeof callbacks.onNotifyInputting == "function") {
        imNotifyFuncs[25] = callbacks.onNotifyInputting;
    }

    tupIm.notifyImInputting(param, {
        response: onImNotifyImInputtingResponse,
        onNotifyInputting: onNotifyInputting
    });
};

//This is callback of send input status.
function onImNotifyImInputtingResponse(data) {
    if (typeof imNotifyFuncs[24] == "function") {
        imNotifyFuncs[24](data);
    }
}

//This is callback of send input status.
function onNotifyInputting(data) {
    if (typeof imNotifyFuncs[25] == "function") {
        imNotifyFuncs[25](data);
    }
}

//This function is used to add contact.
function imAddContact(param, callbacks) {
    if (callbacks && typeof callbacks.onAddContact == "function") {
        imNotifyFuncs[26] = callbacks.onAddContact;
    }

    tupIm.addContact(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[26] == "function") {
                imNotifyFuncs[26](data);
            }
        }
    });
}

//This function is used to modify contact.
function imModContact(param, callbacks) {
    if (callbacks && typeof callbacks.onModContact == "function") {
        imNotifyFuncs[27] = callbacks.onModContact;
    }

    tupIm.modContact(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[27] == "function") {
                imNotifyFuncs[27](data);
            }
        }
    });
};

//This function is used to add fixed group.
function imAddFixedGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onAddFixedGroup == "function") {
        imNotifyFuncs[28] = callbacks.onAddFixedGroup;
    }

    tupIm.addFixedGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[28] == "function") {
                imNotifyFuncs[28](data);
            }
        }
    });
}

//This function is used to move contact to group.
function imMoveContactGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onMoveContactGroup == "function") {
        imNotifyFuncs[29] = callbacks.onMoveContactGroup;
    }

    tupIm.moveContactGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[29] == "function") {
                imNotifyFuncs[29](data);
            }
        }
    });
};

//This function is used to set read meessage.
function imSetMessageRead(param, callbacks) {
    if (callbacks && typeof callbacks.onSetMessageRead == "function") {
        imNotifyFuncs[30] = callbacks.onSetMessageRead;
    }

    tupIm.setMessageRead(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[30] == "function") {
                imNotifyFuncs[30](data);
            }
        }
    });
};

//This function is used to delete fixed group.
function imDelFixedGroup(id, callbacks) {
    if (callbacks && typeof callbacks.onDelFixedGroup == "function") {
        imNotifyFuncs[31] = callbacks.onDelFixedGroup;
    }

    tupIm.delFixedGroup(id, {
        response: function(data) {
            if (typeof imNotifyFuncs[31] == "function") {
                imNotifyFuncs[31](data);
            }
        }
    });
};

//This function is used to de;ete discussion group.
function imDelDiscussionGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onDelDiscussionGroup == "function") {
        imNotifyFuncs[32] = callbacks.onDelDiscussionGroup;
    }
    if (callbacks && typeof callbacks.onDiscussGroupDismiss == "function") {
        imNotifyFuncs[33] = callbacks.onDiscussGroupDismiss;
    }

    tupIm.delDiscussionGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[32] == "function") {
                imNotifyFuncs[32](data);
            }
        },
        onDiscussGroupDismiss: function(data) {
            if (typeof imNotifyFuncs[33] == "function") {
                imNotifyFuncs[33](data);
            }
        }
    });
};

//This function is used to modify fixed group info.
function imModFixedGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onModFixedGroup == "function") {
        imNotifyFuncs[34] = callbacks.onModFixedGroup;
    }
    if (callbacks && typeof callbacks.onFixedGroupInfChg == "function") {
        imNotifyFuncs[35] = callbacks.onFixedGroupInfChg;
    }

    tupIm.modFixedGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[34] == "function") {
                imNotifyFuncs[34](data);
            }
        },
        onFixedGroupInfChg: function(data) {
            if (typeof imNotifyFuncs[35] == "function") {
                imNotifyFuncs[35](data);
            }
        }
    });
};

//This function is used to modify discussion group info.
function imModDiscussionGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onModDiscussionGroup == "function") {
        imNotifyFuncs[36] = callbacks.onModDiscussionGroup;
    }
    if (callbacks && typeof callbacks.onDiscussGroupInfoChange == "function") {
        imNotifyFuncs[37] = callbacks.onDiscussGroupInfoChange;
    }

    tupIm.modDiscussionGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[36] == "function") {
                imNotifyFuncs[36](data);
            }
        },
        onDiscussGroupInfoChange: function(data) {
            if (typeof imNotifyFuncs[37] == "function") {
                imNotifyFuncs[37](data);
            }
        }
    });
};

//This function is used to get fixed group.
function imGetFixedGroups(param, callbacks) {
    if (callbacks && typeof callbacks.onGetFixedGroups == "function") {
        imNotifyFuncs[38] = callbacks.onGetFixedGroups;
    }

    tupIm.getFixedGroups(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[38] == "function") {
                imNotifyFuncs[38](data);
            }
        }
    });
};

//This function is used to get fixed group detail.
function imGetFixedGroupDetail(param, callbacks) {
    if (callbacks && typeof callbacks.onGetFixedGroupDetail == "function") {
        imNotifyFuncs[39] = callbacks.onGetFixedGroupDetail;
    }

    tupIm.getFixedGroupDetail(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[39] == "function") {
                imNotifyFuncs[39](data);
            }
        }
    });
};

//This function is used to get fixed group members.
function imGetFixedGroupMembers(param, callbacks) {
    if (callbacks && typeof callbacks.onGetFixedGroupMembers == "function") {
        imNotifyFuncs[40] = callbacks.onGetFixedGroupMembers;
    }

    tupIm.getFixedGroupMembers(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[40] == "function") {
                imNotifyFuncs[40](data);
            }
        }
    })
};

//This function is used to add fixed group member.
function imAddFixedGroupMember(param, callbacks) {
    if (callbacks && typeof callbacks.onAddFixedGroupMember == "function") {
        imNotifyFuncs[41] = callbacks.onAddFixedGroupMember;
    }

    tupIm.addFixedGroupMember(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[41] == "function") {
                imNotifyFuncs[41](data);
            }
        }
    });
};

//This function is used to add discussion group member.
function imAddDiscussionGroupMember(param, callbacks) {
    if (callbacks && typeof callbacks.onAddDiscussionGroupMember == "function") {
        imNotifyFuncs[42] = callbacks.onAddDiscussionGroupMember;
    }

    tupIm.addDiscussionGroupMember(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[42] == "function") {
                imNotifyFuncs[42](data);
            }
        }
    });
};

//This function is used to agree or reject administrator invitation.
function imConfirmFixedGroupInvite(param, callbacks) {
    console.log("+++++++++++++++++" + param.member_account);
    if (callbacks && typeof callbacks.onConfirmFixedGroupInvite == "function") {
        imNotifyFuncs[44] = callbacks.onConfirmFixedGroupInvite;
    }
    if (callbacks && typeof callbacks.onFixedGroupMemberAdd == "function") {
        imNotifyFuncs[45] = callbacks.onFixedGroupMemberAdd;
    }

    tupIm.confirmFixedGroupInvite(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[44] == "function") {
                imNotifyFuncs[44](data);
            }
        },
        onFixedGroupMemberAdd: function(data) {
            if (typeof imNotifyFuncs[45] == "function") {
                imNotifyFuncs[45](data);
            }
        }
    })
};

//This function is used to request to join fixed group.
function imJoinFixedGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onJoinFixedGroup == "function") {
        imNotifyFuncs[46] = callbacks.onJoinFixedGroup;
    }

    tupIm.joinFixedGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[46] == "function") {
                imNotifyFuncs[46](data);
            }
        }
    });
};

//This function is used to administrator approves the fixed group join.
function imConfirmFixedGroupApply(param, callbacks) {
    if (callbacks && typeof callbacks.onConfirmFixedGroupApply == "function") {
        imNotifyFuncs[47] = callbacks.onConfirmFixedGroupApply;
    }
    if (callbacks && typeof callbacks.onFixedGroupMemberAdd == "function") {
        imNotifyFuncs[48] = callbacks.onFixedGroupMemberAdd;
    }

    tupIm.confirmFixedGroupApply(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[47] == "function") {
                imNotifyFuncs[47](data);
            }
        },
        onFixedGroupMemberAdd: function(data) {
            if (typeof imNotifyFuncs[48] == "function") {
                imNotifyFuncs[48](data);
            }
        }
    });
};

//This function is used to administrator delete fixed group member.
function imDelFixedGroupMember(param, callbacks) {
    if (callbacks && typeof callbacks.onDelFixedGroupMember == "function") {
        imNotifyFuncs[49] = callbacks.onDelFixedGroupMember;
    }
    if (callbacks && typeof callbacks.onFixedGroupMemberDel == "function") {
        imNotifyFuncs[50] = callbacks.onFixedGroupMemberDel;
    }
    if (callbacks && typeof callbacks.onFixedGroupKickout == "function") {
        imNotifyFuncs[51] = callbacks.onFixedGroupKickout;
    }

    tupIm.delFixedGroupMember(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[49] == "function") {
                imNotifyFuncs[49](data);
            }
        },
        onFixedGroupMemberDel: function(data) {
            if (typeof imNotifyFuncs[50] == "function") {
                imNotifyFuncs[50](data);
            }
        },
        onFixedGroupKickout: function(data) {
            if (typeof imNotifyFuncs[51] == "function") {
                imNotifyFuncs[51](data);
            }
        }
    });
};

//This function is used to administrator delete discussion group member member.
function imDelDiscussionGroupMember(param, callbacks) {
    if (callbacks && typeof callbacks.onDelDiscussionGroupMember == "function") {
        imNotifyFuncs[52] = callbacks.onDelDiscussionGroupMember;
    }
    if (callbacks && typeof callbacks.onDiscussGroupDelMember == "function") {
        imNotifyFuncs[53] = callbacks.onDiscussGroupDelMember;
    }

    tupIm.delDiscussionGroupMember(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[52] == "function") {
                imNotifyFuncs[52](data);
            }
        },
        onDiscussGroupDelMember: function(data) {
            if (typeof imNotifyFuncs[53] == "function") {
                imNotifyFuncs[53](data);
            }
        }
    });
};

//This function is used to leave fixed group.
function imLeaveFixedGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onLeaveFixedGroup == "function") {
        imNotifyFuncs[54] = callbacks.onLeaveFixedGroup;
    }
    if (callbacks && typeof callbacks.onFixedGroupLeaveResult == "function") {
        imNotifyFuncs[55] = callbacks.onFixedGroupLeaveResult;
    }

    tupIm.leaveFixedGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[54] == "function") {
                imNotifyFuncs[54](data);
            }
        },
        onFixedGroupLeaveResult: function(data) {
            if (typeof imNotifyFuncs[55] == "function") {
                imNotifyFuncs[55](data);
            }
        }
    });
};

//This function is used to leave discussion group.
function imLeaveDiscussionGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onLeaveDiscussionGroup == "function") {
        imNotifyFuncs[56] = callbacks.onLeaveDiscussionGroup;
    }

    tupIm.leaveDiscussionGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[56] == "function") {
                imNotifyFuncs[56](data);
            }
        }
    });
};

//This function is used to transfer fixed group administrator.
function imTransferFixedGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onTransferFixedGroup == "function") {
        imNotifyFuncs[57] = callbacks.onTransferFixedGroup;
    }
    if (callbacks && typeof callbacks.onFixedGroupOwnerChg == "function") {
        imNotifyFuncs[58] = callbacks.onFixedGroupOwnerChg;
    }

    tupIm.transferFixedGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[57] == "function") {
                imNotifyFuncs[57](data);
            }
        },
        onFixedGroupOwnerChg: function(data) {
            if (typeof imNotifyFuncs[58] == "function") {
                imNotifyFuncs[58](data);
            }
        }
    });
};

//This function is used to transfer discussion group administrator.
function imTransferDiscussionGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onTransferDiscussionGroup == "function") {
        imNotifyFuncs[59] = callbacks.onTransferDiscussionGroup;
    }
    if (callbacks && typeof callbacks.onDiscussGroupOwnerChange == "function") {
        imNotifyFuncs[60] = callbacks.onDiscussGroupOwnerChange;
    }

    tupIm.transferDiscussionGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[59] == "function") {
                imNotifyFuncs[59](data);
            }
        },
        onDiscussGroupOwnerChange: function(data) {
            if (typeof imNotifyFuncs[60] == "function") {
                imNotifyFuncs[60](data);
            }
        }
    });
};

//This function is used to add discussion group.
function imAddDiscussionGroup(param, callbacks) {
    if (callbacks && typeof callbacks.onAddDiscussionGroup == "function") {
        imNotifyFuncs[61] = callbacks.onAddDiscussionGroup;
    }

    tupIm.addDiscussionGroup(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[61] == "function") {
                imNotifyFuncs[61](data);
            }
        }
    });
};

//This function is used to add the discussion group to the phone member.
function imAddDiscussioGroupPhoneMember(param, callbacks) {
    if (callbacks && typeof callbacks.onAddDiscussioGroupPhoneMember == "function") {
        imNotifyFuncs[62] = callbacks.onAddDiscussioGroupPhoneMember;
    }

    tupIm.addDiscussionGroupPhoneMember(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[62] == "function") {
                imNotifyFuncs[62](data);
            }
        }
    });
};

//This function is used to delete the discussion group to the phone member.
function imDelDiscussionGroupPhoneMember(param, callbacks) {
    if (callbacks && typeof callbacks.onDelDiscussioGroupPhoneMember == "function") {
        imNotifyFuncs[64] = callbacks.onDelDiscussioGroupPhoneMember;
    }

    tupIm.delDiscussionGroupPhoneMember(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[64] == "function") {
                imNotifyFuncs[64](data);
            }
        }
    });
};

//This function is used to set policy for discussion group.
function imSetDisgroupPolicy(param, callbacks) {
    if (callbacks && typeof callbacks.onSetDisgroupPolicy == "function") {
        imNotifyFuncs[66] = callbacks.onSetDisgroupPolicy;
    }

    tupIm.setDisgroupPolicy(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[66] == "function") {
                imNotifyFuncs[66](data);
            }
        }
    });
};

//This function is used to send files
function setP2pFileImEvent(callbacks){
    if (callbacks && typeof callbacks.onP2pFileProcess == "function") {
        imNotifyFuncs[68] = callbacks.onP2pFileProcess;
    }
    if (callbacks && typeof callbacks.onP2pFileStartResult == "function") {
        imNotifyFuncs[69] = callbacks.onP2pFileStartResult;
    }
    if (callbacks && typeof callbacks.onP2pFileStop == "function") {
        imNotifyFuncs[70] = callbacks.onP2pFileStop;
    }
    if (callbacks && typeof callbacks.onP2pFileStopResult == "function") {
        imNotifyFuncs[73] = callbacks.onP2pFileStopResult;
    }
    if (callbacks && typeof callbacks.onP2pFileIncomming == "function") {
        imNotifyFuncs[75] = callbacks.onP2pFileIncomming;
    }    

    tupIm.setP2pFileImEvent({
        onP2pFileIncoming:p2pFileIncoming,
        onP2pFileProcess:p2pFileProcess,
        onP2pFileStartResult:p2pFileStartResult,
        onP2pFileStopResult:p2pFileStopResult,
        onP2pFileStop:p2pFileStop
    });  

}

function p2pFileIncoming(data){
    imNotifyFuncs[75](data);
}
function p2pFileProcess(data){
    imNotifyFuncs[68](data);
}
function p2pFileStartResult(data){
    imNotifyFuncs[69](data);
}
function p2pFileStopResult(data){
    imNotifyFuncs[73](data);
}
function p2pFileStop(data){
    imNotifyFuncs[70](data);
}

//This function is used to send P2P file.
function imSendp2pFile(param, callbacks) {
    if (callbacks && typeof callbacks.onSendp2pFile == "function") {
        imNotifyFuncs[67] = callbacks.onSendp2pFile;
    }

    tupIm.sendP2PFile(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[67] == "function") {
                imNotifyFuncs[67](data);
            }
        }
    });
};

//This function is used to cancel P2P file.
function imCancelp2pFile(param, callbacks) {
    if (callbacks && typeof callbacks.onCancelp2pFile == "function") {
        imNotifyFuncs[71] = callbacks.onCancelp2pFile;
    }

    tupIm.cancelP2PFile(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[71] == "function") {
                imNotifyFuncs[71](data);
            }
        }
    });
};

//This function is used to accept P2P file.
function imAcceptp2pFile(param, callbacks) {
    if (callbacks && typeof callbacks.onAcceptp2pFile == "function") {
        imNotifyFuncs[74] = callbacks.onAcceptp2pFile;
    }

    tupIm.acceptP2PFile(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[74] == "function") {
                imNotifyFuncs[74](data);
            }
        }
    });
};

//This function is used to reject P2P file.
function imRejectp2pfile(param, callbacks) {
    if (callbacks && typeof callbacks.onRejectp2pfile == "function") {
        imNotifyFuncs[78] = callbacks.onRejectp2pfile;
    }

    tupIm.rejectP2PFile(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[78] == "function") {
                imNotifyFuncs[78](data);
            }
        }
    });
};

//This function is used to send discussion group message.
function imSendDisgroupOpMessage(param, callbacks) {
    if (callbacks && typeof callbacks.onSendDisgroupOpMessage == "function") {
        imNotifyFuncs[80] = callbacks.onSendDisgroupOpMessage;
    }
    if (callbacks && typeof callbacks.onDiscussGroupBroadcast == "function") {
        imNotifyFuncs[81] = callbacks.onDiscussGroupBroadcast;
    }

    tupIm.sendDisgroupOpMessage(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[80] == "function") {
                imNotifyFuncs[80](data);
            }
        },
        onDiscussGroupBroadcast: function(data) {
            if (typeof imNotifyFuncs[81] == "function") {
                imNotifyFuncs[81](data);
            }
        }
    });
};

//This function is used to login rich media.
function imRichMediaLogin(param, callbacks) {
    if (callbacks && typeof callbacks.onRichMediaLogin == "function") {
        imNotifyFuncs[82] = callbacks.onRichMediaLogin;
    }

    tupOfflinefile.login(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[81] == "function") {
                imNotifyFuncs[81](data);
            }
        }
    });
};

//This function is used to get department list.
function imGetDepts(param, callbacks) {
    if (callbacks && typeof callbacks.onGetDepts == "function") {
        imNotifyFuncs[82] = callbacks.onGetDepts;
    }

    tupIm.getDepts(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[82] == "function") {
                imNotifyFuncs[82](data);
            }
        }
    });
};

//This function is used to get system url.
function imGetSysUrl(callbacks) { //IM_E_EVENT_IM_SYSURLRET_NOTIFY
    if (callbacks && typeof callbacks.onGetSysUrl == "function") {
        imNotifyFuncs[83] = callbacks.onGetSysUrl;
    }
    if (callbacks && typeof callbacks.onSysUrlRet == "function") {
        imNotifyFuncs[84] = callbacks.onSysUrlRet;
    }

    tupIm.getSysUrl({
        response: function(data) {
            if (typeof imNotifyFuncs[83] == "function") {
                imNotifyFuncs[83](data);
            }
        },
        onSysUrlRet: function(data) {
            if (typeof imNotifyFuncs[84] == "function") {
                imNotifyFuncs[84](data);
            }
        }
    });
}

//This function is used to upload file.
function imUploadFile(param, callbacks) {
    if (callbacks && typeof callbacks.onUploadFile == "function") {
        imNotifyFuncs[85] = callbacks.onUploadFile;
    }
    if (callbacks && typeof callbacks.onOffLineRspNotify == "function") {
        imNotifyFuncs[86] = callbacks.onOffLineRspNotify;
    }

    tupOfflinefile.upLoadFile(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[85] == "function") {
                imNotifyFuncs[85](data);
            }
        },
        onOffLineRspNotify: function(data) {
            if (typeof imNotifyFuncs[86] == "function") {
                imNotifyFuncs[86](data);
            }
        }
    });
};

//This function is used to cancel the file upload(slices).
function imCancel(param, callbacks) {
    if (callbacks && typeof callbacks.onCancel == "function") {
        imNotifyFuncs[87] = callbacks.onCancel;
    }

    tupOfflinefile.cancel(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[87] == "function") {
                imNotifyFuncs[87](data);
            }
        }
    });
};

//This function is used to cancel the file upload.
function imRelease(param, callbacks) {
    if (callbacks && typeof callbacks.onRelease == "function") {
        imNotifyFuncs[88] = callbacks.onRelease;
    }

    tupOfflinefile.release(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[88] == "function") {
                imNotifyFuncs[88](data);
            }
        }
    });
};

//This function is used to download file.
function imDownLoadFile(param, callbacks) {
    if (callbacks && typeof callbacks.onDownLoadFile == "function") {
        imNotifyFuncs[89] = callbacks.onDownLoadFile;
    }
    if (callbacks && typeof callbacks.onOffLineRspNotify == "function") {
        imNotifyFuncs[90] = callbacks.onOffLineRspNotify;
    }
    if (callbacks && typeof callbacks.onOffLineProgNotify == "function") {
        imNotifyFuncs[91] = callbacks.onOffLineProgNotify;
    }

    tupOfflinefile.downloadFile(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[89] == "function") {
                imNotifyFuncs[89](data);
            }
        },
        onOffLineRspNotify: function(data) {
            if (typeof imNotifyFuncs[90] == "function") {
                imNotifyFuncs[90](data);
            }
        },
        onOffLineProgNotify: function(data) {
            if (typeof imNotifyFuncs[91] == "function") {
                imNotifyFuncs[91](data);
            }
        }
    });
};

//This function is used to resume file.
function imGetResumeupUrl(param, callbacks) {
    if (callbacks && typeof callbacks.onGetResumeupUrl == "function") {
        imNotifyFuncs[92] = callbacks.onGetResumeupUrl;
    }

    tupOfflinefile.getResumeupUrl(param, {
        response: function(data) {
            if (typeof imNotifyFuncs[92] == "function") {
                imNotifyFuncs[92](data);
            }
        }
    });
};